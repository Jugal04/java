
import java.util.*;

enum Value{
  LOW("L"), MEDIUM("M"), HIGH("H"), VERY_HIGH("VH");

  private  Value(String abbreviation){
   this.abbreviation=abbreviation;
  }

  public String getAbbreviation(){ 
     return abbreviation;
  }

  private String abbreviation;

}

public class EnumTest{

public static void main(String args[]){
  Scanner in = new Scanner(System.in);
  System.out.println("Enter Value Rating : LOW   MEDIUM  HIGH  VERY_HIGH");
  String input= in.next().toUpperCase();
  Value value = Enum.valueOf(Value.class, input);
  System.out.println("Value =  " +value);
  System.out.println("abbreviation =  " +value.getAbbreviation());

  if (value == Value.LOW){
    System.out.println("true Value is  LOW");

  }

 }
}



