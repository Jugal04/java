
/*

- enums help us to ensure only a fixed set of options are provided for
- variable.

- In the following example, anything other than LOW, MEDIUM, HIGH, VERY_HIGH, will result in error.

- Go through EnumTest.java for an advanced example

*/



import java.util.*;

enum Value{
  LOW, MEDIUM, HIGH, VERY_HIGH};
 

public class EnumTest1{

public static void main(String args[]){

Value value = Value.LOW;

System.out.println("item value  = " + value);

}
}

