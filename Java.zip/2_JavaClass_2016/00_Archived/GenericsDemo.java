//Generic class

class Pair<T>{

private T first;
private T second;

public Pair(){

}

public Pair( T first, T second){

this.first = first;
this.second =  second;

}

public T getFirst(){

return this.first;
}

public T getSecond(){

return this.second;
}


public void setFirst(T first){

this.first =  first;

}


public void setSecond(T second){

this.second =  second;

}

public String toString(){


//String info = "first = " + first +"  second = " + second ;
//return info;

return first.toString() +"  " + second.toString();


}

}

class Box{

private int l;
private int w;
private int h;

public Box(int l, int w, int h){
 this.l = l;
 this.w = w;
 this.h = h;

}

// setters and getters


public String toString(){

return "    Box Dimensions are \n" +
       "length = " + l +
       "width =  " + w +
       "height= "+ h +  "\n";
}


}


class GenericsDemo{

public static void main(String args[]){

Pair<Integer> ipair = new Pair<Integer>(10,20);
System.out.println(ipair);


Pair<String> spair = new Pair<String>("Ganesh","Ram");
System.out.println(spair);

Box b1 = new Box(10,20,30);
Box b2 = new Box(40,50,60);

Pair<Box> bpair = new Pair<Box>(b1,b2);
System.out.println(bpair);
}
}