import java.util.*;

public class GenericsTest{

public static void main(String args[]){


ArrayList<Integer> ai = new ArrayList<Integer>();

ai.add(100);
ai.add(200);
ai.add(300);
ai.add(400);
ai.add(500);

System.out.println(ai);

}



}