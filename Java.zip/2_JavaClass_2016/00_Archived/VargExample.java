// VargExample.java
// Illustrates the use of variable arguements in a method



public class VargExample{

    static void varArgMethod(int...int1){
    
         System.out.print("Total Arguements Passed " + int1.length + " Contents: ");
         for (int int2:int1)
             System.out.print(int2 +  "  ");
         System.out.println();
     }
     
     public static void main(String[] args){
         
          varArgMethod();
          varArgMethod(10,30,36);
          varArgMethod(1,2,3,4,5,6,7);
     }
}            

/****************************************************************************************************************

Code Analysis:
--------------

-  static void varArgMethod(int...int1) 

         - int1 acts like an array/ collection to hold all the arguements you pass

- int1.length 

          - contains the total number of arguements passed

- for (int int2:int1)
           
           - used to iterate through the collection
           - int2 reads the arguements from int1 one by one,  as it  navigates throug it
           
- Here int2 is type int because int1 is int

- If int1 happens to be String int2 will also have to be String (referVargExampleStringVersion.java)
           
******************************************************************************************************************/               
              
     
   