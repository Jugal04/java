// Demonstrates a method with a return type which accepts variable number of arguements


//VargExample2.java


public class VargExample2{

    static int varArgMethod(int...int1){
         int total = 0;
         System.out.print("Total Arguements Passed " + int1.length + " Contents: ");
         System.out.println();
         for (int int2:int1){
                 System.out.print(int2 +  "  ");
                 total = total + int2;  
                 System.out.println();
        }
        return total;
     }
     
     public static void main(String[] args){
         
         int t1 = varArgMethod();
         System.out.println("Total = " + t1); 

         int t2 =  varArgMethod( 10,30,36);
         System.out.println("Total = " + t2);

         int t3 =  varArgMethod( 1,2,3,4,5,6,7);
         System.out.println("Total = "  + t3);
     }
}                  