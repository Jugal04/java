//VargExampleStringversion.java

// Accepts Strings as variable arguements




public class VargExampleStringVersion{

    static void varArgMethod(String ...s1){
    
         System.out.print("Total Arguements Passed " + s1.length + " Contents: ");
         for (String  s3:s1)
             System.out.print(s3 +  "  ");
         System.out.println();
     }
     
     public static void main(String[] args){
         
          varArgMethod();
          varArgMethod("aa", "bb", "cc");
          varArgMethod("Hello");
     }
}           


/*****************************************************************************************************************

Code Analysis

- static void varArgMethod(String ...s1)
         String ...s1 indicates that the arguements should be String type

- for (String  s3:s1)
         String s3 iterates through the collection of strings
         Please note the use of String as the type foe s3
         This is required because s1 is String Collection
********************************************************************************************************************/          
	 



       