// class CloneDemo


 
class Employee implements Cloneable
 {
   public String name;
   private double salary;
   private Day hireDay;
 
   public Employee(String n, double s, Day d)
    {  name = n;
       salary = s;
       hireDay = d;
    }

   public Object clone()
   {
    try
      {
        Employee e = (Employee)super.clone();
        e.name =  new String(e.name+"  copy of");
        e.hireDay  =  (Day)hireDay.clone();
        return e;
      }

    catch (CloneNotSupportedException e)
      {
        e.printStackTrace();
        return null;
      }              

   } 
  
    public void print()
    {  System.out.println("name ...... = " + name + "\n"
                       + "salary .... = " + salary + "\n"
                       + "hireYear .. = " + hireYear());
    }
 
    public void raiseSalary(double byPercent)
    {  salary *= 1 + byPercent / 100;
    }
 
    public int hireYear()
    {  return hireDay.getYear();
    }
 }
 
 
public class CloneDemo
 {
   public static void main(String[] args)
    {  Employee anand = new Employee("Anand", 35000, 
 				new Day(1989,10,1));
       Employee anand_copy = (Employee)anand.clone();
             
       anand.print();
       anand_copy.print();

       if (anand.name == anand_copy.name)
          {
           System.out.println("refer to the same string");
          }
       else
         {
            System.out.println("refer to the different  strings");
         }
        
     }  
  }    
 
     
       

