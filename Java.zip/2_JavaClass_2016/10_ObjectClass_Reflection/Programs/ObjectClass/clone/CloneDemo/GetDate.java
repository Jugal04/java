import java.util.*;
public class GetDate{
	public static void main(String[] args){
		Calendar calendar = new GregorianCalendar();
		System.out.println(calendar.get(Calendar.DATE) +" "+String.valueOf(calendar.get(Calendar.MONTH) +1) +" "+calendar.get(Calendar.YEAR));
                                }
}

