import java.util.*;
public class GetDay{
	public static void main(String[] args){
		Day day =new Day(2015,11,3);
                                System.out.println(day);
                                }

                
}

