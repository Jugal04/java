// class CloneDemo1
 
class Employee implements Cloneable
 {
   public String name;
   private double salary;

 
   public Employee(String n, double s)
    {  name = n;
       salary = s;
      }

public Object clone() {
    try {
        Employee e = (Employee)super.clone();
        e.name =  new String(this.name);
        return e;
       }
    catch (CloneNotSupportedException e){
        e.printStackTrace();
        return null;
      }              
   } 


/* public Object clone(){

  try{
        return  super.clone();
      }
catch(CloneNotSupportedException cnse){
        cnse.printStackTrace();
        return null;
   }
}
*/
   public void print(){
             System.out.println("name ...... = " + name + "\n"  + "salary .... = " + salary + "\n");
     }
   }
  
public class CloneDemo1 {
   public static void main(String[] args){
       Employee anand = new Employee("Anand", 35000);
       Employee anand_copy = (Employee)anand.clone();
       anand.print();
       anand_copy.print();

       if (anand.name == anand_copy.name){
           System.out.println(" names refer to the same string");
            }
       else{
            System.out.println(" names refer to the different  strings");
           }
        }  
  }    
 
     
       

