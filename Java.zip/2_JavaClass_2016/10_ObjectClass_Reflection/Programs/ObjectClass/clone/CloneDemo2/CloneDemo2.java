// class CloneDemo2
 
class Employee implements Cloneable {
   public String name;
   private double salary;
   private Address address;
 
   public Employee(String name, double salary, Address address){
     this.name = name;
     this. salary = salary;
     this.address = address;
    }

   public Object clone()
   {
    try
      {
        Employee e = (Employee)super.clone();
        e.name =  new String(e.name);
        e.address =(Address)address.clone();
        return e;
      }

    catch (CloneNotSupportedException e)
      {
        e.printStackTrace();
        return null;
      }              

   } 
  
    public void print() {  System.out.println("name ...... = " + name + "\n"
                                                                 + "salary .... = " + salary + "\n"
                                                                  + "address.. = " + address);
    }
 

 }

class Address implements Cloneable{
 public int doorNo;
 public String streetName;
 public String city;
 public  String state;
 public int pin;

public Address(int doorNo, String streetName, String city, String state, int pin){
 this.doorNo = doorNo;
 this.streetName =  streetName;
 this.city = city;
 this.state = state;
 this.pin =  pin;
 }
 
 public String toString(){
   return "\n doorno = " + this.doorNo +
           "\n street Name = " + this.streetName +
		    "\n city  = " + this.city +
			 "\n state = " + this.state +
			 "\n pin =  "+  this.pin;
    }
  public Object clone(){
    try{
        Address a = (Address)super.clone();
        a.streetName = new String(this.streetName);
        a.city = new String(this.city);
        a.state =  new String(this.state);
        return a;
      }

    catch (CloneNotSupportedException e){
        e.printStackTrace();
        return null;
      }              
   } 
 }

public class CloneDemo2
 {
   public static void main(String[] args){
       Employee anand = new Employee("Anand", 35000, new Address(11,"KB Road", "Chennai", "Tamil Nadu", 600041));
       Employee anand_copy = (Employee)anand.clone();
             
       anand.print();
       anand_copy.print();
             
     }  
  }    
 
     
       

