class Employee{

	int empId;
	String empName;

	public Employee(){}

	public Employee(int empId, String empName){
 		this. empId= empId;
		this.empName =empName;
	}
	
     	  public boolean equals(Object obj){
               		if (! (obj.getClass()== (this.getClass()))){
                                          	System.out.println("incompatible object");
                                   	return false;    			}
				else{
                            		     	         Employee employee = (Employee)obj;
                                                     	         return (this.empId==employee.empId) && (this.empName.equals(employee.empName));
			     	     }
	}

}

class Book{
 int id;
String title;

}
public class EmployeeEqualsDemoTemp{

          public static void main(String[] args){


	Employee employee1 = new Employee(102, "Ganesh");
                Book b1 = new Book();

  System.out.println("book - employee1 equals  " + employee1.equals(b1));
  

                Employee employee2 = new Employee(102, "Ganesh");

                Employee employee3 = new Employee(103, "Ganesh");
                Employee employee4 = new Employee(104, "Ganesh");

                 Employee employee5 = new Employee(105, "Ganesh");
                 Employee employee6 = new Employee(105, "Giri");

                System.out.println("employee1.equals(employee2) is  " + employee1.equals(employee2));
                System.out.println("employee3.equals(employee4) is  " + employee3.equals(employee4));
                System.out.println("employee5.equals(employee6) is  " + employee5.equals(employee6));

                System.out.println("employee5.equals(Hello) is  " + employee5.equals("Hello"));

                System.out.println("book " + b1.getClass());
                System.out.println("employee1 " + employee1.getClass());
             System.out.println("employee2 " + employee2.getClass());

              
               }

}

// if (obj instanceof Employee)


