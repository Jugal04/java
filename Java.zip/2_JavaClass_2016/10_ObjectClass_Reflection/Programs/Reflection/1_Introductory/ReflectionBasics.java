// demonstrates the use of getClass(), getSuperClass(),class, instanceof

class Animal{
  String type; 
  int age;
  String color;
  boolean speed;

  void eat(){
  System.out.println("Animal eats");
  }

  void attack(String severity){
  System.out.println("Animal attack is severity level " + severity);
  }

  void makeNoise(){
  System.out.println("Animal makes noise");
  }

}

class Dog extends Animal{

  boolean isVaccinated;
  int speed;

  void makeNoise(){
  System.out.println("Dog barks");
  }

  void attack(String severity,boolean isFatal){
  if (isFatal){
    attack(severity);
    }
  }

  void assignSpeed(){
  speed = 40;
  super.speed = true;
  }
}

class Cat extends Animal{
  
  void makeNoise(){
  super.makeNoise();
  System.out.println("cat mews");
  }
}

class ReflectionBasics{

  public static void main(String[] args){
      Animal animal = new Animal();
      Dog dog = new Dog();
      Cat cat = new Cat();

     Find.find(animal);
     Find.find(dog);
     Find.find(cat);

   }
}

class Find{

public static void find(Object object) {
 
  System.out.println("class  is " + object.getClass().getName());

  System.out.println("Super Class is " +object.getClass().getSuperclass().getName() + "\n");

   if (object.getClass() == Cat.class){
     System.out.println("caught  Cat");
      }
    else{
   System.out.println("Not  Cat");
     } 
     

  if (object instanceof Animal){
     System.out.println(object.getClass().getName() + " is an instance of Animal");
          //same way you can check for interface instances
    }
   try{
        Class class1 = Class.forName("Dog");
        System.out.println("the class for class1 is " + class1.getName());
      }
 catch(ClassNotFoundException cne){
       cne.printStackTrace();
}

Class c1 =Animal.class;
System.out.println("the class forAnimal  is " + c1.getName());
 }

}

