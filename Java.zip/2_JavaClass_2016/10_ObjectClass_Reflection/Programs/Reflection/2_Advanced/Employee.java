  public class Employee{
  private int empNo;
  public String empName;
  double salary;

  public void setEmpNo(int empNo){ 
       this.empNo =  empNo;
  }

  public int getEmpNo(){
   return this.empNo;
   }
   public Employee(){}
   public Employee(int empNo, String empName, double salary){
   this.empNo =  empNo;
   this.empName =  empName;
   this.salary =  salary;   
  }
  
  public double bonus(double percent){
  return (salary*percent)/100;
  }
}