import java.lang.reflect.*;
import java.util.*;


class ReflectionAdvanced{
   public static void main(String[] args) throws Exception{
   Employee employee = new Employee(1234, "Ganesh", 20000.00);
   Reflect.getDetails(employee);
   Reflect.getFieldValue1(employee);
   Reflect.getFieldValue2(employee);
   }
}

class Reflect{
   public static void getDetails(Object obj) {
   Class myClass = obj.getClass();
    int modifiers  = myClass.getModifiers();
   System.out.println("\nModifier of class is  " +   Modifier.toString(modifiers));

  Field[] fields = myClass.getDeclaredFields();
  System.out.println("\nThe fields are \n");
  for (Field f : fields){  
     Class type = f.getType();
     String name =  f.getName();  
     System.out.println("");
     String fmodifiers  = Modifier.toString(f.getModifiers());
     System.out.println(fmodifiers);
      System.out.println(type.getName() + "  " + name);
    }
   System.out.println("\nThe Methods are \n");
   Method[] methods = myClass.getDeclaredMethods();
      for(Method m:methods) {
          Class retType = m.getReturnType();
          String name = m.getName();
          String mmodifiers = Modifier.toString(m.getModifiers());
          System.out.println(mmodifiers+ " " +retType.getName() + "  "+ name + " ");
 
          Class[] paramTypes =  m.getParameterTypes();
              for(int i=0;i<paramTypes.length;i++){
             System.out.println("parameter types "+paramTypes[i].getName()+"\n");
            }
        }
   }

   public static void getFieldValue1(Object object) throws Exception{
       Class myClass = object.getClass();
       Field empNameField = myClass.getDeclaredField("empName");
       String empNameValue =(String) empNameField.get((Employee)object);
       System.out.println("employee name is  " + empNameValue);
  }

 public static void getFieldValue2(Object object) throws Exception{
       Class myClass = object.getClass();
       Field empNoField = myClass.getDeclaredField("empNo");
    //  empNoField.setAccessible(true);     
       Integer empNoValue =(Integer) empNoField.get((Employee)object);
       System.out.println("employee nos  " + empNoValue);
  }
}
