 class ThrowsDemo
 {
   public static void main(String args[])
   {
     System.out.println("Before calling a()...");
try{
     a();
}
catch (Exception cne){

    System.out.println("cne" +cne);
}
     System.out.println("After calling a()...");
   }
 
   public static void a() throws ClassNotFoundException
   {
     try
     {
       b();
     }
     //catch(ClassNotFoundException e)
 catch(ArithmeticException e)
     {
       e.printStackTrace();
     }
   }
   
   public static void b() throws ClassNotFoundException
   {
     c();
   }
 
   public static void c() throws ClassNotFoundException
   {
     Class cls = Class.forName("java.lang.Intger");         //need to spell wrongly to have the exception caught
     System.out.println(cls.getName());
     System.out.println(cls.isInterface());
   }
 }
