
import java.io.*;

class ExSuper
 {
    
   public static void b() throws FileNotFoundException
   {
     
   }
 
   
 }


// sub class can throw any unchecked exception

class ExSub1 extends ExSuper{

 
public static void b() throws ArithmeticException
   {
     
   }
}




// sub class cannot throw a higher checked exception
// will result in compile error

class ExSub extends ExSuper{


public static void b() throws IOException    
   {
     
   }




}

// or subclass may not throw any exception at all