/* 

-- Exception thrown
-- Not Caught
-- but finally block is present
-- finally block will execute
-- Statements after finally block will not  execute

-- also catch should immediately follow try 
-- and finally (if used) should immediately follow catch

*/


class TCF3{
  public static void main(String args[]) 
  {  
    try 
    {
      System.out.println("Before Division");
      int i = Integer.parseInt(args[0]);
      int j = Integer.parseInt(args[1]);
      System.out.println(i/j);
      System.out.println("After Division");
                    }
                                              //System.out.println("after try before  catch ");    // error 
   
    catch(ArrayIndexOutOfBoundsException e) 
    {
      System.out.println("ArrayIndex" + 
        "OutOfBoundsException");
    }

                                                // System.out.println("after catch -  before catch");    // error 
    catch(NumberFormatException e) 
    {
      System.out.println("NumberFormatException");
    }
    
                                                // System.out.println("after catch - just before finally");    // error 

     finally 
    {
      System.out.println("Finally block");

     }
 System.out.println("After finally block");
  
  }
}
