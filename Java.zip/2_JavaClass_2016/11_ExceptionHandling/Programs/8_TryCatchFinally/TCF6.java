
/*
 -- Try - finally combination
 -- No Exception thrown
 -- finally executes
 -- the statement after finally excecutes

*/


class TCF6{
  public static void main(String args[]) 
  {  
    try 
    {
      System.out.println("Before Division");
      int i = Integer.parseInt(args[0]);
      int j = Integer.parseInt(args[1]);
      System.out.println(i/j);
      System.out.println("After Division");
    }
        
     finally 
    {
      System.out.println("Finally block");
    }

    System.out.println(" after finally block");
  }
}
