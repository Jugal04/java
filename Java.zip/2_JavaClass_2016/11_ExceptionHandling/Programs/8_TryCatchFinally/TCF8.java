/*
--  System.exit(0) in try
-- finally will not be executed
--  
*/


/* 

-- return in try
-- finally will execute

*/




class TCF8
{
  public static void main(String args[]) 
  {  
    try 
    {
      System.out.println("in try");
      System.exit(0);             // finally will not be executed
      // return;                 //  finally will be executed
      
    }
   finally{

    System.out.println("in finally");

    } 
   
  }
}
