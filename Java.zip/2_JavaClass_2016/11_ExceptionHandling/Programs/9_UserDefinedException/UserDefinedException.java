 import java.util.*;
 
 class UserDefinedException extends Exception
 {
  
  private int accountNumber;
  private double withdrawalAmount;
  private double drawingLimit;
 

  public  UserDefinedException()
   {
   }
   
  public UserDefinedException(String message)
   {
     super(message);
   }

  public UserDefinedException(String message, int p_accountNumber, double p_withdrawalAmount,double p_drawingLimit)
   {
    this(message);
    accountNumber = p_accountNumber;
    withdrawalAmount =  p_withdrawalAmount; 
    drawingLimit = p_drawingLimit;
   }

   public void getErrorDetails() 
    {
     System.out.println("Transaction Rejected: withdrawal exceeds limit");
     System.out.println("Account Number = " + accountNumber) ;
     System.out.println("Limit = " + drawingLimit); 
     System.out.println("Withdrawal Amount =  " + withdrawalAmount);
     System.out.println(getMessage());
 }
  }
      