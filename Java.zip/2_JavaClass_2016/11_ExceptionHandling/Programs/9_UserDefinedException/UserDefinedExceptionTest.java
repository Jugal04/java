 class UserDefinedExceptionTest
 {
   public static void main(String args[])
    {
     int acnum;
     double wd;
     final double LIMIT = 10000.00;
       try
         {
           System.out.println(" Enter Account Number");
           acnum = Console.readInt();

            System.out.println("Enter Withdrawal Amount");
            wd = Console.readDouble();
            if ( wd > LIMIT )
             {
               throw new UserDefinedException("Insufficient Limit", acnum, wd, LIMIT);
              } 
          }
   
       catch (NumberFormatException nf)
         {
          System.out.println("Number Format Exception"); 
         }
           
       catch (UserDefinedException ue)
         {
           ue.getErrorDetails();
         } 
  }
 }
 