import java.util.*;

public class ConcurrentModification
{  public static void main(String[] args)
   {  

      List<String> b =  new LinkedList<String>();

      b.add("Angela");
      b.add("Carl");
      b.add("Erica");
      
      System.out.println("The elements of linked list b: after add ");
      System.out.println(b);

      ListIterator rIter = b.listIterator();  
      ListIterator r1Iter = b.listIterator();
     

       if (rIter.hasNext())
        {
           String s1 =(String)rIter.next();
           if(s1.equals("Angela"))
               rIter.remove();
        }

       if (r1Iter.hasNext()){            // results in concurrent modification excepion
          r1Iter.next();
     }

      System.out.println();
      System.out.println("After removing  from b...");
      System.out.println(b);

      
   }
}

/* Mod Count in list - Mod Count in iterator - compared by iterator */

