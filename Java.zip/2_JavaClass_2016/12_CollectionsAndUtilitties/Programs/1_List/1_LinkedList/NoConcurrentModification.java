// note that  set doesnot throw concurrent modification exception

import java.util.*;

public class NoConcurrentModification
{  public static void main(String[] args)
   {  

      List<String> b =  new LinkedList<String>();

      b.add("Angela");
      b.add("Carl");
      b.add("Erica");
      
      System.out.println("The elements of linked list b: after add ");
      System.out.println(b);

      ListIterator rIter = b.listIterator();  
      ListIterator r1Iter = b.listIterator();
     

       while (rIter.hasNext()){  

           while (r1Iter.hasNext()){

                  String s1 =(String)rIter.next();
                         if(s1.equals("Angela"))
                              rIter.set("Angela modified by set");

                  String s2=(String)r1Iter.next();     
                         if(s2.equals("Erica"))
                             r1Iter.set("Erica modified by set");
                         
            }
      }

      System.out.println();
      System.out.println("After set ...");
      System.out.println(b);

      
   }
}



