import java.util.*;

class IteratorDemo 
 {

  public static void main(String args[]) {

    // Create a vector and its elements
    Vector vector = new Vector();
    vector.addElement(new Integer(5));
    vector.addElement(new Float(-14.14f));
    vector.addElement(new String("Hello"));
    vector.addElement(new Long(120000000));
    vector.addElement(new Double(-23.45e-11));

    // Display the elements of the vector
    System.out.println("The vector elements are: ");
    Iterator e = vector.iterator();
    while(e.hasNext()) {
      Object obj = e.next();
      System.out.println(obj);
    }
  }
}
    
