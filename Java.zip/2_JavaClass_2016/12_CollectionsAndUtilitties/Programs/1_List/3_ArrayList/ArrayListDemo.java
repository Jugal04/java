import java.util.*;

public class ArrayListDemo{
	public static void main(String[] args){

		ArrayList<String> list = new ArrayList<String>();

		// List list = new ArrayList(); type object , not recommended
                                // List clist = new ArrayList(100);  100 is capacity / similar to string buffer

    	   	list.add("Hello");
		list.add("hi");
		list.add("hi2");
		list.add("hi3");
		list.add("hi4");
		list.add("hi5");
		list.add("hi6");
		list.add("hi7");
		list.add("hi8");

		System.out.println(list);

		list.add(3,"hi0");  //inserts
		System.out.println("length is " + list.size());
		System.out.println("the position of hi3 is " + list.indexOf("hi3"));
		System.out.println("element at 5  is  " + list.get(5));  
		list.set(4,"four");
		String removedValue = list.remove(5);   //param is int - index
                                boolean isRemoved =  list.remove("hi7");   // param is Object - value
		System.out.println("element at 5  is  " + list.get(5));

		System.out.println(list);

		//Synchronized ArrayList ( no synch for class � only for the methods)
		List <String> synchlist = Collections.synchronizedList(new ArrayList<String>());
		}
}

