import java.util.*;
import java.io.*;

public class HashSet2{
	public static void main(String[] args){
		Set<String>  hset = new HashSet<String>();
		hset.add("java");
		hset.add("vb");
   		hset.add("oracle");
      		hset.add("oracle");  		// wont add duplicates
                                hset.add(new String("oracle"));  	// strangely this is also treated as duplicate
		hset.add(new String("oracle"));  //strangely this is also treated as duplicate
      		System.out.println(hset);

		System.out.println("vb present in the hash set  " +hset.contains("vb"));
		hset.remove("vb");
		System.out.println(hset);
		System.out.println("length  = " +hset.size());     

		Iterator iter = hset.iterator();
         			while (iter.hasNext()){
            				String s = (String)iter.next();
  				 System.out.println(s);
			}
		System.out.println(hset);
 
		}
}
// no get method for hashset ... Can you create one ?


