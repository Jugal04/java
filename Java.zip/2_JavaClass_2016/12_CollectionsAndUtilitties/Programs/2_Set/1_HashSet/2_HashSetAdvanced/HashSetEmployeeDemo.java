import java.util.*;
import java.io.*;

class Employee{
  int empId;
  String empName;
  String city;

  public Employee(){}

  public Employee(int empId, String empName, String city){
  this.empId = empId;
  this.empName =  empName;
  this.city =  city;
  }

  public String toString(){
  return  " empId = " + empId +"\n" + "empName = "  +  empName +"\n"  + "city = " + city +"\n";
  }

  public boolean equals(Object obj){
  if  (!(obj.getClass()==this.getClass())){
     return false;
     }
      else{
               return this.empId == ((Employee)obj).empId && this.empName.equals (((Employee)obj).empName);
             }
  }

  // comment hashCode() and observe
 public int hashCode(){
  return 17 *( (Integer)empId).hashCode() + empName.hashCode() ;
    // return 17 *( (Integer)empId).hashCode() + empName.hashCode() + city.hashCode(); // what hapens if this line is used  ?
  }
}

public class HashSetEmployeeDemo{
  public static void main(String[] args){
  Set<Employee>  hset = new HashSet<Employee>();
  hset.add(new Employee(101, "Ganesh", "Chennai"));
  hset.add(new Employee(102, "SaiRam", "Hyderabad"));
  hset.add(new Employee(102, "SaiRam","Vizag"));
  System.out.println(hset);
   }
}



