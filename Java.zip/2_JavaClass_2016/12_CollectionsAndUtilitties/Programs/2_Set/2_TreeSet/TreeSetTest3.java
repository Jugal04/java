
import java.util.*;

// Item Class definition

class Item implements Comparable{
	 private String description;
	 private int partNumber;

	public Item(String aDescription, int aPartNumber){
		description = aDescription;
     	 partNumber = aPartNumber;
   	}

  	 public String getDescription(){  
	 return description;
   	}

 	public String toString(){
	return "\n {descripion=" + description
         	+ ", partNumber=" + partNumber + "}";
  	 }

  	 public boolean equals(Object other){ 
	 if (getClass() == other.getClass()){
		Item otherItem = (Item)other;
        		 return description.equals(otherItem.description)&& (partNumber == otherItem.partNumber);
      		}
      		else{
       			 return false;
		       }
  	 }

  	public int hashCode(){
	return 13 * description.hashCode() + 17 * partNumber;
  	 }

	public int compareTo(Object other){
		Item otherItem = (Item)other;
      		return partNumber - otherItem.partNumber;
  	 }

              // return descrA.compareTo(descrB); for sorting on name
}



public class TreeSetTest3{
	public static void main(String[] args){ 

	//SortedSet parts = new TreeSet();
                TreeSet parts = new TreeSet();
	parts.add(new Item("Toaster", 1234));
	parts.add(new Item("Modem", 9912));
	parts.add(new Item("Book", 12));
	parts.add(new Item("Pen", 9913));

	System.out.println();
	System.out.println("Tree set sorted by partno...");
     	System.out.println(parts);
	}
   }
