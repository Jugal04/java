import java.util.*;

class Employee {
	public Employee(String n){
		name = n;
    		salary = 0;
   	}
   	public String toString(){
	return "[name=" + name + ", salary=" + salary + "] \n";
  	}
	public void setSalary(double s){
	salary = s;
	}
	private String name;
	private double salary;
}
public class TreeMapTest{
public static void main(String[] args){
	TreeMap staff = new TreeMap();
	staff.put("144-25-5464", new Employee("Angela Hung"));
	staff.put("567-24-2546", new Employee("Harry Hacker"));
	staff.put("157-62-7935", new Employee("Gary Cooper"));
	staff.put("456-62-5527", new Employee("Francesca Cruz"));  	
	System.out.println(staff);

	staff.remove("567-24-2546");
	System.out.println(staff);
          
	staff.put("456-62-5527", new Employee("Francesca Miller"));  //replaces value part of the hash map entry
	System.out.println(staff);

 	// look up a value
	System.out.println();
	System.out.println("The element with key 157-62-7935 is :");
	System.out.println(staff.get("157-62-7935"));

	// iterate through all entries
	System.out.println("Printing the elements of staff through an iterator...");
	Set entries = staff.entrySet();  // converts hash map to Set, since there is no iterator for Map
	Iterator iter = entries.iterator();
	while (iter.hasNext()){
		Map.Entry entry = (Map.Entry)iter.next();       //Entry is a nested static interface inside  interface Map
         		Object key = entry.getKey();
         		Object value = entry.getValue();
         		System.out.println("key=" + key + ", value=" + value);
     		 }
  	 }
}

