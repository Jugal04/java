/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/



public class ForEachLoop{
 public static void main(String args[]){
  int j=0;
 int[] marksArray = {10, 20, 30, 40,50};
 
 for(int i:marksArray){
  System.out.println("marksArray["+ j++ +"] = " + i);
  }
 }
}

