/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/

import java.util.*;


public class ForEachLoop2{
 public static void main(String args[]){
  
  List<String> list = new ArrayList<String>();


  list.add("Hello");
  list.add("hi");
  list.add("hi2");
  list.add("hi3");
  list.add("hi4");
  list.add("hi5");
  list.add("hi6");
  list.add("hi7");
  list.add("hi8");

 int j=0;
 for (String i:list){
  System.out.println("list("+ j++ +") = " + i);
  }
 }
}

