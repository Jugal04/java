/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/

import java.util.*;


public class ForEachLoop3{
 public static void main(String args[]){
  
  List<Person> list = new ArrayList<Person>();


  list.add(new Person("Ganesh", 20));
  list.add(new Person("Ram", 22));
  list.add(new Person("Ravi", 30));
  list.add(new Person("Tuli", 40));
  

 int j=0;
 for (Person p:list){
  System.out.println("list("+ j++ +") = " + p);
  }
System.out.println(" printing the list" + list);



 }
}

