
import java.util.*;

class CalendarDemo {

  public static void main(String args[]) {

    Calendar calendar = Calendar.getInstance();
    System.out.println("YEAR = " + calendar.get(Calendar.YEAR));
    System.out.println("HOUR = " + calendar.get(Calendar.HOUR));
    System.out.println("HOUR_OF_DAY = " + calendar.get(Calendar.HOUR_OF_DAY));
    System.out.println("MINUTE = " + calendar.get(Calendar.MINUTE));
  }
}







