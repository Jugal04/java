import java.util.*;

class DateDemo {

  public static void main(String args[]) {

    // Get date object initialized 
    // to current date and time
    Date currentDate = new Date();

    // Display current date
    System.out.println(currentDate);

    // Get date object initialized to
    // the epoch (Jan 1 1970)
    Date epoch = new Date(0);
    
    // Display epoch date
    System.out.println(epoch);
  }
}
    
