
import java.util.*;

// Item Class definition

class Item implements Comparable
{  public Item(String aDescription, int aPartNumber)
   {  description = aDescription;
      partNumber = aPartNumber;
   }

   public String getDescription()
   {  return description;
   }

   public String toString()
   {  return "\n {descripion=" + description
         + ", partNumber=" + partNumber + "}";
   }

   public boolean equals(Object other)
   {  if (getClass() == other.getClass())
      {  Item otherItem = (Item)other;
         return description.equals(otherItem.description)
            && partNumber == otherItem.partNumber;
      }
      else
         return false;
   }

   public int hashCode()
   {  return 13 * description.hashCode() + 17 * partNumber;
   }

// compareTo is used for natural sorting

// Return 1 if the current object is greater, -1 if lesser or 0
// if equal. You can use an appropriate logic and return any of these values


   public int compareTo(Object other)
   {  Item otherItem = (Item)other;
      return partNumber - otherItem.partNumber;
   }

   private String description;
   private int partNumber;
}



public class TreeSetTest2
{  public static void main(String[] args)

   { 

   // creating a  TreeSet object based on natural ordering
    
      SortedSet parts = new TreeSet();

      parts.add(new Item("Toaster", 1234));
      parts.add(new Item("Modem", 9912));

      System.out.println();
      System.out.println("Tree set sorted by partno...");
      System.out.println(parts);

    /*  SortedSet sortByDescription = new TreeSet(
         new Comparator()
         {  public int compare(Object a, Object b)
            {  Item itemA = (Item)a;
               Item itemB = (Item)b;
               String descrA = itemA.getDescription();
               String descrB = itemB.getDescription();
               return descrA.compareTo(descrB);
            }
         });
  */


  // Defining a class which implements Comparator Interface

     class MyComparator implements Comparator{

        public int compare(Object a, Object b)
            {  Item itemA = (Item)a;
               Item itemB = (Item)b;
               String descrA = itemA.getDescription();
               String descrB = itemB.getDescription();
               return descrA.compareTo(descrB);
            }
    }

 //   Creating a comparator object

     MyComparator mycomp = new MyComparator();


//creating a treeset object which will sort based on the comparator object

      SortedSet sortByDescription = new TreeSet(mycomp);

      sortByDescription.add(new Item("Toaster", 1234));
      sortByDescription.add(new Item("Modem", 9912));
      sortByDescription.add(new Item("APC UPS", 19912));
    
      System.out.println();
      System.out.println("Tree set sorted by description...");
      System.out.println(sortByDescription);
   }
}

/************************************************************************************************

implementing compareTo method to be consistant with equals method
-------------------------------------------------------------------

 public int compareTo(Object otherItem) {
        if ((this.partnumber == ((Item) otherItem).partnumber)

        &&   this.description.equals(otherItem.description))

        return 0;
     //similarly return 1 or -1 based on your logic.
  
     
        //else if ((this.Sal) > ((Employee) o1).Sal)
          //  return 1;
        //else
          //  return -1;
    }
} 

*************************************************************************************************/


