import java.util.*;

class VectorDemo {

  public static void main(String args[]) {

    // Create a vector and its elements
    Vector vector = new Vector();
    vector.addElement(new Integer(5));
    vector.addElement(new Float(-14.14f));
    vector.addElement(new String("Hello"));

    // Display the vector elements
    System.out.println("The vector is : ");
    System.out.println(vector);

    System.out.println();
    System.out.println("Size of the vector is " + vector.size());
    System.out.println("Capacity of the vector is " + vector.capacity());

    // Insert an element into the vector
    String s = new String("inserted value");
    vector.insertElementAt(s, 1);

    System.out.println();
    System.out.println("The vector after inserting an element at index 1 : ");
    System.out.println(vector);
 
    // Remove an element from the vector
    vector.removeElementAt(1);

    System.out.println();
    System.out.println("The vector after removing an element at index 1 : ");
    System.out.println(vector);
  }
}
    
