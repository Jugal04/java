import java.io.*;

class PrintWriterDemo
{
    public static void main(String args[])
                            throws Exception
    {
        PrintWriter pw =
                     new PrintWriter
                     (new BufferedWriter
                     (new OutputStreamWriter
                     (new FileOutputStream
                     ("C:/kr/javafiletest/PWDemo.txt"))));

        pw.print("kumar");
        pw.print(":");
        pw.print(22);
        pw.print(":");
        pw.println(1000.00);
    
        pw.print("mohan");
        pw.print(":");
        pw.print(33);
        pw.print(":");
        pw.println(2000.00);

        pw.print("raju");
        pw.print(":");
        pw.print(44);
        pw.print(":");
        pw.println(3000.00);

        pw.close();

        System.out.println("Successfully written" +
                " to the file...");
    }
}
