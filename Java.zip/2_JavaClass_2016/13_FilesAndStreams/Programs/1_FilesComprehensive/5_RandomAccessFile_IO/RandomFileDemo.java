import java.io.*;

public class RandomFileDemo
{
   public static void main(String[] args)
   {
      File myFile = new File(args[0]);
      
      if (myFile.exists() && myFile.isFile())
      {
         RandomAccessFile raf=null;
         try
         {
            raf = new RandomAccessFile(myFile, "rw");
         
            while(true)
            {
    	       int value = raf.readInt();

               int lBound = Integer.parseInt(args[1]);
               int uBound = Integer.parseInt(args[2]);

	 
               if ((value < lBound) || (value > uBound))
               {
                  raf.seek(raf.getFilePointer() - 4);
                  raf.writeInt((int)((uBound-lBound+1)*Math.random()+lBound) );
    	       }
            }
         }      
         catch(Exception e)
         {
            System.out.println(e);
         }
         try
         {
            raf.close();
         }
         catch(Exception e)
         {
            System.out.println(e);
         }         
      }
      else if (myFile.exists() && myFile.isDirectory())
      {
         System.out.println(myFile + " is a directory");
         System.exit(0);
      }
      else if (!myFile.exists())
      {
         RandomAccessFile raf=null;
         try
         {
            raf = new RandomAccessFile(myFile, "rw");

            int lBound = Integer.parseInt(args[1]);
            int uBound = Integer.parseInt(args[2]);

            for (int i=0; i < 5; i++)
            {
               raf.writeInt((int)((uBound-lBound+1)*Math.random()+lBound) );
            }

         }
         catch(Exception e)
         {
            System.out.println(e);
         }
         try
         {
            raf.close();
         }
         catch(Exception e)
         {
            System.out.println(e);
         }
      }

      System.out.println("The current content of the file...");

      RandomAccessFile raf = null;

      try
      {
         raf = new RandomAccessFile(myFile, "r");

         while(true)
         {
            System.out.println(raf.readInt());
         }

      }
      catch(IOException e)
      {
         System.out.println (" all records retrieved.. Bye");
      }
      try
      {
         raf.close();
      }
      catch(Exception e)
      {
         System.out.println(e);
      }         

   }
}
