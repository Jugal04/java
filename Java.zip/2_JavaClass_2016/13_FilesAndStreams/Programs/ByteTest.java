import java.io.*;

class ByteTest
{
    public static void main(String args[])
    {
        ByteArrayOutputStream baos = 
			new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        try
        {
            // Writing data to a byte array 
            // through the ByteArrayOutputStream object.


            dos.writeUTF("Kumar");
            dos.writeInt(23);
            dos.writeDouble(5000.00);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        try
        {
            dos.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        // Retrieving the data written to the
        // ByteArrayOutputStream object as a byte array

        byte[] ba = baos.toByteArray();

        byte[] b2 = new byte[baos.size()];
        System.arraycopy(ba, 0, b2, 0, baos.size());
   
        // Attaching a byte array to a stream
        ByteArrayInputStream bais 
		= new ByteArrayInputStream(b2);
	    
       DataInputStream dis = new DataInputStream(bais);

       try
       {
           while(true)
           {
              System.out.print(dis.readUTF() + "\t");
              System.out.print(dis.readInt() + "\t");
              System.out.println(dis.readDouble());
           }
       }
       catch(Exception e)
       {
           if (e instanceof EOFException)
           {
               System.out.println("EOF reached");
           }
       }

       try
       {
           dis.close();
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
    }
}
