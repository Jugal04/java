import java.io.*;

class CharTest
{
  public static void main(String args[])
  {
    try
    {
        CharArrayWriter caw = new CharArrayWriter();
        caw.write("core");
        caw.write(":");
        caw.write("java");
        caw.close();

        char[] ca = caw.toCharArray();

        char[] c2 = new char[caw.size()];
        System.arraycopy(ca, 0, c2, 0, caw.size());

        CharArrayReader car = new CharArrayReader(c2);
        BufferedReader br = new BufferedReader(car);

        String line = br.readLine();
        System.out.println(line);

        br.close(); 
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
  }
}
