// illustrates the role of inheritance in serialization

import java.io.*;

class Employee{

String location;
int year;
String city;

Employee(){
  System.out.println(" in employee constructor \n\n");
  location="TCO";
  year = 2006;
 }

}

class Manager extends Employee implements Serializable{  
                                            
int id;
String name;

Manager(int id, String name,String location, int year, String city){
 this.id =id;
 this.name = name;
 this.location = location;
 this.year = year;
 this.city = city;
 System.out.println(" in Manager constructor \n\n");
 }

}

public class BaseNoSerial{

  public static void main(String[] args) throws IOException, ClassNotFoundException{
 
   Manager m1 = new Manager(126,"GreatMan","ASV", 2007,"Chennai");

   System.out.println( " before ser " + m1.id);
   System.out.println( " before ser " + m1.name);
   System.out.println( " before ser " + m1.location);
   System.out.println( " before ser " + m1.year);
   System.out.println( " before ser " + m1.city + "\n");

   ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("c:/employee.dat"));
   out.writeObject(m1);
   out.close();

   ObjectInputStream in =  new ObjectInputStream(new FileInputStream("c:/employee.dat"));

   Manager mr1 = (Manager)in.readObject();
   in.close();

   System.out.println( " after deser " + mr1.id);
   System.out.println( " after deser " + mr1.name);
   System.out.println( " after deser " + mr1.location);
   System.out.println( " after deser " + mr1.year);
   System.out.println( " after deser " + mr1.city);
  
   }

}
         