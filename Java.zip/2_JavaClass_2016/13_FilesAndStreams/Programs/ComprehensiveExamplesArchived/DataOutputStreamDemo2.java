import java.io.*;

class DataOutputStreamDemo2
{
  public static void main(String args[]) throws Exception{
                                  
/*    DataOutputStream 
  dos = new DataOutputStream
                       (new BufferedOutputStream
                       (new FileOutputStream
              	  	   ("C:/kr/DataStream.bin")));
*/

     File mf = new File("c:/kr/DataStream.bin");
     FileOutputStream fos = new FileOutputStream(mf);
     BufferedOutputStream bos = new BufferedOutputStream(fos);
     DataOutputStream dos = new DataOutputStream(bos);
    
       

    dos.writeUTF("Kumar2");
    dos.writeInt(23);
    dos.writeDouble(5000.00);

    dos.writeUTF("Anand2");
    dos.writeInt(26);
    dos.writeDouble(10000.00);

    dos.writeUTF("Kannan2");
    dos.writeInt(13);
    dos.writeDouble(8000.00);

    dos.close();

System.out.println 
      ("Successfully written to the file...");
  }
}
