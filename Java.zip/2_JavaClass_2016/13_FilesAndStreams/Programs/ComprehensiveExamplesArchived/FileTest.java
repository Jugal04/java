// demonstrates creating a file object

import java.io.*;

class FileTest{

public static void main(String[] args) throws IOException{
 
// creates a file object  but NOT a physical file in disk
// if the file is already present, then the file object is created using that file

          File f1 = new File("c:/kr/file1.txt"); 
          System.out.println(" file f1 exists " + f1.exists());

// creates a file in the disk
 
         f1.createNewFile(); // creates a file in the disk
         System.out.println(" file f1 exists " + f1.exists());  


// append = true; otherwise default is over write
  
          FileOutputStream fs = new FileOutputStream(f1,true); 
                                     




// While directly creating a file stream object, physical file automatically gets created

    File mf = new File("c:/kr/DataStream.bin");
    System.out.println(" file mf exists " + mf.exists());  

    FileOutputStream fos = new FileOutputStream(mf);
    System.out.println(" file mf exists  after fos creation " + f1.exists());  
    
    BufferedOutputStream bos = new BufferedOutputStream(fos);
    DataOutputStream dos = new DataOutputStream(bos);
  }
}


