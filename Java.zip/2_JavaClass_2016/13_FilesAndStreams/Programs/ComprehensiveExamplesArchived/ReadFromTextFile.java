import java.io.*;

public class ReadFromTextFile{

  public static void main(String[] args){
  
    String line = null;

  try{
 
        BufferedReader in = new BufferedReader(new FileReader("cusdata.txt"));

        while ((line = in.readLine()) != null)
             { 
               System.out.println(line);
             }

      }
        catch (IOException ex)
      {  System.out.println("Exception: " + ex);
         ex.printStackTrace ();
      }
   }
}







   