
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

/**
 * Program WriteOnFile.java which writes contents to the File
 */
public class WriteOnFile{
    static String line;
    static char[] cArray;
    public static void main(String args[]){
        try{
            File f = new File("C:/Mohan/SomeFile.txt");
            FileOutputStream fos=new FileOutputStream(f);
            OutputStreamWriter out = new OutputStreamWriter(fos);
            DataInputStream in = new DataInputStream(System.in);
            
            while(!(line=in.readLine()).equalsIgnoreCase("end")){
                cArray = (line).toCharArray();
                out.write(cArray);
                out.flush();
            }
            
            System.out.println("Written to file!");
            fos.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}