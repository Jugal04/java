import java.io.*;

class DataInputStreamDemo
{
  public static void main(String args[]) throws Exception
  {
     DataInputStream dis = new DataInputStream
                             (new BufferedInputStream
                             (new FileInputStream
                             ("C:/JunkData/DataStream.bin")));

     try
     {
	while(true)
	{
	   System.out.print(dis.readUTF() + "\t");
	   System.out.print(dis.readInt() + "\t");
           System.out.println(dis.readDouble());
	}
      }
      catch(Exception e)
      {
	 if (e instanceof EOFException)
         {
	    System.out.println("EOF reached");
	 }
      }
      finally
      {
	dis.close();
      }
  }
}
