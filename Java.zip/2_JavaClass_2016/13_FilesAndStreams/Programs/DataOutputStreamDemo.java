import java.io.*;

class DataOutputStreamDemo
{
  public static void main(String args[]) throws Exception
  {
    DataOutputStream dos = new DataOutputStream
                            (new BufferedOutputStream
                            (new FileOutputStream
                            ("C:/JunkData/DataStream.bin")));

    dos.writeUTF("Kumar");
    dos.writeInt(23);
    dos.writeDouble(5000.00);

    dos.writeUTF("Anand");
    dos.writeInt(26);
    dos.writeDouble(10000.00);

    dos.writeUTF("Kannan");
    dos.writeInt(13);
    dos.writeDouble(8000.00);

    dos.close();

    System.out.println("Successfully written to the file...");
  }
}
