import java.io.*;       // For input & output classes
import java.util.Date;  // For the Date class

public class FileDemo2
{
  public static void main(String[] args)
  {
    // Create an object that is a directory
    File myDir = new File("C:/class/java1class/exe");
    System.out.println("C:/class/java1class/exe" 
      + (myDir.exists()?" exists.":"doesn't exist.")); 
    System.out.println(myDir.getAbsolutePath()
      + (myDir.isDirectory()?" is ":" is not ") 
      + "a directory");
    System.out.println(myDir.getAbsolutePath()
      + (myDir.isFile()?" is ":" is not ") + "a file");


    // Get the contents of the directory
    File[] contents = myDir.listFiles();

    // List the contents of the directory
    if(contents!=null)
    {
      System.out.println("\nThe " + contents.length 
                  + " items in the directory "
                  + myDir.getName() + " are:");

      for(int i = 0; i < contents.length; i++)
      {
        System.out.println(contents[i] + " is a " 
          + (contents[i].isDirectory()?"directory":"file ") 
          + "\n  last modified " 
	  + new Date(contents[i].lastModified()));
      }
    }
    else
    {
      System.out.println(myDir.getName() 
	+ " is not a directory");
    }
    return;
  }
}
