import java.io.*;

class ReadConsole {

  public static void main(String args[]) {

    try {

      // Create an input stream reader
      InputStreamReader isr = 
        new InputStreamReader(System.in);

      // Create a buffered reader
      BufferedReader br = new BufferedReader(isr);


      OutputStreamWriter osw = 
        new OutputStreamWriter(System.out);

      // Create a buffered reader
      BufferedWriter bw = new BufferedWriter(osw);

      // Read and process lines from console
      String s;
      while((s = br.readLine()) != null) {
        bw.write(s.length()+"\t"+s);
      }

      // Close input stream reader
      isr.close();
      osw.close();
    }
    catch(Exception e) {
      System.out.println("Exception: " + e);
    }
  }
}
