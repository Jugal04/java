import java.io.*;
import java.util.zip.*;

class ReadZippedPrimes
{
  public static void main(String[] args)
  {
    try
    {

      String dirName = "c:\\Data";   
      String zipName = "Numbers.zip";  

      File myPrimeZip = new File(dirName, zipName);
      ZipInputStream myZipFile =
                new ZipInputStream
                (new FileInputStream
                (myNumbersZip));

      ZipEntry myZipEntry = myZipFile.getNextEntry();

      out.println("Compressed File is " + myZipEntry.getName());
      DataInputStream numbersIn =
                new DataInputStream
                (new BufferedInputStream
                (myZipFile));

      
      while(!EOF)
      {
        try
        {
          for(;;)
            System.out.println(numbersIn.readInt() + "\t");
        }
        catch(EOFException e)
        {
          EOF = true; 
        }
      }

      numbersIn.close();                  
    }
    catch(FileNotFoundException e)        
    {
      System.err.println(e);
      return;
    }
    catch(IOException e) 
    {
      System.out.println("Error reading input file" + e );
      return;
    }
  }
}
