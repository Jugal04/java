import java.io.*;
import java.util.*;

class SequenceInputStreamDemo
{
    public static void main(String[] args) throws Exception
    {
        int c;
        Vector files = new Vector();

        files.addElement(new FileInputStream(args[0]));
        files.addElement(new FileInputStream(args[1]));

        InputStream in = new SequenceInputStream(files.elements());

        while ((c=in.read()) != -1)
        {
            System.out.print((char) c);
        }

        in.close();
    }
}
