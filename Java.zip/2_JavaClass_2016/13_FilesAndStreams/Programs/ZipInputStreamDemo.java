import java.io.*;
import java.util.zip.*;

class ZipInputStreamDemo
{
  public static void main(String[] args)
  {
    try
    {

      String dirName = "c:\\JunkData";   
      String zipName = "Numbers.zip";  

      File myNumbersZip = new File(dirName, zipName);
      ZipInputStream myZipFile =
                new ZipInputStream
                (new FileInputStream
                (myNumbersZip));

      ZipEntry myZipEntry = myZipFile.getNextEntry();

      System.out.println
        ("Compressed File is " + myZipEntry.getName());

      DataInputStream numbersIn =
                new DataInputStream
                (new BufferedInputStream
                (myZipFile));

      
      while(true)
      {
        try
        {
          for(;;)
            System.out.print(numbersIn.readInt() + " ");
        }
        catch(EOFException e)
        { break;
        }
      }

      numbersIn.close();                  
    }
    catch(FileNotFoundException e)        
    {
      System.err.println(e);
      return;
    }
    catch(IOException e) 
    {
      System.out.println("Error reading input file" + e );
      return;
    }
  }
}
