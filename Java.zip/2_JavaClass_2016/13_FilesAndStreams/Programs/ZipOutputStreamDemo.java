import java.io.*;
import java.util.zip.*;

public class ZipOutputStreamDemo
{
  public static void main(String[] args)
  {
   
    // Write numbers 1 to 100 to the zip file

    try
    {
      String dirName = "c:\\JunkData";      
      String zipName = "Numbers.zip";     
      String fileName = "Numbers.bin";    
      File myNumbersDir = new File(dirName);

      if(!myNumbersDir.exists())              
        myNumbersDir.mkdir();                 
      else
        if(!myNumbersDir.isDirectory())
        {
          System.err.println(dirName + " is not a directory");
          return;
        }

      File myNumbersZip = new File(myNumbersDir, zipName);  
      myNumbersZip.createNewFile();                 

      ZipOutputStream myZipFile = 
			new ZipOutputStream
                (new FileOutputStream(myNumbersZip));

      ZipEntry myZipEntry = new ZipEntry(fileName); 
      myZipFile.putNextEntry(myZipEntry);

      DataOutputStream myFile = 
            new DataOutputStream
                (new BufferedOutputStream(myZipFile));
      
      for(int i = 1; i <= 20; i++)
        myFile.writeInt(i);

      myFile.flush();                     
      myZipFile.closeEntry();             
      myFile.close();                     
      System.out.println
        ("File size = " + myFile.size());
      System.out.println
        ("Compressed file size = " +
          myZipEntry.getCompressedSize());
    }
    catch(IOException e)                  
    {
      System.out.println("IOException " + e + " occurred");
    }
  }
}
