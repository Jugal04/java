// demonstrates the effect of calling run directly


class RunnableY implements Runnable
{
  public void run()
  {
    System.out.println(Thread.currentThread().getName()  + "   begins...");
    try
    {
      for (int i=1; i<=5; i++)
      {
        Thread.sleep(500);
        System.out.println("Hello from "+ Thread.currentThread().getName());
      }
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }
    System.out.println("End of "+ Thread.currentThread().getName() );
  }
}

class CallRunDirect
{

  public static void main(String args[])
  {
    System.out.println("Main thread begins...");
    RunnableY ry = new RunnableY(); 
    Thread t = new Thread(ry,"called by start");
    t.start();
    Thread t2 = new Thread(ry,"called by run");
    //t2.start();
    t2.run(); 
    

    System.out.println("End of Main thread");
  }
}
