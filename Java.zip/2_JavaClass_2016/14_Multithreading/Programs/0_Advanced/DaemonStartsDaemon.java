//shows what happens when a daemon thread tries to start a user thread

import java.io.IOException;

class UsThread extends Thread{

int name;

public void run(){
System.out.println("\n in UStHread");

}
}

class TryThread extends Thread
{
 private String firstname;
 private String secondname;
 private long aWhile;

 TryThread(){}

 TryThread(String firstname,String secondname,long msec)
 {
  this.firstname=firstname;
  this.secondname=secondname;
  this.aWhile=msec;
  setDaemon(true);
 }

// Method where thread execution will start
 public void run()
 {
  try
  {
   while(true)
   {
    System.out.print(firstname);
    sleep(aWhile);
    System.out.print(secondname + "\n");
    
    UsThread ut = new UsThread();
     ut.setDaemon(false);    // this being started by a Daemon, can never be                               // false . Will be reset to true
    System.out.print(isDaemon());  // prints true
     ut.start();
     
    
    
   }
  }

  catch(InterruptedException e)
  {
   System.out.println(firstname + secondname + e);
  }
}
}

public class DaemonStartsDaemon

{
 public static void main(String args[])
 {

  TryThread First = new TryThread("Hopolong","Cassidy",200L);
  TryThread Second = new TryThread("Marilyn","Monroe",300L);
  TryThread Third = new TryThread("Slim","Pickens",500L);

 
  First.start();
  Second.start();
  Third.start();
 
  try
  {
   System.out.println("Press Enter when you have had enough..");
   System.in.read();
   System.out.println("\n Enter pressed...");
  }
  catch(IOException e)
  {
   System.out.println(e);
  }

  System.out.println("\n Ending main()");
  return;
 }

 }


