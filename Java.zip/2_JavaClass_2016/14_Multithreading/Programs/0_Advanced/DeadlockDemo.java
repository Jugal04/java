class A
{
  B b;

  synchronized void a1()
  {
    System.out.println(Thread.currentThread().getName() + " has accquired a lock on A");
    System.out.println(Thread.currentThread().getName() + " is starting a1()");
    System.out.println(Thread.currentThread().getName() + " is trying to call b.b2()..");
    b.b2();
    System.out.println(Thread.currentThread().getName() + " is releasing a lock on A");
  }

  synchronized void a2()
  {
    System.out.println(Thread.currentThread().getName() + " has accquired a lock on A");
    System.out.println(Thread.currentThread().getName() + " is starting a2()");
    System.out.println(Thread.currentThread().getName() + " is releasing a lock on A");
  }
}

class B
{
  A a;
 
  synchronized void b1()
  {
    System.out.println(Thread.currentThread().getName() + " has accquired a lock on B");
    System.out.println(Thread.currentThread().getName() + " is starting b1()");
    System.out.println(Thread.currentThread().getName() + " is trying to call a.a2()..");
    a.a2();
    System.out.println(Thread.currentThread().getName() + " is releasing a lock on B");
  }

  synchronized void b2()
  {
    System.out.println(Thread.currentThread().getName() + " has accquired a lock on B");
    System.out.println(Thread.currentThread().getName() + " is starting b2()");
    System.out.println(Thread.currentThread().getName() + " is releasing a lock on B");
  }
}

class Thread1 extends Thread
{
  A a;

  Thread1(A a, String name)
  {
    super(name);
    this.a = a;
  }
  
  public void run()
  {
    for(int i = 0; i < 10; i++)
      a.a1();
  }
}

class Thread2 extends Thread
{
  B b;

  Thread2(B b, String name)
  {
    super(name);
    this.b = b;
  }
  
  public void run()
  {
    for(int i = 0; i < 10; i++)
      b.b1();
  }
}

class DeadlockDemo
{
  public static void main(String args[])
  {
 
    // Create objects
    A a = new A();
    B b = new B();
    a.b = b;
    b.a = a;

    // Create threads
    Thread1 t1 = new Thread1(a, "Thread 1");
    Thread2 t2 = new Thread2(b, "Thread 2");
    t1.start();
    t2.start();

    // Wait for threads to complete
    try
    {
      t1.join();
      t2.join();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // Display message
    System.out.println("Done!");
  }
}
       
