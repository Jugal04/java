class Producer extends Thread
{
  Queue queue;

  Producer(Queue queue)
  {
    super("Producer");
    this.queue = queue;
  }

  public void run()
  {
    int i = 0;
    while(true)
    {
      
      queue.add(i++);
    }
  }
}

class Consumer extends Thread
{
  String name;
  Queue queue;

  Consumer(String name, Queue queue)
  {
    super(name);
    this.name = name;
    this.queue = queue;
  }

  public void run()
  {
    while(true)
    {
      System.out.println(name + ": " + queue.remove());
    }
  }
}

class Queue
{
  private final static int SIZE = 10;
  int array[] = new int[SIZE];

  int r = 0;
  int w = 0;
  int count = 0;
  
  synchronized void add(int i)
  {

    // Wait while the queue is full
    while(count == SIZE)
    {
      try
      {
        System.out.println(Thread.currentThread().getName() + " is entering into wait state" );
        System.out.flush();
        wait();
        System.out.println(Thread.currentThread().getName() + " is entering into running state" );
        System.out.flush();
      }
      catch(InterruptedException ie)
      {
        ie.printStackTrace();
        System.exit(0);
      }
    }

    // Add data to array and adjust write pointer
    System.out.println(Thread.currentThread().getName() + " is adding the number " + i + " to the queue " );
    array[w++] = i;
    if(w >= SIZE)
      w = 0;

    // Increment count
    ++count;

    // Notify waiting threads
    notify();
  }

  synchronized int remove()
  {

    // Wait while the queue is empty
    while(count == 0)
    {
      try
      {
        System.out.println(Thread.currentThread().getName() + " is entering into wait state" );
        wait();
        System.out.println(Thread.currentThread().getName() + " is entering into running state" );
      }
      catch(InterruptedException ie)
      {
        ie.printStackTrace();
        System.exit(0);
      }
    }

    // Read data from array and adjust read pointer
    System.out.println(Thread.currentThread().getName() + " is removing a number from the queue " );
    int element = array[r++];
    if(r >= SIZE)
      r = 0;

    // Decrement count
    --count;

    // Notify waiting threads
    notify();

    // Return element from array
    return element;
  }
}

class ProducerConsumers
{
  public static void main(String args[])
  {
    Queue queue = new Queue();
    new Producer(queue).start();
    new Consumer("Consumer-A", queue).start();
    new Consumer("Consumer-B", queue).start();
  }
}
