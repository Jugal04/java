//demonstartes how two threads of the same object take turns to execute


class ReadWrite implements Runnable{
   public void run(){

     for (int i=0;i<=10;i++){     

     // String runningThread = Thread.currentThread().getName();
     // System.out.println("Now Running " + runningThread);

      if(runningThread.equals("Read")){

         System.out.println("Reading");
         try{
            Thread.sleep(1000);
          }
         catch(InterruptedException e){
          }
    }
else{

   System.out.println("writing");
    try{
   Thread.sleep(1000);
   }
   catch(InterruptedException e){
   } 
  }         
}                    

}

}

class ReadWriteDemo {
public static void main(String args[]) throws Exception{

ReadWrite rw = new ReadWrite();

Thread ReadingThread = new Thread(rw, "Read");

Thread WritingThread = new Thread(rw, "Write");


ReadingThread.start();
WritingThread.start();

//System.in.read();
}
}



