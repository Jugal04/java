class ThreadX extends Thread
{

  ThreadX(String str)
   {
     super(str);
   }
  public void run()
  {
    System.out.println( Thread.currentThread().getName() +
       " begins...");


      for (int i=0; i<=10000000; i++);
    
   /*   for (int i=1; i <=5; i++)
      {
        try
        {              
        Thread.sleep(1000);   
        }

       catch(InterruptedException e)
       {
        e.printStackTrace();
       }                            
      }

  */
  
    System.out.println("End of Thread " + Thread.currentThread().getName());
  }
}

class NoSleepDemo
{
  public static void main(String args[])
  {
    System.out.println("Main thread begins...");
    ThreadX tx = new ThreadX("thread 1");
    ThreadX ty = new ThreadX("thread 2");
    ThreadX tz = new ThreadX("thread 3");
    tx.start();
    ty.start();
    tz.start(); 
    System.out.println("End of Main thread");
  }
}
