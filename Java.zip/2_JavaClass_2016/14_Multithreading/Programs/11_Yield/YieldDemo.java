/************************************************************************************************************************

Use of The Yield() method Vs sleep() method
--------------------------------------------

- sleep(n) allows the thread to be taken out of the processor for n milliseconds. 

- This will happen, even if no other threads are waiting for processor time 

- But yield() will give up processor time only if another thread is waiting and if its priority is equal to or greater than   its (the current thread where yield() is encountered) priority 

***************************************************************************************************************************/

// YieldDemo.java


class ThreadX extends Thread
{

  ThreadX(String str)
   {
     super(str);
   }
  public void run()
  {
    System.out.println( Thread.currentThread().getName() +
       " begins...");
    
      for (int i=1; i <=5; i++)
      {
        for (int j=0;j<=10000000; j++);
              
        Thread.yield();                               
      }
    
    System.out.println("End of Thread " + Thread.currentThread().getName());
  }
}

class YieldDemo
{
  public static void main(String args[])
  {
    System.out.println("Main thread begins...");
    ThreadX tx = new ThreadX("thread 1");
    ThreadX ty = new ThreadX("thread 2");
    ThreadX tz = new ThreadX("thread 3");
    tx.start();
    ty.start();
    tz.start(); 
    System.out.println("End of Main thread");
  }
}
