/***************************************************************************************************************************

                                       Thread Creation  


What is multithreading 
----------------------

- In multi tasking, multiple instances of the same program, have their own data areas.
 
  ie., they operate in their own address space 

  (e.g) Executing different programs in different windows simultaneously 


- When multiple instances of the the same program (or part of the same program) execute 
  simultaneously sharing the same data area, then it is called Multi threading. 

- Such individual instances are called Threads of control or simply Threads. 


How to create a multithreaded program
---------------------------------------

- Your class should inherit Thead class, to exhibit threaded behaviour. 

- Alternatively, you can also pass an object of a class which implements 
  the Runnable interface to the the constructor of the Thread class 

- Should over ride the inheriterd run() method in both the cases. 

****************************************************************************************************************************/

// Program illustrationg Thread creation 


import java.io.IOException;

class MyThread extends Thread
{
 private String firstname;
 private String secondname;
 private long aWhile;

 MyThread(){}

 MyThread(String firstname,String secondname,long msec)
 {
  this.firstname=firstname;
  this.secondname=secondname;
  this.aWhile=msec;
  setDaemon(true);
 }

// Method where thread execution will start
 public void run()                      //diagram to illustrate
 {
  try
  {
   while(true)
   {
    System.out.print(firstname);     
    sleep(aWhile);
    System.out.print(secondname + "\n");
    
   }
  }

  catch(InterruptedException e)
  {
   System.out.println(firstname + secondname + e);
  }
}
}

public class MyThreadDemo

{
 public static void main(String args[])
 {

  MyThread first = new MyThread("Shankar","Ram",200L);
  MyThread second = new MyThread("Nancy","Reagen",300L);
  MyThread third = new MyThread(" Reubon","Moses",500L);

 
  first.start();
  second.start();
  third.start();
 
 
  try
  {
   System.out.println("Press Enter when you have had enough..");
    
   System.in.read();
   System.out.println("\n Enter pressed...");
  }
  catch(IOException e)
  {
   System.out.println(e);
  }

  System.out.println("\n Ending main()");
 
 }

 }

/*************************************************************************************************************************

Code Analysis 
-------------

- class MyThread extends Thread defines a Threadable class by extending the Thread Class 

- MyThread(){} provides the default constructor 

- MyThread(String firstname,String secondname,long msec) is a user defined constructor which accept the first and second   names as well as the msec which will be used by the sleep() method. 

- setDaemon(true) defines the thread as a daemon thread, i.e., a Slave thread. A daemon thread is always subordinate to the   thread which started it and will die as soon as its parent thread completes. 

- The other type of thread is called user thread. 

- A user thread continues to execute even after the thread which started it ends. 

- If you dont specify setDaemon(true), the thread will be a user thread. 

  i.e., A thread is a user thread by default. 

- Also, all threads created by a daemon thread will also be daemon threads. 

- A daemon thread cannot create a user thread. 

- public void run() is the first method to be called when you start a thread. 

- sleep(aWhile) enables the thread to be taken out of the processor for aWhile milliseconds. 

- When this happens, any waiting thread will execute. 

- sleep()is a static method of the Thread class which has been inherited by our MyThread class. 

- catch(InterruptedException e) catches the interrupted exception likely to be thrown by the sleep() method, in case our   thread is interrupted. 


- public class MyThreadDemo is the client application which creates and uses the threads. 

- MyThread First = new MyThread("Hopolong","Cassidy",200L); etc., creates the threads. 

- First.start(); Second.start(); Third.start(); starts these threads one by 
  one. 

- The start method in turn will invoke the run method defined in the MyThread class. 

- Also , please note that the start() method, only schedules a call to the O/S through JVM to start the thread. It is left to   the scheduler to actually prioritize and start the the thread. In other words, the start() method will return immediately. 


- System.in.read() waits for the keyboard input from the user. 

- Its like your getch()of c. main()which is also considered a thread is now held 
  back from proceeding, while the other two threads are executing. 


- Main will resume only when you press any key. 


-Question 

- The output of the above code will have the first and second names mixed up. Try to find out why. 

****************************************************************************************************************************/
