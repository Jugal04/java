/*************************************************************************************************************************
  Thread Creation with Runnable Object 

  Creates a thread object by passing a runnable object (object of a class which implements Runnable Interface) to the   constructor of Thread (class) 

  Since there is no need to extend the Thread class, you have the advantage of extending some other useful class for the   desired functionality 

  ThreadDemo2.java 

*************************************************************************************************************************/


class RunnableY implements Runnable
{
  public void run()
  {
    System.out.println("Child thread begins...");
    try
    {
      for (int i=1; i<=5; i++)
      {
        Thread.sleep(500);
        System.out.println("Hello");
      }
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }
 
   System.out.println("End of Child thread");
  }
}

class ThreadDemo2
{
  public static void main(String args[])
  {
    System.out.println("Main thread begins...");
    RunnableY ry = new RunnableY(); 
    Thread t = new Thread(ry);
    t.start();
    System.out.println("End of Main thread");
  }
}
