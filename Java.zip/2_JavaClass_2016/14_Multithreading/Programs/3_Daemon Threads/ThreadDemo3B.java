/************************************************************************************************************************

Daemon Threads 
---------------

- Daemon Threads are slave threads. 

- They are subordinates of the thread which started them. 

- When the parent thread dies, the daemon thread also dies. 

- Daemon Thread do not have any exitance after the thread which started it dies / completes. 

- Any thread started by a Daemon Thread will also be a Daemon Thread. 


How to specify a Daemon Thread 
-------------------------------

- By invoking the setDaemon() method of the Thread class either in your class definition itself 
  Or invoking the setDaemon() method with the instance of the class 

- invoking  the setDaemon() with the thread class instance is the only option, if you have created your Thread object using Runnable object. 

*************************************************************************************************************************/

// ThreadDemo3B.java 



class MyThread3 extends Thread
{
  String str;
  long msec;

  MyThread3(String str, long msec)
  {
    this.str = str;
    this.msec = msec;
  }
  
  public void run()
  {
    System.out.println("Thread "+str+ " begins...");
    try
      {
        for(int j=1; j<=10; j++){

        System.out.println(str+j);
      
        Thread.sleep(msec);
       
      }
   }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }
    System.out.println("End of Thread "+str);
  }
}

class ThreadDemo3B
{
  public static void main(String args[])
  {
    System.out.println("Main thread begins...");
    MyThread3 ta = new MyThread3("A", 1000);
    MyThread3 tb = new MyThread3("B", 2000);
 //   ta.setDaemon(true);
    tb.setDaemon(true);
    ta.start();
    tb.start();

   try{

    System.in.read();
}
  catch(Exception e){}

  

    System.out.println("End of Main thread");
  }
}
