/**************************************************************************************************************************

Creating a User Thread 
-------------------------

- Unlike a Daemon thread, a User Thread can continue to run, even after the thread that started it dies. 

- A thread unless specified other wise, is a user thread. 

- main() is always a user thread by default 

**************************************************************************************************************************/

// ThreadDemo3A.java 


class MyThread3 extends Thread
{
  String str;
  long msec;

  MyThread3(String str, long msec)
  {
    this.str = str;
    this.msec = msec;
  }
  
  public void run()
  {
    System.out.println("Thread "+str+ " begins...");
    try
    {
     
         for (int j=1;j<=30;j++){
           System.out.println(str+j);
            Thread.sleep(msec);
         }
            
      
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }
    System.out.println("End of Thread "+str);
  }
}

class ThreadDemo3A
{
  public static void main(String args[])
  {
    System.out.println("Main thread begins...");
    MyThread3 ta = new MyThread3("A", 1000);
    MyThread3 tb = new MyThread3("B", 2000);
    ta.start();
    tb.start();
    System.out.println("End of Main thread");
  }
}

