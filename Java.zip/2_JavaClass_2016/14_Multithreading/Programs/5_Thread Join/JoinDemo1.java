class ThreadM extends Thread
{
  public void run()
  {

    System.out.println("ThreadM beings...");

    try
    {
      for(int i = 0; i < 2; i++)
      {
        Thread.sleep(1000);
        System.out.println("ThreadM");
      }
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }

    System.out.println("End of ThreadM");
  }
}

class ThreadN extends Thread
{
  public void run()
  {
    System.out.println("ThreadN beings...");

    try
    {
      for(int i = 0; i < 2; i++)
      {
        Thread.sleep(2000);
        System.out.println("ThreadN");
      }
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }

    System.out.println("End of ThreadN");
  }
}

class JoinDemo1
{
  public static void main(String args[]) throws Exception
  {
    System.out.println("Main thread begins...");

    ThreadM tm = new ThreadM();
    tm.start();
   
    ThreadN tn = new ThreadN();
    tn.start();

    try
    {
      tm.join();
    tn.join();
                 //tn.join(1000);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    System.out.println("End of Main thread");
  }
}
