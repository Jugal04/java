class ThreadN extends Thread{
	public void run() {
    		System.out.println("ThreadN beings...");
		for(int j=0;j<100;j++){
   			 try {
                  		        for (int  i=0;i<5;i++){
       				 if (Thread.interrupted()) {
           					 System.out.println(" ThreadN interrupted");
            					 throw new InterruptedException();
            					}
       				}
              
               			        SetCountCheckCount.count++;
               			        System.out.println(" I am tn - count = " + SetCountCheckCount.count);
                                                        sleep(2000); 
                                                        for(int k=0;k<10000;k++);
                                                        sleep(1000);
                                                        for(int k1=0;k1<10000;k1++);
 			        sleep(1000);
            			      }
    
    			catch(InterruptedException ex){
      			       System.out.println(" I am tn, count is now " +  SetCountCheckCount.count  +" I have been interrupted,so  returning");
     			       return; 
    			}
		}
    	System.out.println("End of ThreadN count = " +  SetCountCheckCount.count);
         }
}

class SetCountCheckCount{
	public static int  count=0;
  		public static void main(String args[]) throws Exception{
		System.out.println("Main thread begins...");
		ThreadN tn = new ThreadN();
		tn.start();
   		Thread.sleep(4000);
  		                                 for(;;){
                                               System.out.println(" 			I am main count = " + count);
                                               Thread.sleep(5000);
   		 	if(count >10){
				     System.out.println(" 			I am main count = " + count  +  " so interrupting the thread tn");
           				     tn.interrupt();
                                                	     break;
    				}
                              
                             }
                                System.out.println("		count =" +  count);
		System.out.println("End of Main thread");
  }
}
