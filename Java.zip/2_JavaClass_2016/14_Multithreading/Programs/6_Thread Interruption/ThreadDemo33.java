class MyThread3A extends Thread
{
  long msec;

  MyThread3A(String str, long msec)
  {
    super(str);
    this.msec = msec;
  }
  
  public void run()
  {
      System.out.println(Thread.currentThread().getName() + " begins...");

      for(int i=1; i<=5; i++)
      {
        if (Thread.interrupted())
        {
            System.out.println("Stopping " + Thread.currentThread().getName() + "...");
           
            
            return;
        }
        else
        {
            try
            {
                Thread.sleep(msec);
            }
            catch(InterruptedException ie)
            {
                System.out.println(Thread.currentThread().getName() + " has been interrupted..."); 
                for(int j=0;j<100000;j++);
                return;             
            }
            System.out.println("Message from " + Thread.currentThread().getName());
        }
      }
      System.out.println("End of " + Thread.currentThread().getName());
  }
}


class MyThread3B extends Thread
{

  MyThread3B(String str)
  {
    super(str);
  }
  
  public void run()
  {
      System.out.println(Thread.currentThread().getName() + " begins...");

      for(int i=1; i<=5000; i++)
      {
        if (Thread.interrupted())
        {
            System.out.println("Thread.interrupted() = true , so  Stopping " + Thread.currentThread().getName() + "...");
            return;
        }
        else
        {
            for (int j=1; j<=10000; j++) {}

            System.out.println("Message from " + Thread.currentThread().getName());
        }
      }
      System.out.println("End of " + Thread.currentThread().getName());
  }
}



class ThreadDemo33
{
  public static void main(String args[])
  {
    System.out.println("Main thread begins...");

    MyThread3A ta = new MyThread3A("Thread 3A", 10000);
    MyThread3B tb = new MyThread3B("Thread 3B");
    
    ta.start();
    tb.start();
    

    try
    {
        System.out.println("Press ENTER to stop the Main thread...");
        System.in.read();

        ta.interrupt();
    
        tb.interrupt();
  
        System.out.println("ta has been interrupted " + ta.isInterrupted());
        System.out.println("tb has been interrupted " + tb.isInterrupted());


    }
    catch(Exception e)
    {
        e.printStackTrace();
    }

    System.out.println("End of Main thread");
 
  }
}
