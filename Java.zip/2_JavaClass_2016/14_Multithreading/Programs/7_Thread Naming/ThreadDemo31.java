class MyThread3 extends Thread
{
  long msec;

  MyThread3(String str, long msec)
  {
    super(str);
    this.msec = msec;
  }
  
  public void run()
  {
    System.out.println(Thread.currentThread().getName() + " begins...");
    try
    {
      for (int i=1; i<=5; i++)
      {
        Thread.sleep(msec);
        System.out.println("Message from " + Thread.currentThread().getName());
      }
    }
    catch(InterruptedException ex)
    {
      System.out.println(Thread.currentThread().getName() + " has been interrupted...");
    }
    System.out.println("End of " + Thread.currentThread().getName());
  }
}

class ThreadDemo31
{

  public static void main(String args[])
  {
    System.out.println("Main thread begins...");

    MyThread3 ta = new MyThread3("Thread A", 1000);
    MyThread3 tb = new MyThread3("Thread B", 3000);

    ta.start();
    tb.start();

    try
    {
        System.out.println("Press ENTER to stop the Main thread...");
        System.in.read();
        System.out.println("ENTER has been pressed...");

        ta.interrupt();
        tb.interrupt();
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    System.out.println("End of Main thread");
  }
}
