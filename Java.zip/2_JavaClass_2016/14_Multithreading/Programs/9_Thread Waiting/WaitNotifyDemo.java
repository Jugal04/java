// demontrates inter-thread communication

import java.io.*;

class Account{
	public int balance = 2000;
	synchronized void withdraw(int amount){
		boolean proceedWithwithdrawal = false; 
		while(proceedWithwithdrawal== false){ 
			try{
				if (getBalance() <= amount){
					System.out.println("\n\n balance =  Rs."+getBalance() + " withdrawal amt =   Rs."+amount + " so waiting for deposit");
					wait();
                     				continue;
                     			}		
 			}
			catch(InterruptedException ie){
                      		ie.printStackTrace();
                  		 } 
                              		proceedWithwithdrawal= true;
 		} 
              		setBalance(getBalance() - amount); 
  	}

	synchronized void deposit(int amount){
		System.out.println("\n depositing " + amount);
		setBalance(getBalance() + amount);
		notifyAll(); 
	}
   
	int getBalance(){
		return balance;
	}

  	void setBalance(int amount){
       		balance = amount;
 	 }
}

class JointHolder extends Thread{ 
	Account account;
	JointHolder(Account account, String name){
		super(name);
		this.account = account;
	}

	public void run(){
		String runningThread = currentThread().getName();
			if (runningThread.equals("jh1")){
				account.withdraw(3000);
			}
 			else{
     				account.deposit(5000);

 			}
 	}

}

class WaitNotifyDemo{
	public static void main(String args[]) throws IOException, InterruptedException{
		Account account = new Account();
		JointHolder jh1 = new JointHolder(account,"jh1");
		JointHolder jh2 = new JointHolder(account,"jh2");
		jh1.start();
		jh2.start(); 
		jh1.join();
		jh2.join(); 
		System.out.println("\nThe final balance after withdrawal = Rs. " +account.getBalance());

		}
}

