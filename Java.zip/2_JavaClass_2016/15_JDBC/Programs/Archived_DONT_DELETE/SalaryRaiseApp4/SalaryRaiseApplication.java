import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class SalaryRaiseFrame extends JFrame 
   implements ActionListener
{
    private Connection con;
    private CallableStatement callStat;

    private JTextField txtEmpName;
    private JTextField txtSalRaise;
    private JTextField txtSalAfterRaise;

    SalaryRaiseFrame()
    {
        String url   = "jdbc:odbc:deOracle";
                         
        try
        {
            Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection (url, "scott", "tiger");

            /* callStat = con.prepareCall("{?=call f_sal_raise_2(?,?)}");
             callStat.registerOutParameter(1, java.sql.Types.DOUBLE);
            */

         callStat = con.prepareCall("{call SalRaiseProcedure(?,?)}");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        String  plaf = 
           "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
        try
        {  UIManager.setLookAndFeel(plaf);
            SwingUtilities.updateComponentTreeUI(this);
        }
        catch(Exception e) {e.printStackTrace();}

        addWindowListener(new WindowAdapter()
	{    public void windowClosing(WindowEvent e)
	     {
	           System.exit(0);
	     }
	});

         getContentPane().setLayout(new GridBagLayout());

        JLabel lblEmpName = new JLabel("EMP. NAME: ");
        JLabel lblSalRaise = new JLabel("SAL. RAISE: ");
        JLabel lblSalAfterRaise = new JLabel("SAL. AFTER RAISE: ");

        txtEmpName = new JTextField(10);
        txtSalRaise = new JTextField(10);
        txtSalAfterRaise = new JTextField(10);
        txtSalAfterRaise.setEditable(false);

        JButton btnCalSal = new JButton("Calcualte Salary");

        btnCalSal.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = 100;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST; 

        add(lblEmpName, gbc, 0, 0, 1, 1);
        add(lblSalRaise, gbc, 0, 1, 1, 1);
        add(lblSalAfterRaise, gbc, 0, 2, 1, 1);

        gbc.fill = GridBagConstraints.HORIZONTAL;

        add(txtEmpName, gbc, 1, 0, 1, 1);
        add(txtSalRaise, gbc, 1, 1, 1, 1);
        add(txtSalAfterRaise, gbc, 1, 2, 1, 1);

        gbc.fill = GridBagConstraints.VERTICAL;

        add(btnCalSal, gbc, 2, 0, 1, 3);

        txtEmpName.setNextFocusableComponent(txtSalRaise);
        txtSalRaise.setNextFocusableComponent(txtSalAfterRaise);
        txtSalAfterRaise.setNextFocusableComponent(btnCalSal);
        
        txtEmpName.requestFocus();
    }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      getContentPane().add(c, gbc);
   }

    public void actionPerformed(ActionEvent ae)
    {
        try
        {
             callStat.setString(1, txtEmpName.getText());
	callStat.setInt(2, Integer.parseInt(txtSalRaise.getText()));
						
	float rval = callStat.executeUpdate();

	 /*if (rval == -1)
	{
	    double res = callStat.getDouble(1);						
	    txtSalAfterRaise.setText(""+res);
             }
        }
         */
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void dispose()
    {
        try
        { 
            callStat.close();
            con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}

public class SalaryRaiseApplication
{
    public static void main(String[] args)
    {
        JFrame frame = new SalaryRaiseFrame();
        frame.setTitle("Application to Raise Salary");
        frame.pack();
        frame.show();       
    }
}