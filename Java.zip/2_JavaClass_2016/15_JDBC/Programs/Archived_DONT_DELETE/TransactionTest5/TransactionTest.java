import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class TransactionsFrame extends JFrame implements ActionListener
{
    private Connection con;
    private PreparedStatement prepStat;
    private Statement  stat;

    JTextField txtDeptNo;
    JTextField txtDeptName;
    JTextField txtLoc;
    JTextArea txtStatus;
    
    JButton btnAdd;
    JButton btnQuery;
    JButton btnUpdate;
    JButton btnDelete;

    JButton btnSave;
    JButton btnCancel;
    JButton btnExit;

    JButton btnCommit;    
    JButton btnRollback;   

    TransactionsFrame()
    {
   String  plaf = 
    "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
      try
      {  UIManager.setLookAndFeel(plaf);
         SwingUtilities.updateComponentTreeUI(this);
      }
      catch(Exception e) {e.printStackTrace();}

       addWindowListener(new WindowAdapter()
	{    public void windowClosing(WindowEvent e)
	     {
	           System.exit(0);
	     }
	});

       String url   = "jdbc:odbc:deOracle";
                 
       try 
       {
            Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection (url, "scott", "tiger");
            prepStat = con.prepareStatement("INSERT INTO DEPT(DEPTNO, DNAME,LOC) VALUES(?, ?, ?)");
            stat = con.createStatement();
       }
       catch(Exception e) 
       {
            e.printStackTrace();
       }
     
      Container container = getContentPane();
      
      JPanel topPanel = new JPanel();
      JPanel centerPanel = new JPanel();
      JPanel bottomPanel = new JPanel();

      centerPanel.setLayout(new GridBagLayout());

       JLabel lblDeptNo = new JLabel("DEPTNO: ");
       JLabel lblDeptName = new JLabel("DNAME: ");
       JLabel lblLoc = new JLabel("LOC: ");

       txtDeptNo = new JTextField(2);
       txtDeptName = new JTextField(14);
       txtLoc = new JTextField(13);
       
        btnAdd = new JButton("Add");
        btnQuery = new JButton("Query");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");

        btnSave = new JButton("Save");
        btnCancel = new JButton("Cancel");
        btnExit = new JButton("Exit");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = 100;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST; 

        add(centerPanel, lblDeptNo, gbc, 0, 1, 1, 1);
        add(centerPanel, lblDeptName, gbc, 0, 2, 1, 1);
        add(centerPanel, lblLoc, gbc, 0, 3, 1, 1);
      
        gbc.fill = GridBagConstraints.HORIZONTAL;

        add(centerPanel, txtDeptNo, gbc, 1, 1, 1, 1);
        add(centerPanel, txtDeptName, gbc, 1, 2, 1, 1);
        add(centerPanel, txtLoc, gbc, 1, 3, 1, 1);
     
        add(centerPanel, btnAdd, gbc, 2, 0, 1, 1);
        add(centerPanel, btnQuery, gbc, 2, 1, 1, 1);
        add(centerPanel, btnUpdate, gbc, 2, 2, 1, 1);
        add(centerPanel, btnDelete, gbc, 2, 3, 1, 1);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout());

        add(buttonPanel, btnSave, gbc, 0, 0, 1, 1);
        add(buttonPanel, btnCancel, gbc, 1, 0, 1, 1);
        add(buttonPanel, btnExit, gbc, 2, 0, 1, 1);

        add(centerPanel, buttonPanel, gbc, 0, 4, 3, 1);

        btnAdd.addActionListener(this);
        btnQuery.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);

        btnSave.addActionListener(this);
        btnCancel.addActionListener(this);
        btnExit.addActionListener(this);

        container.add(centerPanel, BorderLayout.CENTER);
        
        JLabel lbl = new JLabel("Managing Database Transactions");
        lbl.setFont(new Font("Courier", Font.BOLD, 16));
        topPanel.add(lbl);

        container.add(topPanel, BorderLayout.NORTH);

       JLabel lblStatus = new JLabel("Status: ");
       txtStatus = new JTextArea(1, 20);
       txtStatus.setEditable(false);
       btnCommit = new JButton("Commit");
       btnRollback = new JButton("Rollback");
    
       bottomPanel.setLayout(new GridBagLayout());
       gbc.weightx = 100;
       gbc.weighty = 0;

      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST; 
      add(bottomPanel, lblStatus, gbc, 0, 0, 1, 1);

      gbc.fill = GridBagConstraints.HORIZONTAL;

      add(bottomPanel, new JScrollPane(txtStatus), gbc, 1, 0, 1, 2);
      add(bottomPanel, btnCommit, gbc, 2, 0, 1, 1);
      add(bottomPanel, btnRollback, gbc, 3, 0, 1, 1);
	
      btnCommit.addActionListener(this);
      btnRollback.addActionListener(this);

       container.add(bottomPanel, BorderLayout.SOUTH);

      txtDeptNo.setNextFocusableComponent(txtDeptName);
      txtDeptName.setNextFocusableComponent(txtLoc);  
      txtLoc.setNextFocusableComponent(btnAdd);  
      btnAdd.setNextFocusableComponent(btnQuery);  
      btnQuery.setNextFocusableComponent(btnSave);  
      btnSave.setNextFocusableComponent(btnCancel);  
      btnCancel.setNextFocusableComponent(btnExit);  
      btnExit.setNextFocusableComponent(btnCommit);    
      btnCommit.setNextFocusableComponent(btnRollback); 
	
      makeNormal();

      disableCommitRollback();

      try
      {
      	con.setAutoCommit(false);
      }
      catch(Exception e)
      {
	JOptionPane.showMessageDialog(this, " Transaction Processing Can't be Enabled", "System Error ", JOptionPane.INFORMATION_MESSAGE);    				
	System.exit(0);   
      }
    }

   public void add(Container ctr, Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      ctr.add(c, gbc);
   }
   
   public void actionPerformed(ActionEvent ae)
   {
       if (ae.getActionCommand().equals("Add"))
       {
	processAdd();
       }
       else if (ae.getActionCommand().equals("Query"))
       {
	try
	{	
	    displayData();
	}
	catch(Exception e)
	{
	    e.printStackTrace();
	}
       }
       else if (ae.getActionCommand().equals("Save"))
       {
          try
          {
	insertData();
             makeNormal();
             enableCommitRollback();
          }
          catch(Exception e)
          {
	    JOptionPane.showMessageDialog(this, "Save not succeeded...", "Operational Error ", JOptionPane.INFORMATION_MESSAGE);    			
          }
       }
       else if (ae.getActionCommand().equals("Cancel"))
       {
	makeNormal();
       }
       else if (ae.getActionCommand().equals("Exit"))
       {
	System.exit(0);
       }
       else if (ae.getActionCommand().equals("Commit"))
       {
	try
             {
	    con.commit();
             }
	catch(Exception e)
	{
	    JOptionPane.showMessageDialog(this, "Commit not succeeded...", "Transactional Error ", JOptionPane.INFORMATION_MESSAGE);    		
	}        
             makeNormal();
	disableCommitRollback();
       }
       else
       {
	try
             {
	    con.rollback();
             }
	catch(Exception e)
	{
	    JOptionPane.showMessageDialog(this, "Rollback not succeeded...", "Transactional Error", JOptionPane.INFORMATION_MESSAGE);    		
	}        
             makeNormal();
	disableCommitRollback();
       }
   }

    public void makeNormal()
    {
        clearTextFields();
        disableTextFields();
        enableAQUD();
        disableSaveCancel();
        txtStatus.setText("NORMAL MODE");
    }

    public void enableTextFields()
    {
        txtDeptNo.setEditable(true);
        txtDeptName.setEditable(true);
        txtLoc.setEditable(true);
    }

    public void disableTextFields()
    {
        txtDeptNo.setEditable(false);
        txtDeptName.setEditable(false);
        txtLoc.setEditable(false);
    }

    public void clearTextFields()
    {
        txtDeptNo.setText("");
        txtDeptName.setText("");
        txtLoc.setText("");
    }

    public void enableAQUD()
    {
       btnAdd.setEnabled(true);
       btnQuery.setEnabled(true);
       btnUpdate.setEnabled(true);
       btnDelete.setEnabled(true);
    }

    public void disableAQUD()
    {
       btnAdd.setEnabled(false);
       btnQuery.setEnabled(false);
       btnUpdate.setEnabled(false);
       btnDelete.setEnabled(false);
     }

    public void enableSaveCancel()
    {
       btnSave.setEnabled(true);
       btnCancel.setEnabled(true);
    }

    public void disableSaveCancel()
    {
       btnSave.setEnabled(false);
       btnCancel.setEnabled(false);
     }

    public void enableCommitRollback()
    {
       btnCommit.setEnabled(true);
       btnRollback.setEnabled(true);
    }

    public void disableCommitRollback()
    {
       btnCommit.setEnabled(false);
       btnRollback.setEnabled(false);
     }

    public void processAdd()
    {
        enableTextFields();
        disableAQUD();
        enableSaveCancel();
        txtStatus.setText("ADD MODE");
        txtDeptNo.requestFocus();
    }

    public void displayData() throws SQLException
    {
       String[] columnTitles = {"DEPTNO", "DNAME", "LOCATION"};
       Object[][] rowData;
    
      ResultSet results = stat.executeQuery("SELECT * FROM DEPT");

       int rowCount = 0;
       boolean more = results.next ();
       while (more) 
       {
           rowCount++;
           more = results.next ();        
       }
       results.close();

       results = stat.executeQuery("SELECT * FROM DEPT");
      
      rowData = new Object[rowCount][3];

      results.next();
      for (int row = 0; row < rowCount; row++)
      {
            for (int col=0; col<3; col++) 
            {
	    {
	        rowData[row][col] =  results.getString(col+1);
	    }
	}
	results.next();
       }
       results.close();

     TableDialog.show(this, rowData, columnTitles, "Query Result", "Select a Row and then click OK");
   }
    
    public void insertData() throws SQLException
    { 
	prepStat.setInt(1, Integer.parseInt(txtDeptNo.getText()));     
	prepStat.setString(2, txtDeptName.getText());     
	prepStat.setString(3, txtLoc.getText());     
             int result = prepStat.executeUpdate();

             if (result == 1)
             {
	    JOptionPane.showMessageDialog(this, "Reocrd Successfully Inserted...", "Saving a Record", JOptionPane.INFORMATION_MESSAGE);    
	}
	else
             {
	    JOptionPane.showMessageDialog(this, "Please Check the Input...", "Saving a Record", JOptionPane.INFORMATION_MESSAGE);    
             }
	txtStatus.setText(""+result);
	pack();
    }

    public void dispose()
    {
         try
         {
             stat.close();
             prepStat.close();
          	con.close();
         }
         catch(Exception e)
         {
	e.printStackTrace();
         }
    }
}

class TableDialog extends JDialog
{
    private static boolean okStatus = false;

    private TableDialog(JFrame container, Object[][] rowData, String[] columnTitles, String title, String message)
    {
       super(container, title, true);

       JTable table = new JTable(rowData, columnTitles);  
       
       Container contentPane = getContentPane();
       contentPane.add(new JLabel(message), BorderLayout.NORTH);
       contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
       JButton okButton = new JButton("OK");
       contentPane.add(okButton, BorderLayout.SOUTH);
       okButton.addActionListener(
	new ActionListener()
	{   public void actionPerformed(ActionEvent ae)
	    {
	        okStatus = true;
 	        dispose();
	    }
	});

       setSize(300, 200);
    } 

    public static boolean show(JFrame container, Object[][] rowData, String[] columnTitles, String title, String message)
    {
        okStatus = false;
        JDialog tableDialog = new TableDialog(container, rowData, columnTitles, title, message);
        tableDialog.show();
        tableDialog.dispose();
        return okStatus;
    }
}



public class TransactionTest
{      public static void main(String[] args)
        {
	JFrame frame = new TransactionsFrame();
	frame.setTitle("Transactions Frame");
	frame.pack();
	frame.show();
        }
}
