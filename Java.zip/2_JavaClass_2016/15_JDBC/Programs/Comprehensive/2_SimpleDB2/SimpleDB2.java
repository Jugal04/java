//Simple JDBC program that demonstrates creating a table

import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class SimpleDB2
{  public static void main (String args[])
   {  try
      {  
         Connection con = getConnection();
         Statement stmt = con.createStatement();
         
         String command = "create table Student2(id number(10), name varchar2(30))";
                           System.out.println(command);
         stmt.executeUpdate(command);
                           System.out.println("table created successfully");
         
         stmt.close();
         con.close();
      }
      catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }

     catch(IOException ie){
       System.out.println("in io catch");
       ie.printStackTrace();             

}
      
   }

public static Connection getConnection()
      throws SQLException, IOException
   {  Properties props = new Properties();
      String fileName = "SimpleDB2Type4.properties";
      FileInputStream in = new FileInputStream(fileName);
      props.load(in);

      String drivers = props.getProperty("jdbc.drivers");
      if (drivers != null)
         System.setProperty("jdbc.drivers", drivers);
      String url = props.getProperty("jdbc.url");
      String username = props.getProperty("jdbc.username");
      String password = props.getProperty("jdbc.password");

      return
         DriverManager.getConnection(url, username, password);
   }


}



