//Simple JDBC program that demonstrates prepared statement
import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class UpdateParams
{  public static void main (String args[]) throws IOException
   {  try
      {  
         Connection con = getConnection();
         String psString = "update emp set sal = sal + 1000 where empno =?";
         int empno = Integer.parseInt(args[0]);
         PreparedStatement ps = con.prepareStatement(psString);
         ps.setInt(1,empno);
         int retval = ps.executeUpdate();
         ps.close();
         con.close();
      }
      catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }

   }

public static Connection getConnection()
      throws SQLException, IOException
   {  Properties props = new Properties();
      String fileName = "updateParams.properties";
      FileInputStream in = new FileInputStream(fileName);
      props.load(in);

      String drivers = props.getProperty("jdbc.drivers");
      if (drivers != null)
         System.setProperty("jdbc.drivers", drivers);
      String url = props.getProperty("jdbc.url");
      String username = props.getProperty("jdbc.username");
      String password = props.getProperty("jdbc.password");

      return
         DriverManager.getConnection(url, username, password);
   }


}



