import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;   
public class SalRaise2
{
    public static void main(String[] args) throws Exception{

     String name = args[0];
     int increase = Integer.parseInt(args[1]);

    Connection con = DriverManager.getConnection("jdbc:oracle:thin:127.0.0.1:1521:orcl","oratrng","oratrng");

     

    CallableStatement callStat = con.prepareCall("{call SalRaiseProcedure(?,?)}");

         callStat.setString(1, name);
	 callStat.setInt(2, increase);
						
	callStat.executeUpdate();
            



        
    }
}