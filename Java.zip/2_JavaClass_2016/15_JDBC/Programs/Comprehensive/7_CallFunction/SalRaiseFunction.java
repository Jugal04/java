import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.math.*;


public class SalRaiseFunction
{
    public static void main(String[] args) throws Exception{
      String name = args[0];
      int increase = Integer.parseInt(args[1]);

      Connection con = DriverManager.getConnection("jdbc:oracle:thin:127.0.0.1:1521:orcl","oratrng","oratrng");

      CallableStatement  callStat = con.prepareCall("{?=call SalRaiseFunction(?,?)}");
      callStat.registerOutParameter(1, java.sql.Types.NUMERIC);
      callStat.setString(2, name);
      callStat.setInt(3, increase);
						
     double rval = callStat.executeUpdate();
       
       System.out.println("rval "+ rval);
	if (rval != -1)
	   {
	   BigDecimal  res = callStat.getBigDecimal(1);	
            System.out.println("res "+ res); 					
	
            }
               
    }
}


