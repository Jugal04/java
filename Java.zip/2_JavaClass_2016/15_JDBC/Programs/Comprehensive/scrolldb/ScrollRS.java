// demonstrates various result set options
// need to make the program more itelligent

import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class ScrollRS
{ 

 public static void main (String args[])
   {  try
      {  Connection con = getConnection();
         Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,                                                                  ResultSet.CONCUR_UPDATABLE);
          String tableName = "";
         if (args.length > 0)
            tableName = args[0];
             
         else
         {  System.out.println("Usage: ScrollRS TableName");
            System.exit(0);
         }

         
         showTable(tableName, stmt);

        
         stmt.close();
         con.close();
      }
      catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }
      catch (IOException ex)
      {  System.out.println("Exception: " + ex);
         ex.printStackTrace ();
      }
   }

   public static Connection getConnection()
      throws SQLException, IOException
   {  Properties props = new Properties();
      String fileName = "ScrollRS.properties";
      FileInputStream in = new FileInputStream(fileName);
      props.load(in);

      String drivers = props.getProperty("jdbc.drivers");
      if (drivers != null)
         System.setProperty("jdbc.drivers", drivers);
      String url = props.getProperty("jdbc.url");
      String username = props.getProperty("jdbc.username");
      String password = props.getProperty("jdbc.password");

      return
         DriverManager.getConnection(url, username, password);
   }

  
   public static void showTable(String tableName,
      Statement stmt) throws SQLException  { 

       String query = "SELECT empno,ename,deptno,job,sal,comm from " + tableName;
         //using select * will make the result set as NON updatable
      System.out.println(query);
      ResultSet rs = stmt.executeQuery(query);
      ResultSetMetaData rsmd = rs.getMetaData();
      int columnCount = rsmd.getColumnCount();
      while (rs.next()) 

         
      {  
           double sal = rs.getDouble("SAL");
           int deptno = rs.getInt("DEPTNO");

           if (deptno ==  10)
              rs.updateDouble("SAL", sal + sal*.1);
           else
              rs.updateDouble("SAL", sal + sal*.2);

           rs.updateRow();

           System.out.println("updated");

                 

      }
         rs.first();
         rs.updateDouble("SAL", 1111);
         rs.updateRow();

      rs.close();
   }
}



