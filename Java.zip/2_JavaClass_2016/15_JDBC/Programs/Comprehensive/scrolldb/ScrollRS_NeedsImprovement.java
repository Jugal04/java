// demonstrates various result set options

import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class ScrollRS
{  public static void main (String args[]){
    Connection con = null;
    Statement stmt = null;

     try
      {   con = getConnection();
          stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,                                                            ResultSet.CONCUR_UPDATABLE);

        
         if (args.length > 0){
            showTable(args, stmt);
          }
          else{
          System.out.println("Table and column names should be specifed");
          return;
          }
 stmt.close();
         con.close();
         
      }
      catch (SQLException ex)
      {  System.out.println ("SQLException:");
         while (ex != null)
         {  System.out.println ("SQLState: "
               + ex.getSQLState());
            System.out.println ("Message:  "
               + ex.getMessage());
            System.out.println ("Vendor:   "
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }
      catch (IOException ex)
      {  System.out.println("Exception: " + ex);
         ex.printStackTrace ();
      }

    
   }

   public static Connection getConnection()
      throws SQLException, IOException
   {  Properties props = new Properties();
      String fileName = "SimpleQueryDB.properties";
      FileInputStream in = new FileInputStream(fileName);
      props.load(in);

      String drivers = props.getProperty("jdbc.drivers");
      if (drivers != null)
         System.setProperty("jdbc.drivers", drivers);
      String url = props.getProperty("jdbc.url");
      String username = props.getProperty("jdbc.username");
      String password = props.getProperty("jdbc.password");

      return
         DriverManager.getConnection(url, username, password);
   }

  
   public static void showTable(String[] args,
      Statement stmt) throws SQLException   { 

      String tablename = args[0];
       
       String query = "select " ;

       for (int i=1;i<=args.length-1;i++){
                query = query + " " +args[i];
                    if (args[i] != args.length-2){
                       query = query +" ,";
                      }

               }

        System.out.println("query = " +query );
         
}
      
      query = query + "  from  " +tablename;

    
      System.out.println(query);
      ResultSet rs = stmt.executeQuery(query);
      ResultSetMetaData rsmd = rs.getMetaData();
      int columnCount = rsmd.getColumnCount();
      while (rs.next()) 

         
      {  
           double sal = rs.getDouble("SAL");
           int deptno = rs.getInt("DEPTNO");

           if (deptno ==  10)
              rs.updateDouble("SAL", sal + sal*.1);
           else
              rs.updateDouble("SAL", sal + sal*.2);

           rs.updateRow();

           System.out.println("updated");

                 

      }
         rs.first();
         rs.updateDouble("SAL", 1111);
         rs.updateRow();

      rs.close();
   }
}



