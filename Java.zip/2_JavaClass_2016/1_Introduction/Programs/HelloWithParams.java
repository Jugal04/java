//Accepting CommandLine Arguements



public class HelloWithParams{

   public static void main(String args[]){
         
      String name = args[0];
      int age = Integer.parseInt(args[1]);

      System.out.println("Hello " + name + " The age entered by you is " + age + "\n" + "Welcome");
     }
}


/*******************************************************************************************

- You invoke this program as java Ganesh 25 

- Ganesh is stored in args[0], where args[] is an array of Strings 

- The age parameter is an int value but will be stored in args[1], only as a string 

- parseInt() is a static method of Integer class 

- It converts the int which is stored in args[1] as a string, to an int value 

- You should do similar conversions for other data types as well 

*******************************************************************************************/
