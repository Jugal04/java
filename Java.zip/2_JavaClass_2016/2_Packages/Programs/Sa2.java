package testpack2;
 public class Sa2
 {
  public static void main(String[] args){

   Sa sa = new Sa();
   sa.protect = 10;
   System.out.println("protected mmeber in Sa is " + sa.protect);

}
 }
