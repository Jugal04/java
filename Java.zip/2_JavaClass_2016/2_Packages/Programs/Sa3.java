package p3;
 public class Sa3
 {
  public static void main(String[] args){

   
   System.out.println("in sa3");

}
 }

// from programs 
// will create sub dir p3 (pack name of Sa3) under p3parent
javac -d p3parent Sa3.java