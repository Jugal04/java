package mypack;
 public class Sa4
 {
  public static void main(String[] args){

   
   System.out.println("in sa4");

}
 }

