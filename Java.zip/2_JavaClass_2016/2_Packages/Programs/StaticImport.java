import static java.lang.Math.*;

class StaticImport{

public static void main(String args[]){

double root = sqrt(4);

System.out.println("Sqr root of 4 = " + root);

}
}


/*

* java from SE5 permits you static imports.

* You do a static import as above

* This imports all the static fields and methods of the specified class

* So you can say sqrt(n) instead of Math.sqrt(n)

* This provides a convenient usage.


*/