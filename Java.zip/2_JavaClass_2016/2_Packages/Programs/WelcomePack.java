package a;

class WelcomePack{

public static void main(String[] args){
System.out.println(" Hello Welconme Pack");



}

}