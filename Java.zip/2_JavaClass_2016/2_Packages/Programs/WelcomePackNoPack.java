public class WelcomePackNoPack{

public static void main(String[] args){
System.out.println(" Hello Welconme Pack");



}

}