package e;

public class E
{
  public    int e1 = 11;
  protected int e2 = 22;
            int e3 = 33;
  private   int e4 = 44;
}
