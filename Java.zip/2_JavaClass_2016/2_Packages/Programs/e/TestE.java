package e;

public class TestE
{
  public void display()
  {
    // Create an instance of E
    E e = new E();

    // OK to access public member
    System.out.println("e.e1 = " + e.e1);

    // Not OK to access protected member 
    System.out.println("e.e2 = " + e.e2);

    // OK to access member with package access
    System.out.println("e.e3 = " + e.e3);

    // Not OK to access private member
    // System.out.println("e.e4 = " + e.e4);
  }
}
