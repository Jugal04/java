package f;

import e.*;

public class F extends E
{

  public void display()
  {
    // OK to access public member
    System.out.println("e1 = " + e1);

    // OK to access protected member in our superclass
    System.out.println("e2 = " + e2);

    // Not OK to access member with package access
    // System.out.println("e3 = " + e3);

    // Not OK to access private member
    // System.out.println("e4 = " + e4);
  }
}
