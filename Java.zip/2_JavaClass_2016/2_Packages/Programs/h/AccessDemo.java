package h;

import e.SubE;
import e.TestE;

import f.F;   //importing class F from package f
import g.G;

class AccessDemo
{

  public static void main(String args[])
  {  
    System.out.println("Testing subclass"
		+ " in the same package...");
    SubE se = new SubE();
    se.display();

    System.out.println();
    System.out.println("Testing subclass"
		+ " in a different package...");
    F f = new F();
    f.display();   

    System.out.println();
    System.out.println("Testing non-subclass" 
		+ " in the same package...");
    TestE te = new TestE();
    te.display();

    System.out.println();
    System.out.println("Testing non-subclass" 
		+ " in a different package...");
    G g = new G();
    g.display();
  }
}
