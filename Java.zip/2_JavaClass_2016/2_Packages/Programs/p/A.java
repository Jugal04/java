 package p;
 
 public class A
 {
   public void a1()
   {
    System.out.println("method a1() of class A invoked");
   }
 }
