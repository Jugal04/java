 package p;
 
 public class B
 {
   public void b1()
   {
    System.out.println("method b1() of class B"
 				   		    + " invoked");
   }
 }
