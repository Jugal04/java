 package p;
 
 public class C
 {
   public void c1()
   {
     System.out.println("method c1() of class C"
 				   			+ " invoked");
   }
 }
