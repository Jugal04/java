 package q;
 
 import s.*;
 
 class ImportDemo
 {
   public static void main(String args[])
   {
     r.R r = new r.R();
     r.r1();
     S s = new S();
     s.s1();
   }
 }
