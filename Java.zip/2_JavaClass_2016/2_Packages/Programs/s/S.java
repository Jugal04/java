 package s;
 
 public class S
 {
   public void s1()
   {
     System.out.println("Message from s1");
   }
 }
