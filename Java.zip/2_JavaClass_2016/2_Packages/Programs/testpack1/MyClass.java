package testpack1;

class MyClass
 {

 public int  p;

   public void s1()
   {
     System.out.println(" public void s1()");
   }
 }
