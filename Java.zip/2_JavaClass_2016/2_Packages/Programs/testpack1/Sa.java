package testpack1;

class Sa
 {

  protected int protect;

   public void s1()
   {
     System.out.println(" public void s1()");
   }
 }
