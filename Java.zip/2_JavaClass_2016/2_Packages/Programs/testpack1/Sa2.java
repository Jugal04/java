package testpack2; 
import testpack1.*;
 public class Sa2

 {
  public static void main(String[] args){

   MyClass sa = new MyClass();
   sa.pt = 10;
   System.out.println("protected mmeber in Sa is " + sa.p);

}
 }
