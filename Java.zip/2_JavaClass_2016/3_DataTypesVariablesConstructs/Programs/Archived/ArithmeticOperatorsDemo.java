class ArithmeticOperatorsDemo
{
	public static void main(String args[])
	{
		System.out.println("  5+2 = " + (5+2));
		System.out.println("  5-2 = " + (5-2));
		System.out.println(" -5/2 = " + (-5/2));
		System.out.println("  5/2 = " + (5/2));
		System.out.println("5.0/2 = " + (5.0/2));
		System.out.println("  5%2 = " + (5%2));
                System.out.println("1.0/0.3 = " + (1.0/0.3));
                System.out.println("1.0%0.3 = " + (1.0%0.3));                
		System.out.println("  4/2 = " + (4/2));
		System.out.println("  4%2 = " + (4%2));
		System.out.println("  2^3 = " + (Math.pow(2.0, 3.0)));						   
	}
}
