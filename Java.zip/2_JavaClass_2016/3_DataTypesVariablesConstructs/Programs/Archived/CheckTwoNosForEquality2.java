class CheckTwoNosForEquality2
{
    public static void main (String[] args)
    {
	   int no1, no2;
		
        System.out.print("Enter the first number  :");
        no1 = Console.readInt();
		
        System.out.print("Enter the second number :");
	   no2 = Console.readInt();	
		
	   if (no1 == no2)
	   {
			System.out.println("The numbers are " + 
 "equal");
	   }
	   else
	   {
			System.out.println("The numbers are " + 
 "not equal");
	   }
	}
}
