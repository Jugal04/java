class ConversionsAndTruncation
{
  public static void main(String args[]) 
  {
     byte b = 127;	
     int i = b;
     
	System.out.println("Widening Conversion: ");
	System.out.println("b = " + b);
	System.out.println("i = " + i);
	
	i = 258;
        b = (byte)i;
	System.out.println("Narrowing Conversion: "); 
	System.out.println("i = " + i);
	System.out.println("b = " + b);
	 
	float f = 23.9999f;
	i = (int)f; 
	System.out.println("Truncation: ");
	System.out.println("f = " + f);
	System.out.println("i = " + i);
	
byte b1 = 1;
byte b2 = 2;
byte b3 =(byte)( b1 * b2);
	System.out.println("Assignment Problem: ");
	System.out.println("b1 = " + b1);
	System.out.println("b2 = " + b2);
	System.out.println("b3 = " + b3);

	char ch = 'A';
        i  = ch; 
	System.out.println("Character Assignment: ");
	System.out.println("ch = " + ch);
	System.out.println("i  = " + i);
  }
}
