class Factorial
{
	public static void main(String[] args)
	{	
        int i, no;
	   long fact = 1;
	   System.out.print("Enter a number :");
	   no = Console.readInt();

        for (i = 1; i <= no; i++)
        {
			fact = fact * i;
        }
        System.out.println("Factorial of " + no + " is "
 + fact);
	}		
}
