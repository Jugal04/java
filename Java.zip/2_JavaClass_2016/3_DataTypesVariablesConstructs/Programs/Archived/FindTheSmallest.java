public class FindTheSmallest
{
	public static void main(String[] args)
	{
	   int no1, no2, no3;
		
        System.out.print("Enter the first number  :");
        no1 = Console.readInt();
		
        System.out.print("Enter the second number :");
	   no2 = Console.readInt();	

	   System.out.print("Enter the third number  :");
	   no3 = Console.readInt();	
	    
   if (no1 < no2)
	   {
		  if (no1 < no3)
		  {
			System.out.println(no1 + 
" is the smallest");
		  }
		  else
		  {
			System.out.println(no3 + 
" is the smallest");
		  }
	   }
	   else
	   {
		  if (no2 < no3)
		  {
			System.out.println(no2 + 
" is the smallest");
		  }  
  else
		  {
			System.out.println(no3 + 
" is the smallest");
		  } // if (no2 < no3)
	    } // if (no1 < no2)
	} // main()
} // class FindTheSmallest
