 class IncrementAndDecrementOperators
 {
      public static void main(String[] args)
 	{
 		int i, j, k;
 		
 		i = 1;
 		j = ++i;		
 		k = i++;
 		
    System.out.println("Increment Operator:");
    System.out.println("i = " + i + ", j = " + j + ", k = " + k);
    System.out.println("i = " + i + ", j = " + (j++) + ", j = " + j + ", k = " + (++k) );
 		
 		i = 3;
 		j = i--;		
 		k = --i;
 		
 		System.out.println("Decrement Operator:");
                System.out.println("i = " + i + ", j = " + j  + ", k = " + k);
                System.out.println("i = " + i + ", j = " +  (--j) + ", k = " + (k--) + ", k = " + k );
 	}
 }
