class Mensuration
{
	public static void main(String[] args)
	{
		final int CMS_PER_METER = 100;
		final double KMS_PER_METER = 1.0 / 1000.0;
		
		double distanceInMeters = 2000.0;
		double distanceInCMs, distanceInKMs;
		
		distanceInCMs = distanceInMeters * CMS_PER_METER;
		distanceInKMs = distanceInMeters * KMS_PER_METER;
		
		System.out.println("Distance in Meters      = " + distanceInMeters);
		System.out.println("Distance in CentiMeters = " + distanceInCMs);
		System.out.println("Distance in KiloMeters  = " + distanceInKMs);
	}
}
