class MissingBreaks 
{
  public static void main(String args[]) 
  {
    
	int no = 0;
	
	System.out.print("Enter a number between " + 
" 1 and 5...:");
	no = Console.readInt();

    switch(no) 
    {
    case 5:
		System.out.println("Greater than 4");
    case 4:
		System.out.println("Greater than 3");
    case 3:
		System.out.println("Greater than 2");
    case 2:
		System.out.println("Greater than 1");
    case 1:
		System.out.println("Greater than 0");
		break;
    default:
		System.out.println("Greater than 5" +
			" or zero or negative");
    }
  }
}
