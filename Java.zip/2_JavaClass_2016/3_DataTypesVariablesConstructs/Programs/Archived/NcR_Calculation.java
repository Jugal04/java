class NcR_Calculation
{
	public static void main(String[] args)
	{
	   int n, r;
        char choice;
        do
        {
           System.out.print("Enter the value of n...:");
           n = Console.readInt();

           System.out.print("Enter the value of r...:");
           r = Console.readInt();
				
           System.out.println(n + "c" +  r + " = " + 
ncr(n, r));

           System.out.print("Want to continue(y/n)..:");
           choice = Console.readChar();
        } while (choice == 'y' || choice == 'Y');
	}
	
	public static long ncr(int n, int r)
	{
		long ncrValue;
		ncrValue = factorial(n) / (factorial(r) * 
factorial(n - r));
		return(ncrValue);
	}

	public static long factorial(int no)
	{
        int i;
	   long fact = 1;

        for (i = 1; i <= no; i = i + 1)
        {
                fact = fact * i;
        }
        return(fact);
	}
}
