

class PascalTriangle
{
	public static void main(String[] args) 
	{
		int rows;
		int row, col;
		
                System.out.print("Enter the number of rows to" + " be printed :");
                rows = Console.readInt();
		
		row = 0;

out:		while (true)
		{
			col = 0;
			while (true)
			{
			   if (col <= row)
			   {
                              System.out.print(ncr(row, col) + " "); 
			   }
			   else
			   {			
				 if ( row == (rows-1))
				 {
					break out;
				 }
				 else
				 {
				 	break;
				 }
			   }
			   col++;	
			}
			System.out.println("");
			row++;
		}
	}	
	
	public static long ncr(int n, int r)
	{
		long ncrValue;
                ncrValue = factorial(n) / (factorial(r) *  factorial(n - r));
		return(ncrValue);
	}

	public static long factorial(int no)
	{
        int i;
	   long fact = 1;

        for (i = 1; i <= no; i = i + 1)
        {
                fact = fact * i;
        }
        return(fact);
	}	
}
