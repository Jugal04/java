

class PrimeNumbers
{
     public static void main(String[] args) 
     {
        int i, no, start, end;
		
 	   System.out.print("Enter the start number...:");
           start = Console.readInt();

	   System.out.print("Enter the end number.....:");
           end = Console.readInt();

search: for (no = start; no <= end; no++)
	   {	
			for (i = 2; i <= (no-1); i++)
			{
				if (no % i == 0)
				{
					continue search;
				}
			}
			System.out.print(no + " ");
	   }
	}
}
