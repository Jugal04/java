

class PrintingOddNumbers
{
	public static void main(String[] args)
	{
	  int start, end, i;

	  System.out.print("Enter the start number...:");
          start = Console.readInt();

	  System.out.print("Enter the end number.....:");
          end = Console.readInt();
		
	  i = start;
		
	  while (true)
	  {
			if (i > end)			
			{
				break;
			}

			if (i%2 == 0)
			{
				i++;
				continue;
			}	
			System.out.print(i  + " ");
			i++;
	  }
	}
}
