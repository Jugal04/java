class SimpleInterestCalculation
{
	public static void main(String[] args) 
	{
		double principal, simpleInterest;
		int noOfYears;
		float interestRate;
		
		principal = 1000.0;
		noOfYears = 5;
		interestRate = 10.0f;
		
		simpleInterest = principal * noOfYears * (interestRate / 100 );
		
		System.out.println("Principal       = " + principal);
		System.out.println("No of Years     = " + noOfYears);
		System.out.println("Interest Rate   = " + interestRate);
		System.out.println("Simple Interest = " + simpleInterest);
		System.out.println("Total Amount    = " + (principal + simpleInterest ));		
	}
}
