

class StudentDivision
{
	public static void main(String[] args)
	{
		int mark;
		char division;

		System.out.print("Enter the mark...:");
                mark = Console.readInt();

		if ( mark >= 80)
		{
		   System.out.println("First division pass");
		}
		else if (mark >= 60)
		{
		   System.out.println("Second division pass");
		}
		else if (mark >= 50)
		{
		   System.out.println("Third division pass");
		}
		else
		{
			System.out.println("Failed, try again!");
		}
	}
}
