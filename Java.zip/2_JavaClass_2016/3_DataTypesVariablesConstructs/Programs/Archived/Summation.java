class Summation
{
	public static void main(String[] args)
	{
		int no, sum=0;
		char choice = 'y';

		while ( choice == 'y' || choice == 'Y')
		{
			System.out.print("Enter a number ...:");
			no = Console.readInt();

			sum = sum + no;

			System.out.print("Want to enter another no.(y/n)...:");
			choice = Console.readChar(); 
		}

		System.out.println("Sum = " + sum);		
	}
}
