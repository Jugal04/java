class VowelTest
{
  public static void main(String args[]) 
  {
	char ch;
	System.out.print("Enter a character...:");
	ch = Console.readChar();
	
	switch (ch) 
	{
	case 'a':
	case 'A':
	case 'e':
	case 'E':
	case 'i':
	case 'I':
	case 'o':
	case 'O':
	case 'u':
	case 'U':
        System.out.println("The character is a Vowel");
        break;
	default:
        System.out.println("The character is a " + 
 " Consonant");
	}
  }
}
