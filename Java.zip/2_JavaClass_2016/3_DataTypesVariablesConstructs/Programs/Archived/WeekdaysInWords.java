class WeekdaysInWords
{
	public static void main(String[] args)
	{
        int no = 0;
	
        while (no < 1 || no > 7)
	   {
			System.out.print("Enter a number between" 
   + " 1 and 7...:");
			no = Console.readInt();
			
			if (no >= 1 && no <= 7)
			{
				break;
			}
			
			System.out.println("Not a valid number."
 + " Please try again!");
	   }
		
	   switch (no)
	   {
		case 1:
			System.out.println("The first day of " + 
 " week is Sunday");
			break;
		case 2:
			System.out.println("The second day of " + 
  " week is Monday");
			break;
		case 3:
			System.out.println("The third day of " + 
" week is Tuesday");
			break;			
		case 4:
			System.out.println("The fourth day of " + 
   " week is Wednessday");
			break;			
		case 5:
			System.out.println("The fifth day of " + 
  " week is Thursday");
			break;			
		case 6:
			System.out.println("The sixth day of " + 
  " week is Friday");
			break;
		case 7:
System.out.println("The seventh day of " 
+ " week is Saturday");
	   }	
    }
}
