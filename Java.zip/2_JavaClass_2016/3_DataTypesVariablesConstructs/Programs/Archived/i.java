public class i
{
  public static void main(String args[]) 
  {
        char ch = 'd';
	short s = 127;
        int i = 10;
        long l = 5l;
        float f =0.5f;
        
        System.out.println("s + f / ch - (i * l) = " + (s + f / ch - (i * l)));
  }
}
