class TernaryGreaterLesserEqual{
	public static void main(String args[]){
		int num1,num2;
  		// num1 = 10; num2 = 7;
   		// num1 = 10; num2 = 20;
   		num1 =10; num2 = 10;
   	System.out.println("num1 " + num1 + " is " + (num1>num2?"Greater than " :(num1==num2?"equal to ":"lesser than ")) + "num2 " + num2);
 	 }
}


                            