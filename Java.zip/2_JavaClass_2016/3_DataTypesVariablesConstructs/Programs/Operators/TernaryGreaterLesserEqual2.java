class TernaryGreaterLesserEqual2{
	public static void main(String args[]){
		int[] num1Array ={10,5,1};
  		int[] num2Array ={6,7,1};
  		 for(int i=0;i<3;i++){
  			 System.out.println("num1Array["+i+"]  " + num1Array[i]+ " is " + 
				(num1Array[i]>num2Array[i]?"Greater than " :(num1Array[i]==num2Array[i]?"equal to ":"lesser than ")) + 
				"num2Array["+i+"] " + num2Array[i]);
    		}
 	 }
}


                            