class LabelledLoop
{
  public static void main(String args[]) 
  {
	outer:
        for (int i=0;i<=6;i++){
       
        inner:
            for (int j=0;j<=5;j++){
                 if(i<=2){
                    break;
                   //  break inner; also OK
                  }

                  else{                
                         break outer;
                 }
                 
              }
              System.out.println(" inner break " + i);
             
          }
       System.out.println(" outer break "); 
   }//main
 }//class



