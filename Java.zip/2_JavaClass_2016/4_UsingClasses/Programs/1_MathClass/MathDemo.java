 class MathDemo 
 {
   public static void main(String args[])
   {
 	int no1, no2;
 	double no3;
 	double noInDegrees, noInRadians;
 	double base, power;
 	  
 	System.out.println("The Mathematical Constants");
 	
 	System.out.println("E  = " + Math.E);
 	System.out.println("PI = " + Math.PI);
 	
 	System.out.println("\n");
 	System.out.println("Finding the Maximum Value");
 	  
 	System.out.print("Enter the first number...:");
 	no1 = Console.readInt();  
 	System.out.print("Enter the second number..:");
 	no2 = Console.readInt();
 	System.out.println("Max of "+ no1 + " and " +
 				 no2 + " is " + Math.max(no1, no2));
 	
 	System.out.println("\n");
 	System.out.println("Finding the Minimum Value");
 	  
 	System.out.print("Enter the first number...:");
 	no1 = Console.readInt();  
 	System.out.print("Enter the second number..:");
 	no2 = Console.readInt();
 	System.out.println("Min of "+ no1 + " and " +
 				 no2 + " is " + Math.min(no1, no2));
 
 	System.out.println("\n");
 	System.out.println("Finding the Absolute Value");
 	System.out.print("Enter a number...........:");
 	no1 = Console.readInt();  
 	System.out.println("Absolute value of " + no1 + 
 					   " is " + Math.abs(no1));
     
 	System.out.println("\n");
 	System.out.println("Rounding to an Integer");
 	
 	System.out.print("Enter a double value.....:");
 	no3 = Console.readDouble();
 	System.out.println("The ceiling of " + no3 + 
 					 " is " +	Math.ceil(no3));
      System.out.println("The floor   of " + no3 +
 					 " is " +	Math.floor(no3));
 	System.out.println("The nearest integer " +
 					 " is " + Math.rint(no3));
 	System.out.println("The nearest long integer " +
 					 " is " + Math.round(no3));
 	
 	System.out.println("\n");
 	System.out.println("Trignometric Functions");
 	
 	System.out.print("Enter an angle in degrees:");
 	noInDegrees = Console.readDouble();
 	
 	noInRadians = noInDegrees * Math.PI / 180;
 	
 	System.out.println("sin(" + noInDegrees + ") = " +
 						Math.sin(noInRadians));
 	System.out.println("cos(" + noInDegrees + ") = " +Math.cos(noInRadians));
 	System.out.println("tan(" + noInDegrees + ") = " +Math.tan(noInRadians));
 						
 	System.out.println("\n");
 	System.out.println("Finding the Exponentiation ");
 	System.out.print("Enter the base value......:");
 	base = Console.readDouble();
 	System.out.print("Entter the value of power.:");
 	power = Console.readDouble();
 System.out.println(base + "^"+ power + " = " + 
 Math.pow(base, power));
 	
 	System.out.println("\n");
 	System.out.println("Generating Random Numbers");
 	
 	for (no1=1; no1 <= 10; no1++)
 	{
 		System.out.println(Math.random());
 	}
   }
 }

/* Math.rint() returns int 
   Math.round() returns long

*/