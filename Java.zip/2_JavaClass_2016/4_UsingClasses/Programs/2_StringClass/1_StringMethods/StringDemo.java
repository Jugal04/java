 class StringDemo
 {
   public static void main(String args[])
   {
 	System.out.println("Extracting Substring...");
 	
     String str = "One Two Three Four";
 	System.out.println("str ................ = " +  str);
      System.out.println("str.substring(8, 11) = " + 
    str.substring(8, 11));
 
      str = "The total cost is $45.67";
      int i1 = str.indexOf('$');
      String substr = str.substring(i1);
 	System.out.println("str ............. = " + str);
      System.out.println("The dollar amount = " + 
  substr);
 	
 	
 	System.out.println("");
 	System.out.println("Reversing a String...");
 
 	System.out.print("Enter a string........:");
 	str = Console.readString();
 	str = str.trim();
 		
 	String strReverse = "";
 	for (int i = str.length()-1; i >= 0; i--)
 	{
 		strReverse += str.charAt(i);
 	}
 	
 	System.out.println("String after trim.....:" + 
 str);
 	System.out.println("Reverse of the string.:" + 
    strReverse);
 	
 	
 	System.out.println("");
 	System.out.println("String Concatenation...");
 	System.out.print("Enter a string.......:");
 	String str1 = Console.readString();
 	System.out.print("Enter another string.:");
 	String str2 = Console.readString();	
 	System.out.println("str1 + str2 ....  = " + 
 (str1 + str2));
 	System.out.println("str1.concat(str2) = " + 
  str1.concat(str2));
 	System.out.println("");
 	System.out.println("String Comparison Without " + 
 "Ignoring Case...");
 	
 	System.out.print("Enter a string.......:");
 	str1 = Console.readString();
 	System.out.print("Enter another string.:");
 	str2 = Console.readString();	
 	
 	System.out.println("Using equals() method...");
 	
 	if (str1.equals(str2))
 	{
 		System.out.println("First string is equal to " 
     + " the second string");
 	}
 	else
 	{
 		System.out.println("First string is not " 
    + " equal to the second string");
 	}
 	
 	System.out.println("Using CompareTo() method...");
 	
 	int result = str1.compareTo(str2);
 	
 	if ( result < 0 )
 	{
 		System.out.println("First string is " 
 + " smaller than the second one");
 	}
 	else if(result == 0)
 	{
 		System.out.println("First string is " 
 + " same as the second one");
 	}
 	else
 	{
 		System.out.println("First string is " 
 + " larger than the second one");
 	}
 	
 	System.out.println("");
 	System.out.println("String Comparison Ignoring " 
 + " Case...");
 	
 	System.out.println("Using equalsIgnoreCase() " 
 + " method...");
 	
 	if (str1.equalsIgnoreCase(str2))
 	{
 		System.out.println("First string is " 
 + " equal to the second string");
 	}
 	else
 	{
 		System.out.println("First string is " 
  + " not equal to the second string");
 	}
 
 	System.out.println("Using compareToIgnoreCase() " 
    + " method...");
 	result = str1.compareToIgnoreCase(str2);
 		
 	if ( result < 0 )
 	{
 		System.out.println("First string is " 
 + " smaller than the second one");
 	}
 	else if(result == 0)
 	{
 		System.out.println("First string is " 
 + " same as the second one");
 	}
 	else
 	{
 		System.out.println("First string is " 
 + " larger than the second one");
 	}
 
 	System.out.println("");
 	System.out.println("Case Conversion...");
 	System.out.print("Enter a string...:");
 	str = Console.readString();
 	System.out.println("str.toUpperCase() = " 
 + str.toUpperCase());
 	System.out.println("str.toLowerCase() = " 
 + str.toLowerCase());
 
 	System.out.println("");
 	System.out.println("Searching for a substring...");
 	System.out.print("Enter a string......:");
 	str = Console.readString();
 	System.out.print("Enter the substring.:");
 	substr = Console.readString();
 	
 	int idx1 = str.indexOf(substr);
 	int idx2 = str.indexOf(substr, idx1+1);
 	
 	System.out.println("Searching in the forward " 
   + " direction...");
 	
 	if (idx1 == -1 && idx2 == -1)
 	{
 		System.out.println("Substring not found...");
 	}
 	
 	if (idx1 != -1)
 	{
 		System.out.println("First  occurance is at " 
 + " index " + idx1);
 	}
 	
 	if (idx2 != -1)
 	{
 		System.out.println("Second occurance is " 
 + " at index " + idx2);
 	}
 
 	idx1 = str.lastIndexOf(substr);
 	idx2 = str.lastIndexOf(substr, idx1-1);
 	System.out.println("Searching in the reverse " 
 + " direction...");
 	
 	if (idx1 == -1 && idx2 == -1)
 	{
 		System.out.println("Substring not found...");
 	}
 	
 	if (idx1 != -1)
 	{
 		System.out.println("First  occurance is at " 
 + "  index " + idx1);
 	}
 	
 	if (idx2 != -1)
 	{
 		System.out.println("Second occurance is at " 
  + " index " + idx2);
 	}
 	
 	System.out.println("");
 	System.out.println("Replacing a Character with " 
   + " Another...");
 	System.out.println("\"matter\".replace('t', 'n')= " 
  + "matter".replace('t', 'n'));	
   }
 }
