 class StringDemo0
 {
   public static void main(String args[])
   {
     String name1 = new String("Ganesh");    // heap 
     String name  = "Sankar";                      // string pool, also heap from java 7
   
     String name1welcome = name1 + " welcome";    // immutable
     String name2 = new String("Ganesh");
    
     System.out.print("name1 == name2 is ");      // need for equals
     System.out.print( name1 ==  name2);

     System.out.print("\n name1 equals name2 is "); 
     System.out.print( name1.equals( name2));

     String name3 = "Ganesh";
     System.out.print("\n name1 == name3 is ");      
     System.out.print( name1 ==  name3);

     String name4 = "Ganesh";
     System.out.print("\n name3 == name4 is ");   // string pool    
     System.out.print( name3 ==  name4);

     String wiseMan = "kishore";
     wiseMan.toUpperCase();

    
     System.out.println("\n wiseMan.equals(\"KISHORE\") " + wiseMan.equals("KISHORE"));   
  
     System.out.println("\n wise man again is " + wiseMan);

 	
   }
 }
