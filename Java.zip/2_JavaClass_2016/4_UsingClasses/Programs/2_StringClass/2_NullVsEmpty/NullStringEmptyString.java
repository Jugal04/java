class NullStringEmptyString{

public static void main(String[] args){

String myString = "Hello";
String nullString = null;       
String emptyString ="";
String emptyString2 = new String("");
// String r=null;   
// System.out.println("r is " + r.length());  thows null ptr execption
System.out.println("myString is " + myString);
System.out.println("length of myString is " + myString.length());


System.out.println("nullString is " + nullString);
//System.out.println("length of nullString is " + nullString.length());     //uncomment for error
System.out.println(" nullString is null " +(nullString==null)); 


System.out.println("emptyString is " + emptyString);
System.out.println("length of emptyString is " + emptyString.length());
System.out.println("emptyString is = 0 " + (emptyString.length()==0));
System.out.println("emptyString is empty " + (emptyString.isEmpty()));

System.out.println("emptyString2 length  = " + emptyString.length());



String es = emptyString + " is No longer empty";
String ns = nullString + " is no longer null";


String esc = emptyString.concat(" is No longer empty");
// String nsc = nullString.concat(" is no longer null"); // uncomment for error


}

}

/*

* String nullString = null;   
* no string object has been created
* nullString is not referring to any thing   
* since there is no object, nullString.method() throws nullpointer exception

* String emptyString = "";
* String object has been created
* emptyString refers to a string object
* but its length is 0
* since it is  a string  object (of course zero length), you can invoke emptyString.method() 

* so while checking strings for no value , you should check == null as well as == 0

* Which is better setting null or "" - ???????

*/