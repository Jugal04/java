import java.io.*;

// Demonstrates the various methods of StringBuffer class

// The capacity is the amount of storage available for newly inserted characters, beyond which an allocation will occur.
// it is length + 16 while creation

class StringBufferDemo
{
 public static void main(String args[]) throws Exception
 {
    StringBuffer sb1 = new StringBuffer();
    System.out.println("\nThe StringBuffer sb1 capacity before assignment is " + 
                                                                sb1.capacity());  // 0 + 16
    System.out.println("\n");

    sb1.append("Hello");
    System.out.println("The StringBuffer sb1  " + sb1);
    System.out.println("The StringBuffer sb1 length  " + sb1.length());
    System.out.println("The StringBuffer sb1 capacity  is " + sb1.capacity());      // will give 16 since append is used
    System.out.println("\n");

    sb1.append("HelloHello");
    System.out.println("The StringBuffer sb1  " + sb1);
    System.out.println("The StringBuffer sb1 length is " + sb1.length());
    System.out.println("The StringBuffer sb1 capacity  is " + sb1.capacity());
    System.out.println("\n");

    
    sb1.append("Hello");
    System.out.println("sb1 is  " + sb1);
    System.out.println("The StringBuffer sb1  " + sb1);
    System.out.println("The StringBuffer sb1 length after append is " + sb1.length());
    System.out.println("The StringBuffer sb1 capacity after append is " + sb1.capacity());
    System.out.println("\n");
     

  
    StringBuffer sb = new StringBuffer("You are welcome");  // capacity  15 +16 =31
    System.out.println("The Length of the String You are welcome is " + sb.length());
    System.out.println("The Capacity of the Buffer is " + sb.capacity());
    System.out.println("\n");
  

    StringBuffer sb2 = new StringBuffer("Hello");
    System.out.println("The Length of the Stringbuffer  sb2   Hello is " + sb2.length());
    System.out.println("The Capacity of the Buffer sb2 for Hello is " + sb2.capacity());  // is 21 since it is creation NOT append

    sb= sb.append("hello again");
    System.out.println("The StringBuffer sb is " + sb);
    int theLength=sb.length();
    int theCapacity=sb.capacity();
  

    System.out.println("The Length of the String is " + theLength);
    System.out.println("The Capacity of the Buffer is " + theCapacity);


  
  // Specified Length is set

  sb.setLength(8);
  System.out.println("The StringBuffer sb after setting length (decrease in the length) now is " + sb);

  StringBuffer sbnew = sb.append(" always invited");
  System.out.println("The StringBuffer sb after using append statement is "+ sbnew);

  // Changes the capacity from the default value to the specified value

  sb.ensureCapacity(70);


  // Inserting a string

  sb.insert(15," warmheartedly");
  System.out.println("After inserting a string sb  becomes" + sb);


  // Creating a String Object from a StringBuffer Object

  String Welcome=sb.toString();
  System.out.println("The String Object Welcome is " + Welcome);




  // A new StringBuffer object is created specifying the capacity

  StringBuffer newString = new StringBuffer(50);

  int StrCapacity=newString.capacity();
  System.out.println("Capacity of new String is "+ StrCapacity);

  newString = new StringBuffer("Hello how are you");
  System.out.println("The new StringBuffer is " + newString);

  int newStringLength = newString.length();
  int newStringCapacity= newString.capacity();

  System.out.println("The Length of new String is " + newStringLength);
  System.out.println("The Capacity of the new buffer is " + newStringCapacity);

  StringBuffer newString2 = newString.append("? ").append(" I").append(" am")
                                        .append(" fine").append(" i expect the same"); 
  System.out.println("The StringBuffer newString after the usage of append statement is " + newString2);


  int newStrLength = newString.length();

  System.out.println("The length now is " + newStrLength);


  int newStrCapacity= newString.capacity();
  System.out.println("The capacity now is " + newStrCapacity);

  StringBuffer revBuffer = new StringBuffer("Hello");
  revBuffer.reverse();
  System.out.println(" hello is reveresed as " + revBuffer);

//Test

StringBuffer sbSubject = new StringBuffer("Advanced Java Technology"); //40
System.out.println("sbSubject capacity is = " + sbSubject.capacity()); 

// other useful methods

/* * * *
   char	charAt(int index)

   String substring(int start)

   String substring(int start, int end)

   void	trimToSize()

* * * */

 }
}
                


/*
StringBuffer
-------------

- Similar to String Class
                                              
- But mutable

- When created the default capacity is 32 bytes   (16 chars)

               length will be 0
- new StringBuffer("Hello") - lenth = 5, capacity =31

- The capacity is the amount of storage available for newly inserted characters, beyond which an allocation will occur.

- Can specify capacity

- when length exceeds capacity, capacity is doubled + 2   normally

- methods are synchronized
*/
