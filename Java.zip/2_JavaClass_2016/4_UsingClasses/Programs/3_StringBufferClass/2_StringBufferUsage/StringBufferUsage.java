class StringBufferUsage{

public static String modifyString(String inputString){

  StringBuffer sb = new StringBuffer(inputString);
  sb.append(" welcome ");
  sb.insert(1," modified ");
  return sb.toString();
  }

public static void main(String[] args){
  String stringToModify = " India is a great nation ";
  String modifiedString = modifyString(stringToModify);
  System.out.println(" modified as " + modifiedString);
  }
}


/* 

* you need to edit a string
* immutability poses a great overhead
* so you convert it to a string buffer (or string builder) object
* edit it
* send back as a string
* what is the gain?

*/

