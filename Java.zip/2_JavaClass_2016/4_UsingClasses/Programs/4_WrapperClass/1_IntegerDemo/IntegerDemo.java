 class IntegerDemo
 {
         public static void main(String args[])
         {
                 String s1 = "125";
                 String s2 = "75";
 
                 Integer obj = Integer.valueOf(s1);
                 int i1 = obj.intValue();
                 int i2 = Integer.valueOf(s2).intValue();
                 System.out.println("i1 = " + i1);
                 System.out.println("i2 = " + i2);
 
                 Integer obj1 = new Integer(5);
                 Integer obj2 = new Integer(5);
                 Integer obj3 = new Integer("5");
                 Integer obj4 = obj1;
 
                 System.out.println("obj1.equals(obj2) =" +  obj1.equals(obj2));                                
                 System.out.println("obj1.equals(obj3) =" +  obj1.equals(obj3));
                 System.out.println("obj1.equals(obj4) =" +  obj1.equals(obj4));
 
                 System.out.println("(obj1 == obj2) = " + (obj1 == obj2));
                 System.out.println("(obj1 == obj3) = " + (obj1 == obj3));
                 System.out.println("(obj1 == obj4) = " + (obj1 == obj4));
         }
 }
