 class WrapperDemo
 {
    public static void main(String args[]) throws java.io.IOException
    {
       System.out.println("The Boolean Class...");
       System.out.println("FALSE = " +
                                 Boolean.FALSE);
       System.out.println("TRUE  = " +
                                 Boolean.TRUE);
 
       System.out.println("\nThe Integer Class...");
       int i = 11;
       System.out.println("Decimal is " + i);
       System.out.println("Binary  is " +
       Integer.toBinaryString(i));
       System.out.println("Hex     is " +
                         Integer.toHexString(i));
       System.out.println("Octal   is " +
                         Integer.toOctalString(i));
 
       System.out.println("MIN_VALUE = " +
                                 Integer.MIN_VALUE);
       System.out.println("MAX_VALUE = " +
                                 Integer.MAX_VALUE);
 
       System.in.read();
       System.out.println("\nThe Byte Class...");
       System.out.println("MIN_VALUE = " +
                                 Byte.MIN_VALUE);
       System.out.println("MAX_VALUE = " +
                                 Byte.MAX_VALUE);
 
       System.out.println("\nThe Long Class...");
       System.out.println("MIN_VALUE = " +
                                 Long.MIN_VALUE);
       System.out.println("MAX_VALUE = " +
                                 Long.MAX_VALUE);
 
 
       System.out.println("\nThe Character Class...");
       System.out.println("Character.isDigit('0') = " +
                                 Character.isDigit('0'));
       System.out.println("Character.isLetter('0') = " +
                                Character.isLetter('0'));
                                   
 
 System.out.println("Character.isLetterOrDigit('0')="+ Character.isLetterOrDigit('0'));
                  
  System.out.println("Character.isLowerCase('a') = " +
             Character.isLowerCase('a'));
                 
 
  System.out.println("Character.isUpperCase('z') = " +
                  Character.isUpperCase('z'));
      
  System.out.println("Character.toLowerCase('A') = "
  					+  Character.toLowerCase('A'));
 
       System.out.println("Character.toUpperCase('z') = "
 +  Character.toUpperCase('z'));
                 
  System.out.println
 ("Character.isSpaceChar('\\n')= " 
                + Character.isSpaceChar('\n'));
                 
  System.out.println
 ("Character.isWhitespace('\\n') = " 
 +  Character.isWhitespace('\n'));
       System.in.read();
       System.out.println("\nThe Float Class...");
       System.out.println("MIN_VALUE = " +
                                 Float.MIN_VALUE);
       System.out.println("MAX_VALUE = " +
                                 Float.MAX_VALUE);
 
       System.out.println("\nThe Double Class...");
       System.out.println("MIN_VALUE = " +
                                 Double.MIN_VALUE);
       System.out.println("MAX_VALUE = " +
                                 Double.MAX_VALUE);
 
       System.out.println("POSITIVE_INFINITY = "+
                           Double.POSITIVE_INFINITY);
       System.out.println("NEGATIVE_INFINITY = "+
                           Double.NEGATIVE_INFINITY);
 
       double d1 = 0;
       double d2 = 0;
 
       double d3 = d1 / d2;
       System.out.println("d3(0/0) = " + d3);
 
       System.out.println("Double.isInfinite(d3) = " +
                                 Double.isInfinite(d3));
       System.out.println("Double.isNaN(d3) = " +
                                      Double.isNaN(d3));
    }
 } 
