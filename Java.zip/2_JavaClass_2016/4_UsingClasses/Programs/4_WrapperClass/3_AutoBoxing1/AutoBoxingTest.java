/* Demonstrates the automatic conversion of primitive data types into the respective 
*  wrapper classes and vice versa

* There is no need to explicitly create a wrapper class object using the new key word, as was done in earlier versions.

*/

class AutoBoxingTest{

  public static void main(String args[]){


    int numInt = 10; 
    Integer numInteger;
    Integer numInteger1;
    numInteger = (Integer)numInt;       //what is typecasting ?
    numInteger1 = new Integer(numInt);

    System.out.println("numInt is " + numInt);
    System.out.println("numInteger is " + numInteger);
    System.out.println("numInteger1 is " + numInteger1);

    int numInt2 ;
    Integer numInteger2 = new Integer(45);
    numInt2 =  numInteger2.intValue();

    System.out.println("numInt2 is " + numInt2);

    
    

  
  Integer I;
  Integer I2;

  int i;
  int i2;

  I  = 0;
  I2 = 30;

   i = 100;
  i2 = 0;


  

  System.out.println("I is " + I);
  System.out.println("i is " + i);

  I = i;

  System.out.println("I after assinment from i is " + I);



 System.out.println("I2 is " + I2);
 System.out.println("i2 is " + i2);

 i2 =I2;
 System.out.println("i2 after assignment from I2is " + I2);


}
}

/* real life impact of autoboxing/unboxing:


---
 calcSum(long start, long end){
    
      Long sum = 0;

      for (long i = start; i < end ; i++) {
      sum += i;
}
System.out.println(sum);
}
*/

