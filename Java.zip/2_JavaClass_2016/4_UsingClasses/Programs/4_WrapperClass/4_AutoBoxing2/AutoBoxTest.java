/***********************************************************************
 demonstartes auto boxing features
*************************************************************************/
class AutoBoxTest{
  
  public static void main(String[] args){

   Integer x = 5;
   Integer y = x;
   System.out.println("x==y is " + (x == y)); // true  
   System.out.println("x.equals(y) is " + (x.equals(y))); // true       
   System.out.println();
 
   x++;
   System.out.println("x==y is " + (x == y)); //false
   System.out.println("x.equals(y) is " + (x.equals(y))); // false       
   System.out.println();
  
   Integer a = new Integer(5);
   Integer b = new Integer(5);
   System.out.println("a==b is " + (a==b));   //false
   System.out.println("a.equals(b) is " + (a.equals(b))); // true       
   System.out.println();

   Integer p = 10;
   Integer q = 10;
   System.out.println("p==q is " +   (p==q));  // true
   System.out.println("p.equals(q) is " + (p.equals(q))); // true       
   System.out.println();

   Integer m = 6;
   Integer n = new Integer(6);
   System.out.println("m==n is "+ (m==n));     //false
   System.out.println("m.equals(n) is " + (m.equals(n))); // true       
   System.out.println();

   Integer r = new Integer(8);
   Integer s = 8;
   System.out.println("r==s is "+ (r==s));    //false
   System.out.println("r.equals(s) is " + (r.equals(s))); // true       
   System.out.println();

 }
}












