
import java.util.*;

class ArrayDeclare
{
    public static void main(String args[])

        int[] intArray2;
        intArray2 = new int[4];
    {
        int[] intArray = new int[5];

     
         
        int[] intArray3 = {10,9,8,7};

        int[] nolength = new int[0]; //?

         System.out.println("int Array...");

        for(int i=0; i < intArray3.length; i++)
        {
            System.out.print(intArray3[i] + " ");
        }

         System.out.println("\n"+ Arrays.toString(intArray3));

  }

}

       
// Array is a class in Java
// default  null, elements 0
