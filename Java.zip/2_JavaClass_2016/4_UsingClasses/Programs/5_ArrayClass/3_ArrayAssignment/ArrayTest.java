class ArrayTest
{
    public static void main(String args[])
    {
        int[] i=new int[3];
        int[] j;

        i[0]=1;
        i[1]=2;
        i[2]=3;

        j = i;

        System.out.println("\n");
        for(int no=0; no < 4; no++)
        {
            System.out.println(i[no] + " ");
        }
    }
}
