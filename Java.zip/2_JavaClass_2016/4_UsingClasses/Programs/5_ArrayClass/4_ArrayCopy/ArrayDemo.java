import java.util.*;
class ArrayDemo
{
    public static void main(String args[])
    {
        System.out.println
                ("Array Initialization...");
        int[] bookArray = new int[10];
         printArray(bookArray);


        int[] b = {2, 1, 5, 3, 4};
        printArray(b);
        System.out.println("\n\nBefore Array " + "Copy...");

        int[] c= {0, 0, 0, 0, 0};
        printArray(c);
        System.arraycopy(b, 0, c, 1, 4);

        System.out.println("\n\nAfter Array"+ "Copy...");


        printArray(c);

     //SE6 Arrays.copyOf

      int[] sourceArray = {10,20,30,40,50,60};
      int [] targetArray = Arrays.copyOf(sourceArray, sourceArray.length);
     // Note that this copies only single dim array
     // for 2d copy each dim separately

      System.out.println("Printing targetArray");
      printArray(targetArray);

      int [] targetArray2 = Arrays.copyOf(sourceArray,3);                       //copies 3 elements from start
      System.out.println("Printing targetArray2");
      printArray(targetArray2);

     //Arrays.copyOfRange(int[] original,int from,int to) - is also available

// copying 2D Arrays

    int[][] twodarray1 = {{5,2,3},{10,12,15}}; 
    int[][] twodarray2 = new int[2][3];
     twodarray2 = Arrays.copyOf(twodarray1, 2);
    System.out.println("twodarra2 contents are " + Arrays.deepToString(twodarray2));

    




    }

    public static void printArray(int[] nos)
    {
        for (int i=0; i<=(nos.length-1); i++)
        {
            System.out.print(nos[i] + " ");
        }
        System.out.println();
    }
}
