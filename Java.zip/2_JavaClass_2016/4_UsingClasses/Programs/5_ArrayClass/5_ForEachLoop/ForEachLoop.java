/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/



public class ForEachLoop{
 public static void main(String args[]){
  int j=0;
 int[] marksArray = {10, 20, 30, 40,50};

  System.out.println("\n contents of  marksArray are:" );
  for(int i:marksArray){
    System.out.println("\n " + i);
  }


  System.out.println("\n manipulating the array with for each loop:" );
 for(int i:marksArray){
  i = i*10;
  System.out.println("\n marksArray["+ j++ +"] = " + i);
  }
  System.out.println("\n printing after the change" );

 System.out.println("\n contents of  marksArray are:" );
  for(int i:marksArray){
    System.out.println("\n " + i);
  }
 }
}


/* 

  * se5 feature
  * for(variable:collection){statements}
  * sets the specified variable to each element of the collectionwith
  * every iteration and also executes the statement or block of statements
  * read this as " for each element in the collection ...

*/
//HOW IS THIS DIFFERENT FROM Arrays.toString() ? ? ?