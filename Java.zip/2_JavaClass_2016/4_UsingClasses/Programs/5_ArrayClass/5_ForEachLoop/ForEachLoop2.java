/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/


class Box{

private int length;
private int width;
private int height;


Box(int length, int width, int height){

this.length = length;
this.width = width;
this.height = height;

}

Box(){}

public void setLength(int length){
this.length= length;
}

public int getLength(){

return this.length;
}

//public setter and getters

public int volume(){

  return length * width * height;

  }

}

public class ForEachLoop2{

 public static void main(String args[]){
   int i=5,j=10,k=15,l=100;
   int i1=5,j1=10,k1=15,l1=100;
   Box[] box = new Box[3];

 for (int s=0;s<box.length;s++){
   box[s]= new Box(i++,j++,k++);
}

 System.out.println("\n before set length - b.volume() ");
 for(Box b:box){
   System.out.println(" before set length "+ b.volume());
   b.setLength(l++); 
   System.out.println(" after set length " +b.volume());
   }

System.out.println("\n printing with a fresh for each loop  - b.volume() ");
 for(Box b:box){
   System.out.println(" after set length "+ b.volume());
  }


System.out.println("\n b1.volume() ");

 for(Box b1:box){
   b1 = new Box(i1++,j1++,k1++);
    System.out.println(b1.volume());
   }

System.out.println("\n b1.volume() separately ");

for(Box b1:box){
     System.out.println(b1.volume());
   }


 }
}



