/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/



public class ForEachLoop3{
 public static void main(String args[]){

Integer ia[] = new Integer[5];

ia[0] = new Integer(10);
ia[1] = new Integer(20);
ia[2] = new Integer(30);
ia[3] = new Integer(40);
ia[4] = new Integer(50);

System.out.println("printing contents before change");

for(Integer i:ia){
System.out.println(i);


}
System.out.println("printing contents after change from within the same for each");

for(Integer i:ia){
i=i+10;
System.out.println(i);
}

System.out.println("printing contents after change from a separate for each");

for(Integer i:ia){
System.out.println(i);
}




 }
}


