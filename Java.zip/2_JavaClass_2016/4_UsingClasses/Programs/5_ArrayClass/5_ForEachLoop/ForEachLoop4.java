/* Demonstrates the use of for each loop
*  Can be used in collections like arrays, vectors, lists, etc.,
*  Also can be used in var args methods
*/

class Intwrapper{
int number;

public Intwrapper(int number){

this.number = number;
}
}




public class ForEachLoop4{
 public static void main(String args[]){

Intwrapper ia[] = new Intwrapper[5];

ia[0] = new Intwrapper(10);
ia[1] = new Intwrapper(20);
ia[2] = new Intwrapper(30);
ia[3] = new Intwrapper(40);
ia[4] = new Intwrapper(50);

System.out.println("printing contents before change");

for(Intwrapper i:ia){
System.out.println(i.number);


}
System.out.println("printing contents after change from within the same for each");

for(Intwrapper i:ia){
i.number++;
System.out.println(i.number);
}

System.out.println("printing contents after change from a separate for each");

for(Intwrapper i:ia){
System.out.println(i.number);
}




 }
}


