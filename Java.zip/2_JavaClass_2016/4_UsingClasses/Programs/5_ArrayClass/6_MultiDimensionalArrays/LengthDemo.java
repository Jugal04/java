class LengthDemo
{
    public static void main(String args[])
    {
        int[][] myArray = {
                            {33, 71},
                            {-16, 45, 50, -7},
                            {99}
                          };

        System.out.println("myArray.length = " + myArray.length);
        System.out.println("myArray[0].length = " + myArray[0].length);
        System.out.println("myArray[1].length = " + myArray[1].length);
        System.out.println("myArray[2].length = " + myArray[2].length);
    }
}
