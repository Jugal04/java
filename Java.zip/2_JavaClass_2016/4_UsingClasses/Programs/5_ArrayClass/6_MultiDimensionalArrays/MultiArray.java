import java.util.*;

class MultiArray
{
    public static void main(String args[])
    {
      
// 2D Array - 1

        int[][] myArray1;
        myArray1 = new int[2][3]; 
        myArray1[0][1] = 11;
        print2DArray(myArray1);


// 2D Array - 2

        int[][] myArray2 = new int[2][3]; 
        myArray2[0][1] = 12;
        print2DArray(myArray2);



// 2D Array - 3

        int[][] myArray3 = {{5,2,3},{10,12,15}}; 
        print2DArray(myArray3);



// 2D    Array -4 

           int[][] myArray = {
                            {33, 71},
                            {-16, 45, 50, -7},
                            {99}
                          };

        System.out.println("myArray.length = " + myArray.length);
        System.out.println("myArray[0].length = " + myArray[0].length);
        System.out.println("myArray[1].length = " + myArray[1].length);
        System.out.println("myArray[2].length = " + myArray[2].length);

       System.out.println("  myarray with deepToString:");
       System.out.println(Arrays.deepToString(myArray));



// 2D Array -5

   int[][] myArray5 = new int[3][];

    myArray5[0] = new int[5];
    myArray5[1]= new int[2];
    myArray5[2]= new int[1];

 
  System.out.println("Length of myArray5 = " + myArray5.length);
  System.out.println("Length of myArray5[0] = " + myArray5[0].length);
  System.out.println("Length of myArray5 =[1] " + myArray5[1].length);
  System.out.println("Length of myArray5[2] = " + myArray5[2].length);

System.out.println("Printing myArray5");
 Arrays.deepToString(myArray5);
   

    }

public static void print2DArray(int[][] twodarray){

      System.out.println("Array elements are:"); 
        for(int i=0; i < twodarray.length; i++)
           {
             for(int j=0; j < twodarray[0].length; j++)
                {
                     System.out.print( twodarray[i][j]);
                     System.out.print("  ");
                 }

             System.out.println();
             }

            //using Arrays.deeppToString
            //import java.util.*;

       System.out.println("using deepToString - Array Elements are :");
       System.out.println("  twodarray :");
       System.out.println(Arrays.deepToString(twodarray));
 }
}
 


//how will you  print a ragged array contents

/*
  2D arrays are nothing but 1D array whose type is an arry itself.
  myArray1 refers to start of the 1st dimension - row
  myArray1[0] refers to the start of the 2nd dimension - col :   refer diagram
*/