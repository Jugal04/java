class LengthDemo3
{
    public static void main(String args[])
    {
      
// 2D Array - 1

        int[][] myArray1;
        myArray1 = new int[2][3]; 
        myArray1[0][1] = 11;
        print2DArray(myArray1);


// 2D Array - 2

        int[][] myArray2 = new int[2][3]; 
        myArray2[0][1] = 12;
        print2DArray(myArray2);



// 2D Array - 3

        int[][] myArray3 = {{5,2,3},{10,12,15}}; 
        print2DArray(myArray3);



// 2D    Array -4 

           int[][] myArray = {
                            {33, 71},
                            {-16, 45, 50, -7},
                            {99}
                          };

        System.out.println("myArray.length = " + myArray.length);
        System.out.println("myArray[0].length = " + myArray[0].length);
        System.out.println("myArray[1].length = " + myArray[1].length);
        System.out.println("myArray[2].length = " + myArray[2].length);
    }

public static void print2DArray(int[][] twodarray){

      System.out.println("Array elements are:"); 

for(int i=0; i < twodarray.length; i++)
     {
         
      
         for(int j=0; j < twodarray[i].length; j++)
                       
        
        {
            System.out.print( twodarray[i][j]);
            System.out.print("  ");
        }

       System.out.println();
     }
}
}

// prints a ragged array contents