import java.util.*;

class LengthDemo4
{
    public static void main(String args[])
    {
      
// 2D Array - 1

        int[][] myArray1;
        myArray1 = new int[2][3]; 
        myArray1[0][1] = 11;
        print2DArray(myArray1);


// 2D Array - 2

        int[][] myArray2 = new int[2][3]; 
        myArray2[0][1] = 12;
        print2DArray(myArray2);



// 2D Array - 3

        int[][] myArray3 = {{5,2,3},{10,12,15}}; 
        print2DArray(myArray3);



// 2D    Array -4 

           int[][] myArray = {
                            {33, 71},
                            {-16, 45, 50, -7},
                            {99}
                          };

        System.out.println("myArray.length = " + myArray.length);
        System.out.println("myArray[0].length = " + myArray[0].length);
        System.out.println("myArray[1].length = " + myArray[1].length);
        System.out.println("myArray[2].length = " + myArray[2].length);



// 2D    Array -5 

           int[][] myArray5;
           myArray5    = new int[3][];
           myArray5[0] = new int[6];
           myArray5[1] = new int[4];
           myArray5[2] = new int[2];
         
           print2DArray(myArray5);

         System.out.println("using deepToString " + Arrays.deepToString(myArray));      //SE5

    }

public static void print2DArray(int[][] twodarray){

      System.out.println("Array elements are:"); 

for(int i=0; i < twodarray.length; i++)
     {
         
      
         for(int j=0; j < twodarray[i].length; j++)
                       
        
        {
            System.out.print( twodarray[i][j]);
            System.out.print("  ");
        }

       System.out.println();
     }


}


}

// prints a ragged array contents