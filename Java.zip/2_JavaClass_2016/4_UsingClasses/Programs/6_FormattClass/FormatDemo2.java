 import java.text.*;
 import java.util.Locale;
 
 class FormatDemo2
 {
      public static void main(String args[]) 
      {
         NumberFormat nfn, nfc, nfp;
         String nfx, cfx, pfx;
         DecimalFormat df;
         double x,y;
 
         System.out.println("Defining custom format...");
         x = 1234.510;
         y = .740;
         System.out.println
 ("\nBefore applying format...");
         System.out.println("x = " + x);
         System.out.println("y = " + y);
 
    System.out.println
 ("\nAfter setting format to #.00000");
         df = new DecimalFormat("#.00000");
         System.out.println("x = " + df.format(x));
         System.out.println("y = " + df.format(y));

 System.out.println
 ("\nAfter setting format to #.#####");
         df = new DecimalFormat("#.#####");
         System.out.println("x = " + df.format(x));
         System.out.println("y = " + df.format(y));

         System.out.println
 ("\nAfter setting format to ,##0.00");
         df = new DecimalFormat(",##0.00#");
         System.out.println("x = " + df.format(x));
        System.out.println("y = " + df.format(y));
 
         System.out.println
 ("\nAfter setting format to " + 
  " $,##0.00;($,##0.00)");
         df = new DecimalFormat("Rs ,##0.00;($,##0.00)");
         System.out.println("x = " + df.format(x));
 
         x = -1234.5;
         System.out.println("\nThe new value of x = " 
 + x);
         System.out.println("\nAfter setting format to" 
 + " $,##0.00;($,##0.00)");
         System.out.println("x = " + df.format(x));
 
         x = 10000.0 / 3.0;
         System.out.println("\nThe new value of x = " 
 + x);
         try
        {
         System.in.read();
         }
         catch (java.io.IOException e)
        {
          System.out.println("\n io caught");
        } 
nfn = NumberFormat.getNumberInstance(Locale.US);
         nfc = 
 NumberFormat.getCurrencyInstance(Locale.US);
    nfp =     
      NumberFormat.getPercentInstance(Locale.US);
 
         nfx = nfn.format(x);
         cfx = nfc.format(x);
         pfx = nfp.format(x);
 
         System.out.println("\nNumber formatted..");
         System.out.println("x = " + nfx);
         System.out.println("Currency formatted..");
         System.out.println("x = " + cfx);
         System.out.println("Percent formatted..");
         System.out.println("x = " + pfx);
 
         System.out.println("\nAfter Setting \n\r" 
 + " the minimum integer digits to 6\n\r" 
 + " and maximum fraction digits to 4..");
         nfn.setMinimumIntegerDigits(6);
         nfn.setMaximumFractionDigits(4);
 
         nfx = nfn.format(x);
         cfx = nfc.format(x);
         pfx = nfp.format(x);
 
         System.out.println("\nNumber formatted..");
         System.out.println("x = " + nfx);
         System.out.println("Currency formatted..");
         System.out.println("x = " + cfx);
         System.out.println("Percent formatted..");
         System.out.println("x = " + pfx);
 
         System.out.println("\nAfter Setting \n\r" 
 + " the maximum integer digits to 3\n\r" 
 + " and minium fraction digits to 0..");
         nfn.setMaximumIntegerDigits(3);
         nfn.setMinimumFractionDigits(0);
         
         try
         {
         System.in.read();
         }
         catch(java.io.IOException e)
         {
          System.out.println(" \n io caught");
        }
         nfx = nfn.format(x);
         cfx = nfc.format(x);
         pfx = nfp.format(x);
 
         System.out.println("\nNumber formatted..");
         System.out.println("x = " + nfx);
         System.out.println("Currency formatted..");
         System.out.println("x = " + cfx);
         System.out.println("Percent formatted..");
         System.out.println("x = " + pfx);
 
       System.out.println
 ("\nAfter changing the locale to German..");
       nfn = 
 NumberFormat.getNumberInstance(Locale.GERMAN);
       nfc = 
    NumberFormat.getCurrencyInstance(Locale.GERMAN);
       nfp = 
    NumberFormat.getPercentInstance(Locale.GERMAN);
 
         nfx = nfn.format(x);
         cfx = nfc.format(x);
         pfx = nfp.format(x);
 
         System.out.println("Number formatted..");
         System.out.println("x = " + nfx);
         System.out.println("Currency formatted..");
         System.out.println("x = " + cfx);
         System.out.println("Percent formatted..");
         System.out.println("x = " + pfx);
      }
 } 
