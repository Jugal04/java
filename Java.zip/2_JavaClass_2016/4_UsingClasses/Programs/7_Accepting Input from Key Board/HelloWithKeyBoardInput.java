// Program accepting key board input 


public class HelloWithKeyBoardInput{

   public static void main(String args[]){
          int i=0;
          
        try{
             i = System.in.read();
            }
        catch(Exception e){
            }
          char c = (char)i;

         System.out.println("You have entered i " + i);  
         System.out.println("You have entered the character  " + c);     
         
     
     }
}


/****************************************************************************************************************************


- System.in.read() reads key board input 

- It is similar to your getch() of C 

- Since it is likely to throw a checked exception , it has to be enclosed in try - catch   blocks. 

- You will learn about exceptions later 

****************************************************************************************************************************/