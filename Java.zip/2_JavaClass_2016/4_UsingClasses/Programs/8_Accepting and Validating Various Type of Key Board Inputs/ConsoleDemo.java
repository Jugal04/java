
// A java application using Console.java 


 class ConsoleDemo
 {
         public static void main(String args[])
         {
                 String name;
                 int age;
                 double height;
                 char gender;
 
                 System.out.print
 ("Enter Your Name.....:");
                 name = Console.readString();
 
                 System.out.print
 ("Enter Your Age......:");
                 age = Console.readInt();
 
                 System.out.print
 ("Your Height(in cms).:");
                 height = Console.readDouble();
 
 
                 System.out.print
 ("Your Gender(M/F)....:");
                 gender = Console.readChar();
 
                 System.out.println("");
                 System.out.println("Hello " + name);
                 System.out.println
 ("Your age is " + age);
                 System.out.println
    ("Your height is " + height + " cms");
 
                 if (gender == 'M')
                 {
                      System.out.println
 ("You are a Male");
                 }
                 else
                 {
                     System.out.println
 ("You are a Female");
                 }
         }
 } 


