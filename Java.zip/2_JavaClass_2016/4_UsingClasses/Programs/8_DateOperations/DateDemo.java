import java.util.*;
//Date Demo

 public class Employee {
 public int id;
 public string name;
 public Day hireDate;
 public Day birthDate;

public Employee(int id,String name, Day hireDate, Day birthDate){
 this.id = id;
 this.name =  name;
 this.hireDate =  hireDate;
 this.birthDate =  birthDate;
}

 public static void main(String args[]) {

 Employee employee = new Employee(123,"Ganesh", new Day(2016,8,1), new Day(1996,1,1));

                
         }
 } 


