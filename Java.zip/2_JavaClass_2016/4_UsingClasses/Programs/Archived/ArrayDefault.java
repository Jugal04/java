class ArrayDefault
{
    public static void main(String args[])
    {
        int[] intArray = new int[5];

        int[] intArray2;
        intArray2 = new int[4];
         
        int[] intArray3 = {10,9,8,7};



        char[] charArray = new char[5];
        double[] doubleArray = new double[5];
        boolean[] booleanArray = new boolean[5];
        String[] strArray = new String[5];

        System.out.println("int Array...");
        for(int i=0; i < 5; i++)
        {
            System.out.print(intArray[i] + " ");
        }

        System.out.println("\n");
        System.out.println("char Array...");
        for(int i=0; i < 5; i++)
        {
            System.out.print((int)charArray[i] + " ");
        }

        System.out.println("\n");
        System.out.println("double Array...");
        for(int i=0; i < 5; i++)
        {
            System.out.print(doubleArray[i] + " ");
        }

        System.out.println("\n");
        System.out.println("boolean Array...");
        for(int i=0; i < 5; i++)
        {
            System.out.print(booleanArray[i] + " ");
        }

        System.out.println("\n");
        System.out.println("String Array...");
        for(int i=0; i < 5; i++)
        {
            System.out.print(strArray[i] + " ");
        }
    }
}
