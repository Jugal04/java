// Demonstrates  that an array is an object and it is a reference to //the value

class ArrayDemo
{
 public static void main(String args[])
 {

  System.out.println("\nArray a:\n");
  int[] a= {5,4,7,3,6,9,100,2,10,1000};
  printArray(a);

  // When the Array a is assigned to Array b,the reference of a is assigned to b
  // So When Array b's elements are changed a also changes

  int[] b=a;
  System.out.println("\n\nArray b:\n");
  printArray(b);


  b[0]=1;
  b[1]=2;

  System.out.println("\n\n\nAfter making changes in the first two      elements of b:\n");
  System.out.println("\nArray b:\n");
  printArray(b);
  System.out.println("\n\nArray a also changes:\n");
  printArray(a);

 // When the Array a is copied to Array c,with System.arraycopy()
 //the value of a is assigned to c 
 // but c holds a refernce to a new array object
 // So When Array c's elements are changed a remains unchanged

  int[] c={0,0,0,0,0,0,0,0,0,0};
  System.out.println("\n\nArray c:\n");
  printArray(c);

  System.arraycopy(a,0,c,0,9);
  System.out.println("\n\nAfter copying Array a to c,Array c:\n");
  printArray(c);

  System.out.println("\n\n\nAfter making changes in the first two      elements of c:\n");
  c[0]=111;
  c[1]=222;

  
  System.out.println("\nArray c:\n");
  printArray(c);
  System.out.println("\n\nArray a has no changes\n");
  System.out.println("\nArray a:\n");
  printArray(a);

  System.out.println("\n");
 }
 public static void printArray(int[] a)
 {
  for(int i=0;i<=(a.length-1);i++)
  {
   System.out.print(a[i] +" ");
  }
 }
}

// System.arraycopy(fromArray,fromIndex,toArray,toIndex,elementCount)