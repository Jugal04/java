class ArrayDemo
{
    public static void main(String args[])
    {
        System.out.println
                ("Array Initialization...");
        int[] b = {2, 1, 5, 3, 4};
        printArray(b);
        System.out.println
            ("\n\nBefore Array " + "Copy...");
        int[] c= {0, 0, 0, 0, 0};
        printArray(c);
        System.arraycopy(b, 0, c, 1, 4);
        System.out.println("\n\nAfter Array"
                            + "Copy...");
        printArray(c);
    }

    public static void printArray(int[] nos)
    {
        for (int i=0; i<=(nos.length-1); i++)
        {
            System.out.print(nos[i] + " ");
        }
    }
}
