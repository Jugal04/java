/* Demonstrates the automatic conversion of primitive data types into the respective 
*  wrapper classes and vice versa

* There is no need to explicitly create a wrapper class object using the new key word, as was done in earlier versions.

*/

class AutoBoxingTest{

  public static void main(String args[]){
  
  Integer I;
  Integer I2;

  int i;
  int i2;

  I  = 0;
  I2 = 30;

   i = 100;
  i2 = 0;


  

  System.out.println("I is " + I);
  System.out.println("i is " + i);

  I = i;

  System.out.println("I after assinment from i is " + I);



 System.out.println("I2 is " + I2);
 System.out.println("i2 is " + i2);

 i2 =I2;
 System.out.println("i2 after assinment from I2is " + I2);


}
}

