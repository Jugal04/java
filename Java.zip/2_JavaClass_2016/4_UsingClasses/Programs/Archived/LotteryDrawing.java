class LotteryDrawing
{
    public static int[] drawing(int low, int high)
    {
        int[] nos = new int[5];
        for(int i=0; i<=4; i++)
        {
            nos[i] = (int) ((high - low +1) * Math.random()) + low;
        }
        return (nos);

    }
    public static void main(String args[])
    {
        int[] a;
        int min, max;
        System.out.print("Enter min value...:");
        min = Console.readInt();
        System.out.print("Enter max value...:");
        max = Console.readInt();
        a= drawing(min,max);
        System.out.println("The drawn numbers...");
        for (int i=0; i<=4; i++)
        {
            System.out.println(a[i]);
        }
    }
}
