import java.text.*;

class MatrixMultiplication
{
    final static int ROWS = 2;
    final static int COLS = 2;

    public static void main(String[] args)
    {
        int[][] a = new int[ROWS][COLS];
        int[][] b = new int[ROWS][COLS];
        int[][] c = new int[ROWS][COLS];

        System.out.println("Enter 4 integers for MATRIX-A...");
        readArray(a);

        System.out.println("Enter 4 integers for MATRIX-B...");
        readArray(b);

        for (int i=0; i <= (ROWS-1); i++)
        {
            for (int j=0; j <= (COLS-1); j++)
            {
                c[i][j] = 0;

                for (int k=0; k <= (COLS-1); k++)
                {
                    c[i][j] = c[i][j] + a[i][k] * b[k][j];
                }
            }
        }

        System.out.println("MATRIX-A...");
        printArray(a);

        System.out.println("MATRIX-B...");
        printArray(b);

        System.out.println("MATRIX-C...");
        printArray(c);
    }

    public static void readArray(int[][] array)
    {
        for (int i=0; i <= (ROWS-1); i++)
        {
            for (int j=0; j <= (COLS-1); j++)
            {
                array[i][j] = Console.readInt();                
            }
        }
    }

    public static void printArray(int[][] array)
    {
        for (int i=0; i <= (ROWS-1); i++)
        {
            DecimalFormat df = new DecimalFormat("000");
            
            for (int j=0; j <= (COLS-1); j++)
            {
                String result = df.format(array[i][j]) + " ";
                result = replaceLeadZeros(result);
                System.out.print(result);
            }
            System.out.println();
        }
    }

    public static String replaceLeadZeros(String str)
    {
        String temp="";
        int i;

        for (i=0; i <= (str.length()-1); i++)
        {
            if (str.charAt(i) == '0')
            {
                temp = temp + " ";
            }
            else
            {
                break;
            }
        }

        temp = temp + str.substring(i);
        return (temp);
    }
}
