class SortExample
{
    public static void main(String args[])
    {
        System.out.println("Array Declaration and"
        + "Memory Allocation...");
        int[] a = new int[5];
        System.out.println("\nBefore Reading"
                            + "Values...");
        printArray(a);
        System.out.println
            ("\nEnter 5 " + " Integers...");
        readArray(a);
        System.out.println
            ("After Reading " + " Values...");
        printArray(a);
        sort(a);
        System.out.println
            ("\nAfter Sorting...");
        printArray(a);
    }

    public static void sort(int[] nos)
    {
        for (int i=0; i<=(nos.length-2); i++)
        {
            for (int j=(i+1); j<=(nos.length-1); j++)
            {
                if (nos[i] > nos[j])
                {
                    int temp = nos[i];
                    nos[i]   = nos[j];
                    nos[j]   = temp;
                }
            }
        }
    }
    public static void printArray(int[] nos)
    {
        for (int i=0; i<=(nos.length-1); i++)
        {
            System.out.print(nos[i] + " ");
        }
    }

    public static void readArray(int[] nos)
    {
        for (int i=0; i<=(nos.length-1); i++)
        {
            nos[i] = Console.readInt();
        }
    }
}
