public class StringAssignment{

public static void main(String[] args){

String name = new String("Ganesh");
String copyOfName = name;
System.out.println("copy of name is  " +copyOfName);
name = new String("Shankar");
System.out.println("copy of name is  " +copyOfName);
}
}