import java.io.*;

// Demonstrates the various methods of StringBuffer class


class StringBufferDemo
{
 public static void main(String args[]) throws Exception
 {

  
  StringBuffer sb = new StringBuffer("You are welcome");

  System.out.println("The StringBuffer sb is " + sb);



  int theLength=sb.length();
  int theCapacity=sb.capacity();
  

  System.out.println("The Length of the String is " + theLength);
  System.out.println("The Capacity of the Buffer is " + theCapacity);


  
  // Specified Length is set

  sb.setLength(8);
  System.out.println("The StringBuffer sb after setting length (decrease in the length) now is " + sb);

  StringBuffer sbnew = sb.append(" always invited");
  System.out.println("The StringBuffer sb after using append statement is "+ sbnew);

  // Changes the capacity from the default value to the specified value

  sb.ensureCapacity(70);


  // Inserting a string

  sb.insert(15," warmheartedly");
  System.out.println("After inserting a string sb  becomes" + sb);


  // Creating a String Object from a StringBuffer Object

  String Welcome=sb.toString();
  System.out.println("The String Object Welcome is " + Welcome);




  // A new StringBuffer object is created specifying the capacity

  StringBuffer newString = new StringBuffer(50);

  int StrCapacity=newString.capacity();
  System.out.println("Capacity of new String is "+ StrCapacity);

  newString = new StringBuffer("Hello how are you");
  System.out.println("The new StringBuffer is " + newString);

  int newStringLength = newString.length();
  int newStringCapacity= newString.capacity();

  System.out.println("The Length of new String is " + newStringLength);
  System.out.println("The Capacity of the new buffer is " + newStringCapacity);

  StringBuffer newString2 = newString.append("? ").append(" I").append(" am")
                                        .append(" fine").append(" i expect the same"); 
  System.out.println("The StringBuffer newString after the usage of append statement is " + newString2);


  int newStrLength = newString.length();

  System.out.println("The length now is " + newStrLength);


  int newStrCapacity= newString.capacity();
  System.out.println("The capacity now is " + newStrCapacity);





 }
}
                


/*
StringBuffer
-------------

- Similar to String Class
                                              
- But mutable

- When created the default capacity is 32 bytes

               length will be 0

- Can specify capacity

- when length exceeds capacity, capacity is doubled + 2   normally
*/
