import java.util.*;

public class DateDemo{

public static void main(String[] args){
GregorianCalendar currentDate = new GregorianCalendar();
System.out.println("Current Date is : " + currentDate);











}


}