import java.util.*;   // error no coorect output
import java.text.*;

public class DateTest{
   public static void main(String[] args){
   Date date = new Date();
   System.out.println("current date is " +date);

   Date  date2 = new Date(2015,9,28);
   String str = String.format("Given  Date/Time : %tc", date2);
   System.out.printf(str);
    }
}