/* 

 * Conventions-class,field,method name;pvt methods, init data, use a class in place of many basic types (Address),
   set,gets on need basis.

 ******Instance members********
 * Scope
 * Lifetime
 * Initial value

 * Access specifiers
 * Instantiation 
 * Object Variables

*/


class Man{

        private String name;
        private int age;
	
	public void setName(String name){
			
			this.name = name;
	}
	
	public String getName(){

		return this.name;
	}

        public void setAge(int age){    // can also add  more functionality 
               this.age =  age;
        }

        public int getAge(){
          return this.age;

        }
      

	public void speak(){
		System.out.println(getName() + " is speaking now");
	}

     

}


class ManDemo3{

	public static void main(String[] args){
		Man ram;
		
		ram = new Man();
		
		ram.setName("RamKumar");
                                ram.setAge(20);
		
		System.out.println("ram's name is " + ram.getName());
                                System.out.println("ram's age is " + ram.getAge());
		ram.speak();
	}
}
