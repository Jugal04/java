/* 

 * Scope
 * LifeTime
 * Initialisation

*/


 class MyObject
 {
   static short s = 400;  // Static variable
   int i = 200;           // Instance variable
 
   void f()
   {
     System.out.println("Before declaring local" 
       + " variables \n with the same name"
       + " as member variables :"); 
     System.out.println("s = " + s);
     System.out.println("i = " + i);
 
     short s = 300;     // Local variable
     float i = 100;     // Local variable
     double d = 1200.00;  // Local variable
 
     System.out.println();
     System.out.println("After declaring local" 
       + " variables \n with the same name"
       + " as member variables :"); 
     System.out.println("s      = " + s);
     System.out.println("this.s = " + this.s);
     System.out.println("i      = " + i);
     System.out.println("this.i = " + this.i);
     System.out.println("d = " + d);
   }
 }
 
 class LocalVariables
 {
   public static void main(String args[])
   {
     MyObject myObject = new MyObject();
     myObject.f();
   }
 }
