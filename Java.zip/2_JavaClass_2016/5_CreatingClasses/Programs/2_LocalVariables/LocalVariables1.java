/* 

 * Scope
 * LifeTime
 * Initialisation

*/


 class MyObject
 {
    int d;
   
   void f()
   {
      int d =0;
       d=5;
       
         {
             int e;
             e = 10; 
             System.out.println("d from sub block= " + d);
             System.out.println("e from sub block= " + e);
              }

     System.out.println("d from main block = " + d);
     // System.out.println("e from main block= " + e); uncomment for error
   }
 }
 
 class LocalVariables1
 {
   public static void main(String args[])
   {
     MyObject myObject = new MyObject();
     myObject.f();
   }
 }
