class Box{
 public int length=20;
 public int breadth=10;
 public int height= assignHeight();

 public  int assignHeight(){
  return  length + breadth +1;
 }
}
class InitByMethod
{
 public static void main(String args[])
 {

   Box Box1= new Box();

  System.out.println("\n Length: " + Box1.length);
  System.out.println("\n Breadth:" + Box1.breadth);
  System.out.println("\n Height: " + Box1.height);
 }

}

