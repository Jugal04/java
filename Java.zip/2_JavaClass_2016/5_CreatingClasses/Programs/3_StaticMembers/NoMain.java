

class NoMain{
  static{
 
      System.out.println("Hello, how are you");
      System.exit(0);
     }
  }
