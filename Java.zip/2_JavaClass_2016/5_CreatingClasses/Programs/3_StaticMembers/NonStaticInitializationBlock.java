class X
{
 int array[];

 
 {
  array = new int[3];

  for(int i=0;i<3;i++)
  {
   array[i]=i;
  }
 }

}


class NonStaticInitializationBlock
{
 public static void main(String args[])
 {
  System.out.println("x1[]: " );

  int[] x1 = new int[3];

  for(int i=0;i<3;i++)
  {
   x1[i]=i;
  }
  for(int i=0;i<3;i++)
  {
   if(i == 2)
   {
    System.out.println(x1[i]);
   }
   else
   {
    System.out.print(x1[i] + ",");
   }
  }
 }
}

