class NonStaticBox
{
 public int length=20;
 public int breadth;
 public int height;

 {
  breadth=length/2;
  height=(length+breadth)/2;
 }

}

class NonStaticInitializationBlock2
{
 public static void main(String args[])
 {

  NonStaticBox Box1= new NonStaticBox();

  System.out.println("\n Length: " + Box1.length);
  System.out.println("\n Breadth:" + Box1.breadth);
  System.out.println("\n Height: " + Box1.height);
 }

}

