class Box{

int lenth;
int width;
int height;

static double basePrice = 3000;

static String brand ="American Tourister";

public static String getBrand(){
return brand;
}

public static double getBasePrice(){
return basePrice;
}

}

class StaticMethod2 {
  public static void main(String args[]) {
    System.out.println(Box.getBrand());
 System.out.println(Box.getBasePrice());


  }
}