
/* 

 * Scope
 * LifeTime
 * Initialisation

*/

class Pen {
  static int count=0;
 
  String name;

 
}

class StaticVariable2 {

  public static void main(String args[]) {

    Pen pen = new Pen();
    Pen.count++;

    Pen pen2 = new Pen();
    Pen.count++;
   
         System.out.println("No of objects  " + Pen.count);

    // pen.count, pen2.count will work; not recommended
  }
}
