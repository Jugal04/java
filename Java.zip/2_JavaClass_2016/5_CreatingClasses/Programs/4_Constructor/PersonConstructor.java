 class Person
{
  String name;
  int age;
  float salary;

  public Person(String name, int age, float salary)
  {
    this.name = name;
    this.age = age;
    this.salary = salary;
   }
}

class PersonConstructor
{

  public static void main(String args[])
  {
    Person p = new Person("John Doe", 21, 29100f);
    System.out.println("Attributes of Person p \n");

    System.out.println("p.name = " + p.name);
    System.out.println("p.age = " + p.age);
    System.out.println("p.salary = " + p.salary);
  }

}
