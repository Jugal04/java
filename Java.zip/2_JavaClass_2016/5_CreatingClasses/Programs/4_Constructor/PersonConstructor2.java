// Program to demonstrate the creation and use of Constructors 

class Person                          // also define the class as public
{
  String name;
  int age;
  float salary;

  public Person(String name, int age, float salary)
  {
    this.name = name;
    this.age = age;
    this.salary = salary;
   }
}

class PersonConstructor2
{

  public static void main(String args[])
  {
    Person p = new Person("John Doe", 21, 29100.00f);
    System.out.println("Attributes of Person p");

    System.out.println("p.name = " + p.name);
    System.out.println("p.age = " + p.age);
    System.out.println("p.salary = " + p.salary);
  }

}

//setters vs constructors

/************************************************************************************************************************

CONSTRUCTORS 
--------------

What is a constructor 
---------------------

- Constructor is a special type of method in java 

- It has the same name as the class . 

- If Box is the class name then Box() is the constructor for the Box class 


How Java uses the constructor 
------------------------------

- Java creates the object in dynamic memory with the help of the key word new. 

- Then it calls the constructor. 

- Uses the constructor to initialize the object. 

- The Default Constructor 

- For every class you define, Java provides a default constructor, internally. 

- A constructor without any arguments is called a default constructor. 
               (e.g) Box() 

- The default constructor provided by java is do-nothing-constructor

- Numeric variables are initialized with zero, char variables with "backslashu000", Boolean with false and objects with null by java   during object creation

- Then it makes a call to the constructor


User Defined Constructor 
------------------------
- The developer can provide his own constructor to initialize the object variables. 

- So, the object variables are initialized, soon after the object is created. 

- Such a constructor looks like this: 




Box(double alength, double awidth, double aheight){
            length = alength;
            width = awidth; 
            height= aheight;
            } 
            where  length, width and height are data members of the Box class.



What happens when you provide your own constructor 
--------------------------------------------------

- When you provide your own constructor, java compiler will not provide the usual default (no args) constructor. 

- So, in the above example, Box new Box() will give error. 

- It is always a good programming practice to provide a default constructor in such cases. 


Other Features of Constructors 
---------------------------------

- Constructors are normally public. 

- They do not have any return type. 

- But you should not use the key word void. 

- You cannot call a constructor directly. 

- It is always associated with the key word new. 


Overloading of Constructors 
----------------------------

- A class can have more than one constructor, each with a different signature. 

- In that case, constructors are said to be overloaded. 

- The following three constructors are overloaded 


Box(){}

Box(double alength, double awidth,  double aheight) {
                length = alength;
                 width = awidth; 
                 height= aheight;
            }

Box(double alength){
       length = alength;
                 }

- Java will invoke the appropriate constructor, based on the arguments you pass during object creation. 

- Overloading methods will be discussed in detail later. 


Calling a Constructor from a Constructor of the same class 
-------------------------------------------------------------

- You can call one constructor from another constructor of the same class. 

- You use the this() method for achieving this. 

Look at the following example: 

         Box(double alength, double awidth,  double aheight) {
       this( alength);       // invokes the specific constructor        
                                                                       // defined in this class earlier
       width = awidth; 
       height= aheight;
 }


- this key word always refers to the currently executing object. 

- Call to this() should be the very first statement, if present. In a constructor. 

- Java Runtime calls the appropriate constructor, based on the arguments you pass to the this() method. 


Calling Super Class Constructor 
--------------------------------

- When you extend a base class, the public and protected members are inherited. 

- But the constructors of the base class are not inherited. 

- Inheritance will be covered in detail later. 

- When you create a derived class object, the base class part of the object is created first. 

- Java achieves this by calling the base class default constructor. 

- If the base class does not contain a default constructor (this can happen, if you provide your own all arguments constructor in the base class but omit to supply a default (no args) constructor), it will result in error. 

- You can avoid this situation by ensuring that your base class always has a default constructor, either java supplied or programmer supplied. 

- Alternatively, you can invoke the specific base class constructor by using the method super() with the necessary arguments. from the derived class constructor. 

- Look at this example 

Our Box class as of now has three overloaded constructors including the default constructor. 
You derive SmallBox from Box class. 

  public class SmallBox extends Box

     double weight;
   {
     SmallBox()                // will call the default   
                          //constructor of Box
     {    �    
                          .
     }


    SmallBox(double alength, double awidth, double aheight,   
                                       double aweight)

    {
     super(alength, awidth, aheight);
            // calls the specific constructor of the super
            // class
     weight = aweight;
    }
*************************************************************************************************************************



*/



