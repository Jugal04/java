// Program to demonstrate the creation and use of  Overloaded Constructors 


class Person
{
  String name;
  int age;
  float salary;

 public  Person(String name, int age, float salary)
  {
    this.name = name;
    this.age = age;
    this.salary = salary;
   }


Person()
{

}



Person(String name)
{
this.name = name;
}


Person(String name, int age)
{
this(name);
this.age = age;
}


}

class PersonConstructorOverLoaded
{

  public static void main(String args[])
  {
    Person p = new Person("John Doe", 21, 29100f);
          System.out.println("Attributes of Person p");
          System.out.println("p.name = " + p.name);
          System.out.println("p.age = " + p.age);
          System.out.println("p.salary = " + p.salary);

    
    Person p1 = new Person();
        System.out.println("Attributes of Person p1");
        System.out.println("p1.name = " + p1.name);
        System.out.println("p1.age = " + p1.age);
        System.out.println("p1.salary = " + p1.salary);
 

    Person p2 = new Person("John Doe");
        System.out.println("Attributes of Person p2");
        System.out.println("p2.name = " + p2.name);
        System.out.println("p2.age = " + p2.age);
        System.out.println("p2.salary = " + p2.salary);
 

         
    Person p3 = new Person("John Doe", 21);

        System.out.println("Attributes of Person p3");
        System.out.println("p3.name = " + p3.name);
        System.out.println("p3.age = " + p3.age);
        System.out.println("p3.salary = " + p3.salary);
 

   
   }

}


