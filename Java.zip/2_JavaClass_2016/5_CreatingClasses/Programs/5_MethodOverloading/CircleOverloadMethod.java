 class Circle
 {
   double x;
   double y;
   double radius;
 
   Circle(double x, double y, double radius)
   {
     this.x = x;
     this.y = y;
     this.radius = radius;
   }
 
   void move(double x)
   {
     this.x = x;
   }
 
   void move(double x, double y)
   {
     this.x = x;
     this.y = y;
   }
 
   public String toString()
   {
     String str;
     str = "x      = " + x;
     str = str + "\n" + "y      = " + y;
     str = str + "\n" + "radius = " + radius;
     return str;
   }
 }
 
 class CircleOverloadMethod
 {
   public static void main(String args[])
   {
     Circle c = new Circle(1,2,10);
     System.out.println("Circle after construction :");
     System.out.println(c);
 
     c.move(0);
     System.out.println();
     System.out.println("Circle after c.move(0) : ");
     System.out.println(c);
 
     c.move(-3, -6);
     System.out.println();
     System.out.println("Circle after c.move(-3, -6) :");
     System.out.println(c);
   }
 }
