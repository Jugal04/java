// differ in number of parameters

class MethodOverload1
{
 public int a;
 public int b;
 public int c;

 public void add(int a,int b)
 {
  int Sum1 = a + b;
  System.out.println("\n\n\n The method add(int a,int b) is being called: ");
  System.out.println("\n The Sum of the two Numbers is " + Sum1);
 }

 public void add(int a,int b,int c)
 {
  int Sum2 = a + b + c;
  System.out.println("\n\n\n The method add(int a,int b,int c) is being called: ");
  System.out.println("\n The Sum of the three Numbers is " + Sum2);
 }

}

public class MethodOverloadDemo1
{
 public static void main(String args[])
 {
  MethodOverload1 Sum= new MethodOverload1();
  Sum.add(2,2);
  Sum.add(2,2,2);
 }
}

  
