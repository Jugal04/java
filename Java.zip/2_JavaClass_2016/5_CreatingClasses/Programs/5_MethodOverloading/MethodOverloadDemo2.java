// differ in order of parameters

class MethodOverload2
{
 public int a=5;
 public char b='A';

 public void display(int a,char b)
 {
  
  System.out.println("\n\n\n The method add(int a,char b) is being called: ");
  System.out.println("\n The Value of int a & char b are " + a+","+b);
 }

 public void display(char b,int a)
 {
  
  System.out.println("\n\n\n The method add(char b,int a) is being called: ");
  System.out.println("\n The Value of char b & int a are " + b+"," + a);
 }

}

public class MethodOverloadDemo2
{
 public static void main(String args[])
 {
  MethodOverload2 Display= new MethodOverload2();
  Display.display('A', 25);
  Display.display(2,'B');


 }
}

  
