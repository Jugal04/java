//differ in type of parameters

class MethodOverload3
{

 public void add(int a,int b)
 {
  int Sum1 = a + b;
  System.out.println("\n\n\n The method add(int a,int b) is being called: ");
  System.out.println("\n The Sum of the two Numbers is " + Sum1);
 }

 public void add(int a,double b)
 {
  double Sum2 = a + b ;
  System.out.println("\n\n\n The method add(int a,double b) is being called: ");
  System.out.println("\n The Sum of the three Numbers is " + Sum2);
 }

}

public class MethodOverloadDemo3
{
 public static void main(String args[])
 {
  MethodOverload3 Sum= new MethodOverload3();
  Sum.add(2,2);
  Sum.add(3,0.1);
  }
}

  
