
// Demonstrates that a method with same data type variables
// cannot be overloaded with another return type
// Will give compilation error

class MethodOverload4
{

 public int add(int a,int b)
 {
  int Sum1 = a + b;
  System.out.println("\n\n\n The method int add(int a,int b) is being called: ");
  System.out.println("\n The Sum(int) of the two Numbers is " + Sum1);
  return(Sum1);
 }

 public long add(int a,int b)
 {
  int Sum2 = a + b;
  System.out.println("\n\n\n The method long add(int a,int b) is being called: ");
  System.out.println("\n The Sum(long) of the two Numbers is " + Sum2);
  return(Sum2);
 }
  
}

public class MethodOverloadDemo4
{
 public static void main(String args[])
 {
  MethodOverload4 Sum= new MethodOverload4();
  Sum.add(3,3);
  Sum.add(2,2);
 }
}

  
