 class CallByValue
 {
   public static void main(String args[])
   {
     // Initialize variables
     int i = 5;
     int j[]  = { 1, 2, 3, 4 };
     StringBuffer sb = new StringBuffer("abcde");
 
     // Display variables
     System.out.println("Before calling a() :");
     display(i, j, sb);
 
     // Call method
     a(i, j, sb);
 
     // Display variables again
     System.out.println();
     System.out.println("After calling a() :");
     display(i, j, sb);
   }
 
   static void a(int fi, int fj[], StringBuffer fsb)
   {
     fi = 7;
     fj[0] = 11;
     fsb.append("fghij");
   }
 
   static void display(int i, int j[], StringBuffer sb)
   {
     System.out.println("i.... : " + i);
     System.out.print("j[].. : ");
     for(int index = 0; index < j.length; index++)
     {
       System.out.print(j[index] + " ");
     }
     System.out.println("");
     System.out.println("sb... : " + sb);
   }
 }
