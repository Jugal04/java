/* You should use enum types any time you need to represent a fixed set of constants. That includes natural enum types such as the planets in our solar system and data sets where you know all possible values at compile time�for example, the choices on a menu, command line flags, and so on.
*/


enum Day {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY,
    THURSDAY, FRIDAY, SATURDAY 
}



class EnumUsage {
    Day day;
    
    public EnumUsage(Day day) {
        this.day = day;
    }
    
    public void tellItLikeItIs() {
        switch (day) {
            case MONDAY:
                System.out.println("Mondays are bad.");
                break;
                    
            case FRIDAY:
                System.out.println("Fridays are better.");
                break;
                         
            case SATURDAY: case SUNDAY:
                System.out.println("Weekends are best.");
                break;
                        
            default:
                System.out.println("Midweek days are so-so.");
                break;
        }
    }
    
    public static void main(String[] args) {
        EnumUsage firstDay =
           new EnumUsage(Day.MONDAY);
        firstDay.tellItLikeItIs();
        EnumUsage thirdDay =
           new EnumUsage(Day.WEDNESDAY);
        thirdDay.tellItLikeItIs();
        EnumUsage fifthDay =
           new EnumUsage(Day.FRIDAY);
        fifthDay.tellItLikeItIs();
        EnumUsage sixthDay =
           new EnumUsage(Day.SATURDAY);
        sixthDay.tellItLikeItIs();
        EnumUsage seventhDay =
           new EnumUsage(Day.SUNDAY);
        seventhDay.tellItLikeItIs();
    }
}
