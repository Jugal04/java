/* You should use enum types any time you need to represent a fixed set of constants. 
*/


enum Speed{

    SLOW,HIGH,MEDIUM;
}



class Vehicle {
    String brand;
    Speed speed;
    
    public Vehicle(String brand, Speed speed) {
        this.brand =  brand;
        this.speed = speed;
    }
    public String toString(){

      return this.brand +"  "+ this.speed;
    }
}
   

class EnumUsage2{
    
    public static void main(String[] args) {
    Vehicle v1 = new Vehicle("Yamaha", Speed.HIGH);
    Vehicle v2 = new Vehicle("elephant", Speed.SLOW);
    System.out.println(v1);
    System.out.println(v2);
       
    }
}
