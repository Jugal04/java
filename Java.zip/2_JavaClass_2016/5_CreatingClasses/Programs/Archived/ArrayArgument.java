 class ArrayArgument
 {
   public static void main(String args[])
   {
     // Initialize variables
     int x[] = { 11, 12, 13, 14, 15 };
 
     System.out.println("Within main()...:");
     System.out.print("x[]...: ");
     // Display variables
     display(x);
 
     // Call method
     change(x);
 
     System.out.println();
     System.out.println("Within main() \n"
         + " after returning from change()...:");
     // Display variables
     System.out.print("x[]...: ");
     display(x);
   }
 
   public static void change(int fx[])
   {
     System.out.println();
     System.out.println("Within change()...:");
     System.out.println("fx[] before assigning"
 			  		 + " y[] to it...:");
     display(fx);
	
     fx[0] = 657;

     int y[] = { 21, 22, 23, 24, 25 };
     
     fx = y;
	
     fx[1] = 345;
 
     System.out.println("fx[] after assigning" 
 			  	 	  + " y[] to it...:");
     display(fx);
   }
 
   public static void display(int x[])
   {
     for(int i = 0; i < x.length; i++)
     {

       System.out.print(x[i] + " ");
     }
     System.out.println("");
   }
 }
