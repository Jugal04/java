class Bag
{
  boolean flag;
  int i, j = 2;
  double array1[] = { -3.4, 8.8e10, -9.2e-10 };
  double array2[] = new double[2];
  String s1, s2 = new String("Hello");
}

class BagTest
{
  public static void main(String args[])
  {
    Bag bag = new Bag();
    System.out.println("bag.flag = " + bag.flag);
    System.out.println("bag.i    = " + bag.i);

    System.out.print("bag.array1[] :");
    for(int i = 0; i < bag.array1.length; i++)
    {
      if (i == (bag.array1.length-1))
      {
         System.out.println(bag.array1[i]);
      }
      else
      {
         System.out.print(bag.array1[i] + ",");
      }
    }

    System.out.print("bag.array2[] :");
    for(int i = 0; i < bag.array2.length; i++)
    {
      if (i == (bag.array2.length-1))
      {
         System.out.println(bag.array2[i]);
      }
      else
      {
         System.out.print(bag.array2[i] + ",");
      }
    }

    System.out.print("bag.s1 :");    
    System.out.println(bag.s1);

    System.out.print("bag.s2 :");
    System.out.println(bag.s2);
  }
}
