class Box{

int i=10;
String s = "Ganesh";
static String st = "staticstring";
static int sint =2345;

void m1(){
System.out.println("m1");
}

static void m2(){

System.out.println("m2");
}
}

class SmallBox extends Box{

int i2=20;
void m3(){
System.out.println("m3");
}

public static void main(String args[]){
SmallBox sb = new SmallBox();
//System.out.println( "Box i in sb= " + sb.i);
System.out.println( "Box string in sb= " + sb.s);
System.out.println( "Box statstring in sb= " + sb.st);
System.out.println( "Box i in sb= " + sb.i);

}

}