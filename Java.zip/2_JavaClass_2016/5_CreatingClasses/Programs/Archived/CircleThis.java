class Circle
{
  double x;
  double y;
  double radius;

  Circle(double x)
  {
    this(x, 0, 1);
  }

  Circle(double x, double y)
  {
    this(x, y, 1);
  }

  Circle(double x, double y, double radius)
  {
    this.x = x;
    this.y = y;
    this.radius = radius;
  }
}

class CircleThis
{
  public static void main(String args[])
  {
    Circle c1 = new Circle(1.0);
    System.out.println("Attributes of the Circle object \n"
        + " constructed with Circle(1.0) :");
    System.out.println("c1.x = " + c1.x);
    System.out.println("c1.y = " + c1.y);
    System.out.println("c1.radius = " + c1.radius);

    Circle c2 = new Circle(11.1, 22.2);
    System.out.println();
    System.out.println("Attributes of the Circle object \n"
        + " constructed with Circle(11.1, 22.2) :");
    System.out.println("c2.x = " + c2.x);
    System.out.println("c2.y = " + c2.y);
    System.out.println("c2.radius = " + c2.radius);

    Circle c3 = new Circle(1.1, 3.4, 10);
    System.out.println();
    System.out.println("Attributes of the Circle object \n"
        + " constructed with Circle(1.1, 3.4, 10) :");
    System.out.println("c3.x = " + c3.x);
    System.out.println("c3.y = " + c3.y);
    System.out.println("c3.radius = " + c3.radius);
  }
}
  
