 import addons.Day;
 
 class Employee
 {
   private String name;
   private double salary;
   private Day hireDay;
 
   public Employee(String n, double s, Day d)
    {  name = n;
       salary = s;
       hireDay = d;
    }
 
    public void print()
    {  System.out.println("name ...... = " + name + "\n"
                       + "salary .... = " + salary + "\n"
                       + "hireYear .. = " + hireYear());
    }
 
    public void raiseSalary(double byPercent)
    {  salary *= 1 + byPercent / 100;
    }
 
    public int hireYear()
    {  return hireDay.getYear();
    }
 }
 
 public class EmployeeTest
 {
   public static void main(String[] args)
    {  Employee[] staff = new Employee[3];
 
       staff[0] = new Employee("Anand", 35000, 
 				new Day(1989,10,1));
       staff[1] = new Employee("Vishwanthan", 75000, 
 				new Day(1987,12,15));
       staff[2] = new Employee("Kumar", 38000, 
 			        new Day(1990,3,15));
       int i;
       for (i = 0; i < 3; i++) staff[i].raiseSalary(5);
       for (i = 0; i < 3; i++)
       {   staff[i].print();
           System.out.println();
       }
    }
 }
