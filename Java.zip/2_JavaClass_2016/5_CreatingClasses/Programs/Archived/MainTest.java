class WithoutMain
{
        static
        {
                System.out.println("This is from static WithoutMain class");
        }

        {
                System.out.println("This is from non-static WithoutMain class");                
        }
        WithoutMain()
        {
                System.out.println("This is from WithoutMain class constructor ");                
        }
}

class MainTest
{
        public static void main(String[] args)
        {

                WithoutMain m1, m2;
                m1=new WithoutMain();
                m2=new WithoutMain();
        }
}
