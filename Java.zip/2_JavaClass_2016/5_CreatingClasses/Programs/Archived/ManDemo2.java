// Demonstrates defining classes 
// Role of Access Specifiers 
// Instantiating objects 




class Man{

        private String name;
        private int age;
	
	public void setName(String nameVal){
	
		if (!nameVal.equals("")){
		
			name = nameVal;
		}
	}
	
	public String getName()
	{
		return(name);
	}

        public void setAge(int age){

           if (age > 0){

              this.age = age; 

              }  
        }  

        public int getAge(){

            return this.age;
        }     

	public void speak(){

		System.out.println(getName() + " is speaking now");
	}

}


public class ManDemo2
{
	public static void main(String[] args){
	
		Man man;
		
		man = new Man();
		
		man.setName("RamKumar");
		
		System.out.println("man's name is " + man.getName());
		man.speak();
	}
}


/****************************************************************************************************************************

- keep the data members of the class as private

_ provide accessor / mutator methods for these data members

- this helps to protect encapsulation

****************************************************************************************************************************/