class Box{



static String st = "staticstring";
static int sint =2345;

void m1(){
System.out.println("m1");
}

static void m2(){

System.out.println("m2 in Box");
}
}

class SmallBox extends Box{

int i2=20;

void m3(){
System.out.println("m3");
}

static void m2(){
System.out.println("m2 in SmallBox");
}

public static void main(String args[]){
Box sb = new SmallBox();

System.out.println( "Box statstring in sb= " + sb.st);

sb.m2();
SmallBox sb2 = new SmallBox();
sb2.m2();


}

}