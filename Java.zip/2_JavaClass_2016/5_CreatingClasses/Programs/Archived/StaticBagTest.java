class StaticBag
{
  static boolean flag;
  static int i, j = 2;
  static double array1[] = { -3.4, 1.0, 0.1e1 };
  static double array2[] = new double[2];
  static String s1, s2 = new String("Hello");
}

class StaticBagTest
{
  public static void main(String args[])
  {
    System.out.println("Attributes of StaticBag...");
    System.out.println("StaticBag.flag = " + StaticBag.flag);
    System.out.println("StaticBag.i    = " + StaticBag.i);
    System.out.println("StaticBag.j    = " + StaticBag.j);

    System.out.println("array1....");
    for(int i = 0; i < StaticBag.array1.length; i++)
    {
      System.out.println(StaticBag.array1[i]);
    }

        System.out.println("array2...");
    for(int i = 0; i < StaticBag.array2.length; i++)
    {
      System.out.println(StaticBag.array2[i]);
    }

    System.out.println(StaticBag.s1);
    System.out.println(StaticBag.s2);
  }
}

    








/*
class Junk {
  public static void main(String args[]) {
    int i, j, k = 3, l = 5;
    System.out.println(i);
    System.out.println(j);
    System.out.println(k);
    System.out.println(l);
  }
}
*/

