import java.util.*;
class X
{
  static int array[];

  static
  {
    Calendar calendar = new GregorianCalendar();

    int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK); 

    if (dayOfWeek == 1){

       array = new int[6];
     }
     
    else{

    array = new int[2];
  
  }

    for(int i = 0; i < array.length; i++)
    {
      array[i] = i;
    } 
  }
}

class StaticInitBlockTest
{
  public static void main(String args[])
  {
    System.out.print("X.array[]: ");
    for(int i = 0; i < (X.array).length; i++)
       {
               System.out.print(X.array[i] + ",");
       }
    
  }
}
