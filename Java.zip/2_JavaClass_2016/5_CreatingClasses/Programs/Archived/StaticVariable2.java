class Thing {
  static int count=0;
  String name;

 
}

class StaticVariable2 {

  public static void main(String args[]) {

    Thing t1 = new Thing();
    Thing.count++;

    Thing t2 = new Thing();
    Thing.count++;
   
         System.out.println("No of objects  " + Thing.count);
  }
}
