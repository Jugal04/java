 class X
 {
   void f()
   {
     for(int j = 0; j < 3; j++)
     {
       int k = 100;
       System.out.println("j = " + j + "; k = " + k);
     }
     // System.out.print(j);  'j is undefined outside for 
   }
 }
 
 class VariableScope
 {
   public static void main(String args[])
   {
     X x = new X();
     x.f();
   }
 }
