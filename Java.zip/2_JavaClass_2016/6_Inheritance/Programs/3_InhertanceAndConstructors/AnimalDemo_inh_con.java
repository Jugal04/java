class Animal{
  String type; //wild or domestic
  String breed;
  int age;
  String color;
  boolean speed;

  //Animal(){}

  Animal(String type,String breed, int age, String color, boolean speed){
    this.type =  type;
   this.breed = breed;
    this.age =  age;
    this.color =  color;
    this.speed =  speed;
  }

  void eat(){
  System.out.println("Animal eats");
  }
  void attack(String severity){
  System.out.println("Animal attack is severity level " + severity);
  }
  void makeNoise(){
  System.out.println("Animal makes noise");
  }
}

class Dog extends Animal{
  boolean isVaccinated;
  int speed;
   
//public Dog(){}

/* public  Dog(String type,String breed ,int age, String color, boolean isVaccinated, int speed)
{
    super(type, breed, age, color, true);
    this.isVaccinated =  isVaccinated;
    this.speed = speed;
  }
*/

  void makeNoise(){
  System.out.println("Dog barks");
  }
  void attack(String severity,boolean isFatal){
  if (isFatal){
    attack(severity);
    }
  }
  void assignSpeed(){
  speed = 40;

  // speed = true; will give error if uncommented.

  super.speed = true;
  }

void printDetails(){

System.out.println(" Type: " +type + " breed"  + breed + " age: " + age + " Color: " + color +  " Vaccinated: " + isVaccinated + "  speed : " + speed + " speed: " + super.speed);

}

}

class Cat extends Animal{

 /*Cat(){
  super("t",10,"r",true);
  }
*/
  
  void makeNoise(){
  super.makeNoise();
  System.out.println("cat mews");
  }
}

class AnimalDemo_inh_con{

  public static void main(String[] args){
  Dog d = new Dog();
  d.assignSpeed();
  System.out.println("Dog speed = " + d.speed);
  System.out.println("Dog speed inherited from animal= " + ((Animal)d).speed);

  // Dog dog =new Dog("Domestic","Labrador", 5, "brown",true, 12);
  //  dog.printDetails();


  Animal a;
  a= new Dog();
  System.out.println(" speed through Animal type variable = " + a.speed);
  a.makeNoise();



  a= new Cat();
  a.makeNoise();

  }

}


/*

What is inheritance 
--------------------

When a class derives the state and behaviour of another class, it is called inheritance. 
*********************************************

- Here we have defined an Animal class and derived a Dog class from it. 

- In other words Dog inherits Animal. 

- Inheritance is a case of �IS A� relationship. 

- You should be able to make the statement �derived class is a base class� 
  i.e., Dog is an Animal 



Inheritance Terminologies 
----------------------------

- Here Animal is called the Base Class or more commonly Super Class. 

- Dog is the Sub Class or Derived Class. 


What happens during inheritance 
---------------------------------

- All the public and protected members are automatically made available in the derived class. 

- Private members are not inherited but their public accessor methods are inherited. 

- The sub class can override any of the inherited members. 

- It can also have its own members. 

- Constructors are never inherited. 

- Members declared as final are also not inherited. 

- When you create a derived class object, the base class part of it is first created and the default constructor of the base   class is automatically invoked. 

- If you want to call a specific constructor of the base class, use the super() method with appropriate arguments. 

- See Constructors section for more details. 


Inheritance and Polymorphism 
-----------------------------

- Since Derived class is a Base class, you can use a base class variable to store the reference to the derived class object. 

- Let us look at this example: 


    Animal a; 
                              
     Dog  d= new Dog()                                                                            
                                                                  
                      // Animal a = new Dog(); is also ok
                 
     a = d;
                 
     a.makeNoise();  // calls Dog class makeNoise() method.
   

       Assume Cat class  also extends Animal;
       
       Cat c = new Cat();
                                                                                       
                       // Animal a = new Cat(); is also ok
       a = c;
      
       a.makeNoise(); 
                      //calls Cat class makeNoise() method.




- Please note that a.makeNoise() invoked Dog�s makeNoise() when a was referring to a Dog object. 

- a.makeNoise() invoked Cat�s makeNoise() when a was referring to a Cat object.. 

- a.makeNoise() never invoked Animal�s makeNoise() method. 

- In other words the method invoked was based on the object that was being REFERRED TO by the variable , but NOT ON THE   DECLARED TYPE of the variable. 

- This is what is called POLYMORPHISM.. 


Rules for Polymorphism 
-----------------------


- The method should be present in both the base class and the derived class. 

- The signature of the derived class method should exactly match the signature of the base class method., including the   return type. 

- The access specifier of the derived class method, should not be more restrictive of the base class method. 

- Use the final key word either for the base class or for a specific method of the base class to prevent polymorphic        behaviour. 

- Also, you cannot override a static base class method in the derived class . 

***************************************************************************************************************************/

