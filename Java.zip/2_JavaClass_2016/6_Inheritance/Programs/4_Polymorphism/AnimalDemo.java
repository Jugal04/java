class Animal{
 String category;
 int age;
 String color;
 double weight;

 public final void move()
 {
  System.out.println("\n The Animal is moving");
 }

public static void sayHello(){
System.out.println("\n This Animal Says Hello");
}

 public void makenoise()
 {
  System.out.println("\n The Animal is Shouting");
 }
}

class Dog extends Animal
{
 Dog(){}

 Dog(String category,int age,String color,double weight)
 {
  this.category=category;
  this.age=age;
  this.color=color;
  this.weight=weight;
 }


public  void makenoise()
 {
  System.out.println("\n The Dog is barking .... bow...bow ...girrrrrrr...");
 }



/* public void move()  // cannot override a final method ..Error
   {
     System.out.println("\n Dog is Moving");
    }
*/ 

public static void sayHello(){            // attempting to override a static method
System.out.println("\n This Dog Says Hello");
}


}

class Cat extends Animal
{
 Cat(){}

 Cat(String category,int age,String color,double weight)
 {
  this.category=category;
  this.age=age;
  this.color=color;
  this.weight=weight;
 }

 public void makenoise()
 {
  System.out.println("\n The Cat is mewing.. miaaaaw");
 }

  /* public void move()  // cannot override final method ... Error..
   {
     System.out.println("\n Cat is Moving");
  
   }
   */

}

class AnimalDemo
{
 public static void main(String args[])
 {

  Animal a = new Dog("domestic",10,"brown",28);
  System.out.println("\n The Dog is of category: " + a.category);
  System.out.println("\n The Dog is of age: " + a.age);
  System.out.println("\n The Dog is of color: " + a.color);
  System.out.println("\n The Dog is of weight: " + a.weight);
  a.makenoise();
  a.move();

  a.sayHello();        // only static binding happens
  Dog d = new Dog();
  d.sayHello();

  Animal B = new Cat("domestic",2,"black",8);
  System.out.println("\n\n\n\n The Cat is of category: " + B.category);
  System.out.println("\n The Cat is of age: " + B.age);
  System.out.println("\n The Cat is of color: " + B.color);
  System.out.println("\n The Cat is of weight: " + B.weight);
  B.makenoise();
  B.move();
  
 }
}

/********

Inheritance and Polymorphism 
-----------------------------

- Since Derived class is a Base class, you can use a base class variable to store the reference to the derived class object. 

- Let us look at this example: 


    Animal a; 
                              
     Dog  d= new Dog()                                                                            
                                                                  
                      // Animal a = new Dog(); is also ok
                 
     a = d;
                 
     a.makeNoise();  // calls Dog class makeNoise() method.
   

       Assume Cat class  also extends Animal;
       
       Cat c = new Cat();
                                                                                       
                       // Animal a = new Cat(); is also ok
       a = c;
      
       a.makeNoise(); 
                      //calls Cat class makeNoise() method.




- Please note that a.makeNoise() invoked Dog�s makeNoise() when a was referring to a Dog object. 

- a.makeNoise() invoked Cat�s makeNoise() when a was referring to a Cat object.. 

- a.makeNoise() never invoked Animal�s makeNoise() method. 

- In other words the method invoked was based on the object that was being REFERRED TO by the variable , but NOT ON THE   DECLARED TYPE of the variable. 

- This is what is called POLYMORPHISM.. 


Rules for Polymorphism 
-----------------------


- Should use super class variable to store derived class object

- The method should be present in both the super class and the sub class. 

- The signature of the sub class method should exactly match the signature of the super class method., including the   return type.(in se5, return type can be a subclass of the overridden method's return type) co variant allowed in SE5

- The access specifier of the derived class method, should not be more restrictive of the base class method. 

- Use the final key word either for the base class or for a specific method of the base class to prevent polymorphic        behaviour. 

- Also, you cannot override a static base class method in the derived class .

- If a subclass defines a static method with the same signature as a static method in the superclass, then the method in the subclass hides the one in the superclass.

- And polymorphism applies only to methods NOT data members 

- Polymorphism is made possible due to run time binding of the overridden methods, provides all rules of pm are followed 

***************************************************************************************************************************/

