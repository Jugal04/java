import java.io.*;

class A{
  void m1(){
   System.out.println("m1 in A");
  }

  void m2()throws IOException{
    System.in.read();
    System.out.println("m1 in A");
  }
}

class B extends A{

  void m1(){
   System.out.println("m1 in B");
  }

  void m2()throws IOException{                    // can throw the same checked exception of the overridden method
   System.in.read();
   System.out.println("m2 in B");
  }

/*
 void m2()throws Exception{                       // compile error - cannot thorw a more general checked exception
   System.in.read();
   System.out.println("m2 in B");
  }
*/
}

class C extends A{

 void m2()throws FileNotFoundException{           // can throw a sub class of the exception

   FileInputStream fis = 
        new FileInputStream("c:myFile.dat");
   System.out.println("m2 in C");
  }
}

class D extends A{

void m2(){                                      // need not throw any exception at all
   System.out.println("m2 in D");
  }
}

class InheritanceExceptionDemo{

public static void main(String[] args){

  A b = new B();
  b.m1();
  try{
      b.m2();
  }
  catch (IOException ioe){
   System.out.println("io exception thrown in b.m2()");
 }
}
}