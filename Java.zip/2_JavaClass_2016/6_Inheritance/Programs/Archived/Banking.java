abstract class Account
{
   private String accountId;
   private double balance;

   private static int nextAccountId = 0;

   protected static String getNextAccountId()
   {
      nextAccountId++;
      return ""+nextAccountId;
   }

   protected Account(String accountId, double balance)
   {
      this.accountId = accountId;
      this.balance = balance;
   }

   public void deposit(double amount)
   {
      balance = balance + amount;
   }

   public abstract double withdraw(double amount);

   public final String getAccountId()
   {
      return accountId;
   }

   public final double getBalance()
   {
      return balance;
   }

   protected final void setBalance(double amount)
   {
      balance = amount;
   }
}

class CheckingAccount extends Account
{
   private int noOfWithdrawals=0;

   protected static String getNextAccountId()
   {
      return "CA" + Account.getNextAccountId();
   }

   public CheckingAccount()
   {
      super(getNextAccountId(), 0);
   }

   public double withdraw(double amount)
   {
      if ((noOfWithdrawals+1) <= 10)
      {
         if ((amount+5) <= getBalance())
         {
            setBalance(getBalance() - (amount+5));
            noOfWithdrawals++;
            return amount;
         }
         else
         {
            return 0.0;
         }
      }
      else
      {
         if (amount <= getBalance())
         {
            setBalance(getBalance() - amount);
            return amount;
         }
         else
         {
            return 0.0;
         }
      }            
   }
}

class SavingsAccount extends Account
{
   protected static String getNextAccountId()
   {
      return "SA" + Account.getNextAccountId();
   }

   public SavingsAccount()
   {
      super(getNextAccountId(), 0);
   }

   public double withdraw(double amount)
   {
      if (amount <= getBalance())
      {
         setBalance(getBalance() - amount);
         return amount;
      }
      else
      {
         return 0.0;
      }
   }            
}

public class Banking
{
   public static void main(String args[])
   {
      Account chkAct = new CheckingAccount();
      Account savAct = new SavingsAccount();

      System.out.println("Attributes of chkAct - ");

      System.out.println("Before deposit: " +
         "accountId= " + chkAct.getAccountId() +
         " balance= " + chkAct.getBalance());

      chkAct.deposit(1000);

      System.out.println("After deposit : " +
         "accountId= " + chkAct.getAccountId() +
         " balance= " + chkAct.getBalance());

      chkAct.withdraw(500);

      System.out.println("After withdraw : " +
         "accountId= " + chkAct.getAccountId() +
         " balance= " + chkAct.getBalance());

      System.out.println("Attributes of savAct - ");

      System.out.println("Before deposit: " +
         "accountId= " + savAct.getAccountId() +
         " balance= " + savAct.getBalance());

      savAct.deposit(1000);

      System.out.println("After deposit : " +
         "accountId= " + savAct.getAccountId() +
         " balance= " + savAct.getBalance());

      savAct.withdraw(500);

      System.out.println("After withdraw : " +
         "accountId= " + savAct.getAccountId() +
         " balance= " + savAct.getBalance());
   }
}
