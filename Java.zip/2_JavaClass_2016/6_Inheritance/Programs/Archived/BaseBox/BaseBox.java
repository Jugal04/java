public class BaseBox
{
 private double length;
 private double breadth;
 private double height;

 public double weight;

 protected String material;

 public void setLength(double p_length)
 {
  if(p_length>0)
  {
   length=p_length;
  }
  else
  {
   System.out.println("INVALID LENGTH");
  }
 }

 public double getLength()
 {
  return(length);
 }

 public void setBreadth(double p_breadth)
 {
  if(p_breadth>0)
  {
   breadth=p_breadth;
  }
  else
  {
   System.out.println("INVALID BREADTH");
  }
 }

 public double getBreadth()
 {
  return(breadth);
 }

 public void setHeight(double p_height)
 {
  if(p_height>0)
  {
   height=p_height;
  }
  else
  {
   System.out.println("INVALID HEIGHT");
  }
 }

 public double getHeight()
 {
  return(height);
 }

 public void setWeight(double p_weight)
 {
  if(p_weight>0)
  {
   weight=p_weight;
  }
  else
  {
   System.out.println("INVALID WEIGHT");
  }
 }

 public double getWeight()
 {
  return(weight);
 }

 public void setMaterial(String p_material)
 {
  if(!p_material.equals(""))
  {
   material=p_material;
  }
  else
  {
   System.out.println("INVALID MATERIAL");
  }
 }

 public String getMaterial()
 {
  return(material);
 }

 BaseBox(){}

 BaseBox(double p_length,double p_breadth,double p_height,double p_weight,String p_material)
 {
  length=p_length;
  breadth=p_breadth;
  height=p_height;
  weight=p_weight;
  material=p_material;
 }

 public void volume()
 {
  double volume=getLength()*getBreadth()*getHeight();
  System.out.println("\n The volume of the box is : " + volume);
 }
}

class BaseCarton extends BaseBox
{
 private double thickness;

 public void setThickness(double p_thickness)
 {
  if(p_thickness>0)
  {
   thickness=p_thickness;
  }
  else
  {
   System.out.println("INVALID THICKNESS");
  }
 }

 public double getThickness()
 {
  return(thickness);
 }

 BaseCarton(){}

 BaseCarton(double p_length,double p_breadth,double p_height,double p_weight,String p_material,double p_thickness)
 {
  super(p_length,p_breadth,p_height,p_weight,p_material);
  this.thickness=p_thickness;
 }
}




