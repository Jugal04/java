// Demonstrates that a Private Data Member can neither be accessed
// directly nor thru set() & get() methods

public class BaseBoxDemo
{
 public static void main(String args[])
 {

  // Direct access
  BaseBox Box1 = new BaseBox(2.0,2.0,2.0,2.0,"silver");

  // A Private/protected  data member cannot be accessed directly
/* System.out.println("\n Length  : " + Box1.length);
  System.out.println("\n Breadth : " + Box1.breadth);
  System.out.println("\n Height  : " + Box1.height);
  System.out.println("\n Weight  : " + Box1.weight);
  System.out.println("\n Material: " + Box1.material);
 */
  Box1.volume();

  BaseCarton Carton1 = new BaseCarton(3.0,3.0,3.0,3.0,"bronze",3.3);
  // A Private data member cannot be accessed directly
/*  System.out.println("\n Length  : " + Carton1.length);
  System.out.println("\n Breadth : " + Carton1.breadth);
  System.out.println("\n Height  : " + Carton1.height);
  System.out.println("\n Weight  : " + Carton1.weight);
  System.out.println("\n Thickness:" + Carton1.thickness);
*/

  // superclass protected member being accessed in derived class
  System.out.println("\n Material (protected member of base class): " + Carton1.material);
  Carton1.volume();

  //Access thru set()&get() methods
  
  // A Private data member can be
  // accessed by (public) set() & get() methods
  System.out.println("\n Length  : " + Box1.getLength());
  System.out.println("\n Breadth : " + Box1.getBreadth());
  System.out.println("\n Height  : " + Box1.getHeight());
  System.out.println("\n Weight  : " + Box1.getWeight());
  System.out.println("\n Material: " + Box1.getMaterial());
  Box1.volume();

  // A Private data member can be
  // accessed by (public) set() & get() methods 
  System.out.println("\n Length  : " + Carton1.getLength());
  System.out.println("\n Breadth : " + Carton1.getBreadth());
  System.out.println("\n Height  : " + Carton1.getHeight());
  System.out.println("\n Weight  : " + Carton1.getWeight());
  System.out.println("\n Material: " + Carton1.getMaterial());
  System.out.println("\n Thickness:" + Carton1.getThickness());
  Carton1.volume();
 }
}




