class C {

  final void m1(){
    System.out.println(" from final");
   }

  private void pvtBase(){
    System.out.println(" from pvtBase from C");
   }

  static void sm1(){
    System.out.println(" from sm1() in C");
   }
}

class C1 extends C{

  // void m1(){}  cannot override a final method

  //int m1(){return 2;} cannot override  even if return type differs

   void m1(int i){
     System.out.println(" from m1(int) in C1"); 
            // overloaded since the signature differs
     }



// can have a  method with the same signature here. The pvtBase() of C is private and hence not //inherited.

   void pvtBase(){
      System.out.println(" pvtBase in C1");
    }


// void sm1(){} attempting to override the static method -- error

  static void sm1(){

     System.out.println(" pvtBase in C1 redefined sm1()");

   } // ok - this is treated as redefined sm1(), not override
 }

class CTest{

 public static void main(String[] args){
  C1 c1 = new C1();
  c1.m1();
  c1.m1(2);
  c1.pvtBase();

  C.sm1();

  C1.sm1();

  }
}



