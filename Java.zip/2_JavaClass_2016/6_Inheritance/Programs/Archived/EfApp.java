class E
{
  int x;
}

class F extends E
{
  String x;
}

class EfApp
{
  public static void main(String args[])
  {
    F f = new F();
    f.x = "This is a string";

    E e = f;
    e.x = 10;

    System.out.println("f.x ....... = " + f.x);
    System.out.println("((E)f).x .. = " + ((E)f).x);
  }
}
