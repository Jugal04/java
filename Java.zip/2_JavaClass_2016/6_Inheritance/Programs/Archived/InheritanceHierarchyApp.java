class Employee
{
}

class Manager extends Employee
{
}

class Secretary extends Employee
{
}

class Programmer extends Employee
{
}

class Executive extends Manager
{
}

class InheritanceHierarchyApp
{
   public static void main(String args[])
   {
      Employee emp;

      System.out.println("Instantiating Employee...");
      emp = new Employee();

      System.out.println("Instantiating Manager...");
      emp = new Manager();

      System.out.println("Instantiating Secretary...");
      emp = new Secretary();

      System.out.println("Instantiating Programmer...");
      emp = new Programmer();

      System.out.println("Instantiating Executive...");
     emp = new Executive();
   }
}
