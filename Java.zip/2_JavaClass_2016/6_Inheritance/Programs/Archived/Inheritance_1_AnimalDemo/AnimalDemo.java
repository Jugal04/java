class Animal{

  String type; //wild or domestic
  int age;
  String color;
  boolean speed;

  void eat(){
  System.out.println("Animal eats");
  }

  void attack(String severity){
  System.out.println("Animal attack is severity level " + severity);
  }

  void makeNoise(){
  System.out.println("Animal makes noise");
  }

}

class Dog extends Animal{

  boolean isVaccinated;
  int speed;

  void makeNoise(){
  System.out.println("Dog barks");
  }

  void attack(String severity,boolean isFatal){
  if (isFatal){
    attack(severity);
    }
  }

  void assignSpeed(){
  speed = 40;

  // speed = true; will give error if uncommented.

  super.speed = true;
  }
}


class Cat extends Animal{
  
  void makeNoise(){
  super.makeNoise();
  System.out.println("cat mews");
  }
}

class AnimalDemo{

  public static void main(String[] args){
  Dog d = new Dog();
  d.assignSpeed();
  System.out.println("Dog speed = " + d.speed);
  System.out.println("Dog speed inherited from animal= " + ((Animal)d).speed);

  Animal a;
  a= new Dog();
  a.makeNoise();

  a= new Cat();
  a.makeNoise();

  }

}

