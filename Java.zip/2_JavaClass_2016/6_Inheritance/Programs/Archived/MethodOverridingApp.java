class A3
{
  void hello()
  {
    System.out.println("Hello from A3");
  }

  void hello(String s)
  {
    System.out.println("Hello from A3 " + s);
  }
}

class B3 extends A3
{
  void hello(String s)
  {
    System.out.println("Hello from B3 " + s);
  }
}

class C3 extends B3
{
  void hello()
  {
    System.out.println("Hello from C3");
  }
}

class MethodOverridingApp
{
  public static void main(String args[])
  {
    C3 vC3Ref = new C3();
    System.out.println("Invoking vC3Ref.hello()...");
    vC3Ref.hello();

    A3 vA3Ref = new C3();
    System.out.println();
    System.out.println("Invoking vA3Ref.hello()...");
    vA3Ref.hello();

    System.out.println();
    System.out.println("Invoking"
	+ " vA3Ref.hello(\"Java\")...");
    vA3Ref.hello("Java");
  }
}
