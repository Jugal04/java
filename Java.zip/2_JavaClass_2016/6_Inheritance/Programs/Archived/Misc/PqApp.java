class P
{
  static int x=10;
  int y=20;
}

class Q extends P
{
  static String x="Java";
  static int y=100;
}

class PqApp
{
  public static void main(String args[])
  {
    Q q = new Q();
    System.out.println("q.x = " + q.x);
    System.out.println("q.y = " + q.y);
  }
}
