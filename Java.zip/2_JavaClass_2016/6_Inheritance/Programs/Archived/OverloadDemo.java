class Animal1{

  void eat(){
  System.out.println("Animal Eats");
 }
    
}

class Dog1 extends Animal1{

//overloads inherited method
 
void eat(String food){
  System.out.println("Dog Eats " + food);
 }

void move(){
  System.out.println("Dog Moves");
 }

//overloads method in the same class
void move(int speed){
  System.out.println("dog moves @ " +speed +"  kmph");
 }

//public void move(){}      only access specifier differs will result in compile time                             //errror

public void move(int a, int b){
System.out.println("Dog Moves public method " + a+" "+b);
 }

/***************** Error
static void m1(){}
void m1(){}
******************/

static void m2(){System.out.println("static void m2()");}
static void m2(int i){System.out.println("static void m2(int) "+ i);}
void m2(int x, int y){System.out.println("void m2(int x " +x +"int y "+y);}


/********************* Error - only retrun type differs

int move(int speed){
      return(speed+10);
 }
*********************/
}
class OverloadDemo{

  public static void main(String[] args){
  Dog1 d = new Dog1();
      d.move();
      d.move(100);
      d.move(10,20);

      d.eat();
      d.eat("biscuits");

      Dog1.m2();
         d.m2();
      Dog1.m2(5);
         d.m2(5);

         d.m2(5,10);
      
   }

}

