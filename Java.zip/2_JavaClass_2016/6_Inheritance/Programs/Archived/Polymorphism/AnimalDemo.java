class Animal
{
 String category;
 int age;
 String color;
 double weight;

 public final void move()
 {
  System.out.println("\n The Animal is moving");
 }

 public void makenoise()
 {
  System.out.println("\n The Animal is Shouting");
 }
}

class Dog extends Animal
{

 Dog(){}

 Dog(String category,int age,String color,double weight)
 {
  this.category=category;
  this.age=age;
  this.color=color;
  this.weight=weight;
 }
 public void makenoise()
 {
  System.out.println("\n The Dog is barking .... bow...bow ...girrrrrrr...");
 }
/* public void move()  // cannot override a final method ..Error
   {
     System.out.println("\n Dog is Moving");
    }
*/ 
}

class Cat extends Animal
{
 Cat(){}

 Cat(String category,int age,String color,double weight)
 {
  this.category=category;
  this.age=age;
  this.color=color;
  this.weight=weight;
 }

 public void makenoise()
 {
  System.out.println("\n The Cat is mewing.. miaaaaw");
 }

 /*
 public void move()  // cannot override final method ... Error..
   {
     System.out.println("\n Cat is Moving");
    }   
  */
   
}

class AnimalDemo
{
 public static void main(String args[])
 {

  Animal A = new Dog("domestic",10,"brown",28);
  System.out.println("\n The Dog is of category: " + A.category);
  System.out.println("\n The Dog is of age: " + A.age);
  System.out.println("\n The Dog is of color: " + A.color);
  System.out.println("\n The Dog is of weight: " + A.weight);
  A.makenoise();
  A.move();

  Animal B = new Cat("domestic",2,"black",8);
  System.out.println("\n\n\n\n The Cat is of category: " + B.category);
  System.out.println("\n The Cat is of age: " + B.age);
  System.out.println("\n The Cat is of color: " + B.color);
  System.out.println("\n The Cat is of weight: " + B.weight);
  B.makenoise();
  B.move();
  
 }
}

