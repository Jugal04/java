//polymorphism Vs typecasting


   
class Employee
 {
   private String name;
   private double salary;
   

    public Employee() {}

    public Employee(String n, double s)
    {  name = n;
       salary = s;
            
    }
 
/* will give error if commented
 public void print()
    {  System.out.println("name ...... = " + name + "\n"
                       + "salary .... = " + salary + "\n"
                          );
    }
   
*/
    public void raiseSalary(double byPercent)
    {  salary *= 1 + byPercent / 100;
    }

    public String getName()
      {
       return name;
      }

    public double getSalary()
      {
      return salary;
     }
  
 }


 
      class Manager extends Employee
         {
             private int expense_account_no;
              
               public Manager()
               {}

              
              
              public Manager(String n, double s ,int expac)
                   {
                     super(n,s);
                     expense_account_no = expac;
                   }
              public void print()
                   {  System.out.println("name ...... = " + getName() + "\n"
                       + "salary of manager.... = " + getSalary() + "\n"
                       +  "expense account no =" + expense_account_no + "\n");
                   }
             
          }


    class Exec extends Employee
   
    {

          public void print()
           
          {
             System.out.println("\n executive");
          }

     }

   class PolymorphismVsTypeCasting
    
      { 
      
        public static void main(String[] args)
         {

        /* Since the print() has been commented in Employee class
           the compiler tries to bind all the print methods statically
           Since static binding resolves addresses based on the            declared type of the variable, it looks for a print() for              employee class. Since it is not available(commented out            here), it generates error during compilation itself 
        */  


              Employee e1 = new Manager();
             e1.print();

                                  // ((Manager)e1).print();
      
                e1 = new Exec();
               e1.print();
                                  // ((Exec)e1).print();
         } 
  }
         

    

