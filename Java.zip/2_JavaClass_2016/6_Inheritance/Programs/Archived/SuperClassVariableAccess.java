// SuperClassVariableAccess.java


class P
{
   int x=10;
   int y=20;
}

class Q extends P
{
    String x="Java";
    int y=100;
}

class SuperClassVariableAccess
{
  public static void main(String args[])
  {
    Q q = new Q();
    System.out.println("q.x = " + q.x);
    System.out.println("q.y = " + q.y);
    System.out.println("p.x = " + ((P)q).x);
    System.out.println("p.y = " + ((P)q).y);
  }
}
