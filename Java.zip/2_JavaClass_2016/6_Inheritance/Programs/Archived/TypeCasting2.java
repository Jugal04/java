//polymorphism Vs typecasting


   
class Employee
 {
   private String name;
   private double salary;
   

    public Employee() {}

    public Employee(String n, double s)
    {  name = n;
       salary = s;
               }
 

 public void print()
    {     System.out.println("Employee Print");
                          
    }

public void print2(){

        System.out.println("Employee Print2 -non overridden");
                          
    }




    
 }


 
      class Manager extends Employee
         {
             private int expense_account_no;
              
               public Manager()
               {}

              
              
              public Manager(String n, double s ,int expac)
                   {
                     super(n,s);
                     expense_account_no = expac;
                   }
              public void print()
                   { 

          System.out.println("Manager Print");
                   }


             
          }

     

   class TypeCasting2
    
      { 
      
        public static void main(String[] args)
         {

             Employee e1 = new Manager();
             e1.print();
            ((Employee)e1).print();// bound to manager in run time , so will print only manager print

            ((Employee)e1).print2();
    
                                         
         } 
  }
         

    

