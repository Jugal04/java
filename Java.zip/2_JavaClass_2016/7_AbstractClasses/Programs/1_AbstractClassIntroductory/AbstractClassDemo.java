/**************************************************************************************************************************

Abstract Classes

Program to demonstrate the creation and use of an abstract class 

****************************************************************************************************************************/


 abstract class Shape
{
  public abstract void display();
}

class Circle extends Shape
{
public  void display()
  {
    System.out.println("Circle");
  }
}

class Rectangle extends Shape
{
  public void display()
  {
    System.out.println("Rectangle");
  }
}

class Triangle extends Shape
{
 public void display()
  {
    System.out.println("Triangle");
  }
}

class AbstractClassDemo
{
  public static void main(String args[])
  {
    Shape s = new Circle();
    s.display();
    s = new Rectangle();
    s.display();
    s = new Triangle();
    s.display();
  }
}


/***************************************************************************************************************************

Code Analysis 
----------------

- abstract class Shape {�} defines the class Shape. 

- The abstract keyword indicates that it is an abstract class. 

- This means that it contains abstract methods and thus can�t be instantiated. 

- It has to be only inherited. 

- abstract void display(); declares an abstract method display(). 

- Since it is an abstract method, it doesn't have a body. 

- class Circle extends Shape {�} defines the class Circle and it is a subclass of Shape. 

- void display() {�} is the implementation of the abstract method defined in the Shape class. 

- Since the Circle class has implemented display(), it is a concrete class. 

- This means that the Circle class can be used to create objects. 

- class Rectangle extends Shape {�} defines Rectangle that extends Shape. 

- void display() {�} is the implementation of the base class abstract method. 

- class AbstractClassDemo {�} is the application class that tests the other worker classes defined in the same source file. 

- Shape s = new Circle(); creates a Circle object and assigns the reference to the Shape type variable s. 

- Here We use an abstract base class variable to store the reference to the derived class object. 

- s.display(); invokes the display() method against the base class type variable s. 

- Since method binding, in this case, is based on the type of the object being referenced, and s now holds a reference to a 
- Circle object, the display() method defined in the Circle class is invoked. 

- s = new Rectangle(); assigns the reference of a Rectangle object to s. 

- Since s contains a reference to a Rectangle object, invoking the display() method against it calls the display() method   defined in the Rectangle class. 

****************************************************************************************************************************

Why do we require an  abstract class 
--------------------------------------

- Sometimes it is required to create a superclass from which a number of subclasses are derived, just to take advantage of   polymorphism. 

- You want to enforce uniform behaviour (methods) across a set of classes, draw(); 

- So you define a Shape class with a draw() method and make it obligatory on the part of other similar classes (circle,   rectangle etc.,) to inherit from this. 

- But you cant provide any meaningful impementation for the draw() method in the Shape class. (what shape can you draw?) 

- To cater to these, Java has abstract classes. 

- So the method is declared as an abstract method and also the class as an abstarct class. 



What is an abstract class 
-------------------------

- An abstract class is a class in which one or more methods are declared but not defined. 

- The bodies of these methods are omitted. 

- The methods without definition are called abstract methods. 

- The declaration for an abstract method ends with a semi-colon. 

- An abstract method should be specified with the keyword abstract to identify it as such. 

- To define an abstract class, the keyword abstract should be used in front of the class name. 

- Abstract classes are only for the purpose of inheritance. 

- This means that an abstract method cannot be private, since a private method cannot be inherited. 

- When a base class method is declared as abstract, all subclasses must implement it. 

- Abstract classes cannot be used to create objects. 

- But, a variable of an abstract class type can be declared. 

- For example, a variable can be declared of Animal type. 

- Then this variable can be used to store objects of the subclasses, Dog, Spaniel, Duck and Cat. 

- If a class contains an abstract method, the class automatically becomes an abstract class. 

- If a class is abstract, the abstract keyword should be used when it is defined, even if it only inherits an abstract method   from its superclass. 

- Classes further down the inheritance hierarchy inherit the abstract base class. 

- If a class is derived from an abstract base class, it doesn't have to define all the abstract methods in the superclass. 

- A subclass becomes a concrete class only if it implements all the abstract methods inherited from its superclass. 

- A class that has implementations for all of its methods � derived or defined � is called a concrete class. 

- A concrete class can be used to create objects. 

- Note that not implementing even one of the abstract methods makes the subclass an abstract class. 

- An abstarct class can contain fully implemented (concrete) methods, other than abstract methods. 

- Surprisingly, an abstract class can contain all concrete methods and still you can define the class as abstract. 

- Here, by declaring it abstarct, you effectively  prevent its instatntiation, while still retaining the implementation as a   sort of model. 

- Abstract base class variables can be used for exhibiting polymorphic behaviour. 

****************************************************************************************************************************/
