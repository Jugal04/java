 abstract class Animal{
  String type; //wild or domestic
  int age;
  String color;
  boolean speed;

  abstract void eat();
  abstract  void attack(String severity);
  abstract void makeNoise();

  }



class Dog extends Animal{

  boolean isVaccinated;
  int speed;

  void makeNoise(){
  System.out.println("Dog barks");
  }

  void attack(String severity,boolean isFatal){
  if (isFatal){
    attack(severity);  
    }
  }

  void attack(String severity){
        System.out.println("dog attacks");
  }


  void assignSpeed(){
  speed = 40;

  // speed = true; will give error if uncommented.

  super.speed = true;
  }

 void eat(){
   System.out.println("dog eats");
 }


}


class Cat extends Animal{
  
  void makeNoise(){
 
  System.out.println("cat mews");
  }

 void attack(String severity){

 System.out.println("cat attacks");

  } 

void eat(){

System.out.println("cat eats");

}

}

class AnimalDemoAbstract{

  public static void main(String[] args){
  Dog d = new Dog();
  d.assignSpeed();
  System.out.println("Dog speed = " + d.speed);
  System.out.println("Dog speed inherited from animal= " + ((Animal)d).speed);

  Animal a;
  a= new Dog();
   System.out.println(" speed through Animal type variable = " + a.speed);
  a.makeNoise();

  a= new Cat();
  a.makeNoise();

  }

}  
/*
Why do we require an  abstract class 
--------------------------------------

- Sometimes it is required to create a superclass from which a number of subclasses are derived, just to take advantage of   polymorphism. 

- You want to enforce uniform behaviour (methods) across a set of classes, draw(); 

- So you define a Shape class with a draw() method and make it obligatory on the part of other similar classes (circle,   rectangle etc.,) to inherit from this. 

- But you cant provide any meaningful impementation for the draw() method in the Shape class. (what shape can you draw?) 

- To cater to these, Java has abstract classes. 

- So the method is declared as an abstract method and also the class as an abstarct class. 



What is an abstract class 
-------------------------

- An abstract class is a class in which one or more methods are declared but not defined. 

- The bodies of these methods are omitted. 

- The methods without definition are called abstract methods. 

- The declaration for an abstract method ends with a semi-colon. 

- An abstract method should be specified with the keyword abstract to identify it as such. 

- To define an abstract class, the keyword abstract should be used in front of the class name. 

- Abstract classes are only for the purpose of inheritance. 

- This means that an abstract method cannot be private, since a private method cannot be inherited. 

- When a base class method is declared as abstract, all subclasses must implement it. 

- Abstract classes cannot be used to create objects. 

- But, a variable of an abstract class type can be declared. 

- For example, a variable can be declared of Animal type. 

- Then this variable can be used to store objects of the subclasses, Dog, Spaniel, Duck and Cat. 

- If a class contains an abstract method, the class automatically becomes an abstract class. 

- If a class is abstract, the abstract keyword should be used when it is defined, even if it only inherits an abstract method   from its superclass. 

- Classes further down the inheritance hierarchy inherit the abstract base class. 

- If a class is derived from an abstract base class, it doesn't have to define all the abstract methods in the superclass. 

- A subclass becomes a concrete class only if it implements all the abstract methods inherited from its superclass. 

- A class that has implementations for all of its methods � derived or defined � is called a concrete class. 

- A concrete class can be used to create objects. 

- Note that not implementing even one of the abstract methods makes the subclass an abstract class. 

- An abstarct class can contain fully implemented (concrete) methods, other than abstract methods. 

- Surprisingly, an abstract class can contain all concrete methods and still you can define the class as abstract. 

- Here, by declaring it abstarct, you effective prevent its instatntiation, while still retaining the implementation as a   sort of model. 

- Abstract base class variables can be used for exhibiting polymorphic behaviour. 

****************************************************************************************************************************/

