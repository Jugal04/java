/***************************************************************************************************************************


                                                   Defining and Implementing an Interface
                                                   ---------------------------------------


Program which defines and implements an interface 

****************************************************************************************************************************/

public interface Shape
{
 void draw();
}


class Circle  implements Shape
{
   public void draw(){
    //draws a circle;
}
}

class rectangle implements Shape{
  public void draw(){
    // draws a rectangle;
 }
}
  

/************************************************************************************************************************

Code Analysis 
--------------

- interface Shape {�} is the definition of Shape interface. 

- It contains an abstract method void draw(); 

- Since the methods of an interface are public and abstract by default, we need not explicitly specify the same. 

- class Circle implements this interface. 

- It means it has to provide definition (code) for the methods of the interface.

- public void draw(){..} is the implementation of the interface method. 

- It should be prefixed with public qualifier and should have the same signature of the interface method including return   type. 

*****************************************************************************************************************************

What is an interface 
----------------------

Introductory 
--------------

- An interface is like class
 
- Its more like an abstract class. 

- It will contain only abstract methods and variables. 

- The methods of an interface are always public and abstract by default. 

- It is error to declare these methods as private or protected.

- Also, you cannot declare the interface as private or proteced.

- However, the default access specifier is supported.

- The variables defined in an interface are public, final and static by default. 

- Interface compiles with the extension .class. 

- So it should not duplicate another class name in the same namespace (package) 


Implementing an Interface 
----------------------------

- An interface needs to be implemented by a class, with the key word implements .... 

- It means the implementing class should provide definition (code) for all the methods of the interface. 

- The signature of the method should be same as that in the interface including return type. 

- The access sepcifier should be public. 

- Or, it should not be more restrictive of the corresponding method in the interface. 


Advantages Of using an interface 
---------------------------------

- Inerfaces help us to group together common behaviour of classes 

- Enable us to enforce similar behaviour (but same/ different implementation)in all the implementing classes. 

- You can also achieve this by extending an abstract class. 

- If you extend an abstract class, then you wont be able to extend any other class if required 

- You can use interface type variable to store the reference to all classes that implement that interface 

- This aspect also facilitates polymorphic behaviour. 

Exceptions thrown by an Interface
----------------------------------

- Assume the interface method throws a checked exception using the throws keyword (thows IOException)
- The implementing class metod It iws cannot thrrow a more general exception than this ( cannot say throws Exception)
- But it can throw  FileNotFoundException, which is asub class of IOException
- It is OK for the implementing class - method not to throw any exception at all.
- It is OK for the implementing class - method to throw a subclass of that exception
- Its OK for the implementing class - method not to throw any unchecked Exception



**************************************************************************************************************************/
