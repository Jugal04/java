// Demonstrates the implementation of methods of interface in various classes

interface Speed
{
 public void highspeed(); // no need to say public
 public void slowspeed();
}

class Vehicle implements Speed
{
 public void highspeed()
 {
  System.out.println("\n Vehicle  Running at High Speed");
 }
 public void slowspeed()
 {
  System.out.println("\n Vehicle Running at slow speed");
 }
}

class Plane implements Speed
{
 public void highspeed()
 {
  System.out.println("\n The Plane can fly at high speed than any other    type of vehicle");
 }
 public void slowspeed()
 {
  System.out.println("\n The Plane can fly slow but not as slow as     other vehicles");
 }
}

class InterfaceDemo1 
{
 public static void main(String args[])
 {
  Speed v = new Vehicle();
  Speed p = new Plane();
  v.highspeed();
  v.slowspeed();

  p.highspeed();
  p.slowspeed();
 }
}

  

