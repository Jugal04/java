// Demonstrates the interface Standarddata

class IEmployee
{

  String EName;
  int BONUSPERCENT;
  String CONAME;
  int Year;

  IEmployee(){}

  IEmployee(int Bonuspercent,String Coname,int Year,String Ename)
  {
   BONUSPERCENT = Bonuspercent;
   CONAME = Coname;
   this.Year = Year;
   EName = Ename;
  }

}
 
class InterfaceDemo2
{
 public static void main(String args[])
 {

  IEmployee Emp1 = new IEmployee(Standarddata.BONUSPERCENT,Standarddata.CONAME,Standarddata.Year,"Raman");

  System.out.println(Emp1.BONUSPERCENT);
  System.out.println(Emp1.CONAME);
  System.out.println(Emp1.Year);
  System.out.println(Emp1.EName);

  // Also you can access Interface variables directly
  System.out.println("Direct from Interface :" +    Standarddata.BONUSPERCENT);
 }

}


