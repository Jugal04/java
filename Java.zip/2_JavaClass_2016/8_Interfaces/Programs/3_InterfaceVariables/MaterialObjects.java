/*************************************************************************************************************************

                                             Interface Variables

****************************************************************************************************************************/

//MaterialObjects.java  


interface Material
{
  String BRONZE = "bronze";
  String GOLD = "gold";
  String MARBLE = "marble";
  String SILVER = "silver";
  String WOOD = "wood";
}

abstract class MaterialObject
{
  String material;
}

class Ball extends MaterialObject
{
  Ball(String material)
  {
    this.material = material;
  }
}

class Coin extends MaterialObject
{
  Coin(String material)
  {
    this.material = material;
  }
}

class Ring extends MaterialObject
{
  Ring(String material)
  {
    this.material = material;
  }
}

class MaterialObjects
{
  public static void main(String args[])
  {
    Ball ball = new Ball(Material.WOOD);
    Coin coin = new Coin(Material.SILVER);
    Ring ring = new Ring(Material.GOLD);
    System.out.println(ball.material);
    System.out.println(coin.material);
    System.out.println(ring.material);
  }
}

/****************************************************************************************************************************

Code Analysis 
-------------

- interface Material {�} is the definition of Material interface. 

- String bronze = "bronze"; defines a String constant named bronze. 

- Variables defined in an interface are automatically taken as public and final variables. 

- abstract class MaterialObject {�} is the definition of an abstract class MaterialObject. 

- String material; defines a String type instance variable. 

- class Ball extends MaterialObject {�} is the definition of class Ball class. 

- It is a subclass of the MaterialObject class. 

- The constructor Ball(String material) {�} accepts a String and assigns it to the base class variable material. 

- class MaterialObjects {�} is the definition of test class MaterialObjects. 

- In Ball ball = new Ball(Material.wood); , Material.WOOD returns a string containing �wood� and it used to construct a Ball   object. 

- System.out.println(ball.material); prints the current value of material variable to verify that it is �wood�. 

- Since the interface contains only variables, we are not using the implements clause. 

- Moreover the interface and the implementing class both are in the same package

- But it is always better to use the implements keyword

- Here the interface variables are used in the same package 

- If you are using them in another package, the interface has to be declared public and 
  this package should be imported. 

- Also please note that the data members of an interface are ALWAYS public, static and 
  final by default. 

**************************************************************************************************************************/
