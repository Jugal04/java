interface Standarddata
{
 int BONUSPERCENT =10;
 String CONAME ="ABC & CO";
 int Year=2005;
}