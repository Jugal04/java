/************************************************************************************************************************** 

                            An Application to Illustrate Interface Reference Variables
                            ----------------------------------------------------------


- This program illustrates how an interface type variable can be used to hold references of objects that implement the  interface. 

- It also shows how to use interface type variables to invoke methods defined in that interface. 

***************************************************************************************************************************/

//InterfaceReferenceVariable.java


interface A
{
  void display(String s);
}
  
class C1 implements A
{
 public void display(String s)
 {
    System.out.println("C1: " + s);
  }
}

class C2 implements A
{
  public void display(String s)
  {
    System.out.println("C2: " + s);
  }
}

class C3 implements A
{
  public void display(String s)
  {
    System.out.println("C3: " + s);
  }
}

class InterfaceReferenceVariable
{
  public static void main(String args[])
  {
    A a;
    a = new C1();
    a.display("String 1");
    a = new C2();
    a.display("String 2");
    a = new C3();
    a.display("String 3");
  }
}


/****************************************************************************************************************************

Code Analysis 
--------------

- interface A {�} is the definition of an interface named A. 

- void display(String s); is the only method declaration of interface A. 

- class C1 implements A {�} is the definition of class C1 that declares itself as providing the functionality defined by   interface A. 

- public void display(String s) {�} is an implementation to complete the contract with the interface A. 

- class InterfaceReferenceVariable {�} is a test class. 

- A a; declares a variable named a of type A. 

- This variable can be used to hold the reference of any object that implements the interface A. 

- a = new C1(); creates a C1 type of object and assigns its reference to a. 

- Since C1 implements the interface A, C1 is_a A. 

- This means that the interface reference variable a can accept the reference of a C1 type object. 

- Since a contains the reference of a C1 object a.display("String 1"); invokes the display() method defined in the C1 class. 

- a = new C2(); assigns the reference of C2 object to a. 

- Since a contains the reference of C2 object a.display("String 2"); invokes the display() method defined in C2. 

***************************************************************************************************************************/
