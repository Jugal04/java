/************************************************************************************************************************* 

                                    An Application that Illustrates Interface Inheritance
                                    -----------------------------------------------------

**************************************************************************************************************************/
 

// This program illustrates how new interfaces can be defined based on existing interfaces. 


//InterfaceInheritance.java


interface J
{
  int j = 200;
  int j1();
}

interface K
{
  double k1();
}

interface r extends K{
void m1();

}

interface L extends J, K
{
  boolean l1();
}

class I implements L
{
  public int j1()
  {
    return 4;
  }

  public double k1()
  {
    return 6.8;
  }

  public boolean l1()
  {
    return true;
  }
}

class InterfaceInheritance
{  
  public static void main(String args[])
  {
    I i = new I();
    System.out.println("i.j .... = " + i.j);
    System.out.println("i.j1().. = " + i.j1());
    System.out.println("i.k1().. = " + i.k1());
    System.out.println("i.l1().. = " + i.l1());
  }
}

/**************************************************************************************************************************

Code Analysis 
--------------

- interface J {�} is the definition of an interface J. 

- It defines a constant named j and a method j1(). 

- interface K {�} is the definition of an interface K and it defines a method k1(). 

- interface L extends J, K {�} is the definition of an interface L. 

- The subinterface L is derived from superinterfaces J and K. 

- This means that the declarations contained in J and K are now derived into L. 

- So, the implementor of L needs to provide implementations for not only the methods specified in L, but also the methods   declared in J and K as well. 

- The interface L declares an additional method l1() apart from methods derived from J and K. 

- class I implements L {�} is the definition of class I that implements the interface L. 

- It derives the constant j defined in the interface J. 

- It implements methods specified in the interface L, that is, j1(), k1() and l1(). 

- class InterfaceInheritance {�} is the definition of the test class InterfaceInheritance . 

- I i = new I(); instantiates an object of type I. 

- The following print() statements invoke the members of the object referenced by i. 


Note:
----

- Multiple inheritance is possible with interfaces unlike classes 

- A class can implement multiple interfaces 

**************************************************************************************************************************/
