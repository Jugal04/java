/* Exceptions in interfaces are also subject to overriding rules*/



import java.io.*;

interface Computable{

int  add(int a , int b)throws IOException;

}

class Addition implements Computable{

public int add(int  a, int b) throws IOException, ArithmeticException{ 
  // can also throw EOFException instead of IOException
  // But error if throws Exception

return a+b;
}

public static void main(String[] args) throws IOException{

Addition a = new Addition();
int p = a.add(5,10);
System.out.println(p);
}
}