

/**************************************************************************************************************************

                                      
Accessing outer class variable from inner class 

****************************************************************************************************************************/


//InnerTest.java


class Employee {
	private String name;

	Employee(String name) {
		this.name = name;
	}

	public String toString() {
		return "From Employee - name : " + name;
	}


	 class SalaryDetails {
		private double basic;      // + other salary related fields

		SalaryDetails(double basic) {
			this.basic = basic;
		}

		public String toString() {
			StringBuffer buffer = new StringBuffer();
			buffer.append("From SalaryDetails - basic: " + basic).append("\n");
			buffer.append("From SalaryDetails - name: " + name).append("\n");


			buffer.append("From SalaryDetails - Employee.this.name: " + Employee.this.name).append("\n");
                        buffer.append("From SalaryDetails without spl notation -name: " + name).append("\n");

			return buffer.toString();
		}
	}
}


public class InnerTest {
	public static void main(String[] args) {
		Employee emp = new Employee("Anand");
		Employee.SalaryDetails salaryDetails = emp.new SalaryDetails(50000.00);
		System.out.println(emp);
		System.out.println(salaryDetails);
	}
}

