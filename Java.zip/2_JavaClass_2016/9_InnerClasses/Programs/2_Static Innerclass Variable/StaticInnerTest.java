/*************************************************************************************************************************

Accessing Inner class static variables from outer class 

***************************************************************************************************************************/

//StaticInnerTest.java


class Employee {
	private String name;

	Employee(String name) {
		this.name = name;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("From Employee - name : " + name).append("\n");
		buffer.append("From Employee - SalaryDetails.da : " + SalaryDetails.da).append("\n");
		return buffer.toString();
	}


	static class SalaryDetails {
		private static int da = 200;

		private double basic;

		SalaryDetails(double basic) {
			this.basic = basic;
		}

		public String toString() {
			StringBuffer buffer = new StringBuffer();
			buffer.append("From SalaryDetails - basic: " + basic).append("\n");
			return buffer.toString();
		}
	}
}


public class StaticInnerTest {
	public static void main(String[] args) {
		Employee emp = new Employee("Anand");
		Employee.SalaryDetails salaryDetails = new Employee.SalaryDetails(50000.00);
		System.out.println(emp);
		System.out.println(salaryDetails);
	}
}
