import java.util.Random;

public class MagicHat1
{
   static int maxRabbits = 5;
   static Random select = new Random();
   static private String[] rabbitNames =
               { "Floppsy", "Moppsy",
                 "Gnasher", "Thumper" };
   static private int[] rabbitNamesCount =
               new int[rabbitNames.length];

   private String hatName;
   private Rabbit rabbits[];

   public MagicHat1(final String hatName)
   {
      this.hatName = hatName;
      rabbits = new Rabbit[1+select.nextInt(maxRabbits)];

      for(int i = 0; i < rabbits.length; i++)
      {
         rabbits[i] = new Rabbit();
      }
   }

   public String toString()
   {
      String hatString = "\n" + hatName + " contains:\n";

      for(int i = 0; i < rabbits.length; i++)
      {
         hatString += "\t" + rabbits[i] + " ";
      }
      return hatString;
   }

   class Rabbit
   {
      private String name;

      public Rabbit()
      {
         int index = select.nextInt(rabbitNames.length);
         name = rabbitNames[index] + (++rabbitNamesCount[index]);
      }

      public String toString()
      {

         return "name= " + name + ": hat = " + hatName;

      }
   }
}
