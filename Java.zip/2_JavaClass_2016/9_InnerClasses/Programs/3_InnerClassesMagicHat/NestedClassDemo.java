public class NestedClassDemo
{
   static public void main(String[] args)
   {
      System.out.println(new MagicHat("Gray Topper"));
      System.out.println(new MagicHat("Black Topper"));
      System.out.println(new MagicHat("Baseball Cap"));

      System.out.println(new MagicHat1("Gray Topper1"));
      System.out.println(new MagicHat1("Black Topper1"));
      System.out.println(new MagicHat1("Baseball Cap1"));

      MagicHat1 oldHat = new MagicHat1("Old hat");
      MagicHat1.Rabbit rabbit = oldHat.new Rabbit();
      System.out.println(oldHat);
      System.out.println("\n New rabbit is: " + rabbit);
   }
}
