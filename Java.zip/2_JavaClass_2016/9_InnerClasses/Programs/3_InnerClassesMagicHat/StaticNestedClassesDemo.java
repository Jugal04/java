public class StaticNestedClassesDemo
{
   static public void main(String[] args)
   {
      System.out.println(new MagicHat("Gray Topper"));
      System.out.println(new MagicHat("Black Topper"));
      System.out.println(new MagicHat("Baseball Cap"));

      MagicHat.Rabbit rabbit = new MagicHat.Rabbit();
      System.out.println(rabbit);
    }
}
