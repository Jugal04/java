/***************************************************************************************************************************

All in one example

***************************************************************************************************************************/

// InnerClassAllTest.java



class Outer {
	private int outerVar;

	Outer() {
		outerVar = 10;
	}

	public String getState(Outer.Inner inner) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("From Outer.getState() - outerVar: " + outerVar).append("\n");
		buffer.append("From Outer.getState() - innerVar: " + inner.innerVar).append("\n");
		return buffer.toString();
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("From Outer - outerVar: " + outerVar).append("\n");
		//buffer.append("From Outer - innerVar: " + innerVar).append("\n"); //CANNOT BE DONE
		buffer.append("From Outer - StaticInner.staticInnerVar: " + StaticInner.staticInnerVar).append("\n");
		return buffer.toString();
	}


	class Inner {
		private int innerVar;

		Inner() {
			innerVar = 20;
		}

		public String toString() {
			StringBuffer buffer = new StringBuffer();
			buffer.append("From Inner - innerVar: " + innerVar).append("\n");
			buffer.append("From Inner - outerVar: " + outerVar).append("\n");
			buffer.append("From Inner - Outer.this.outerVar: " + Outer.this.outerVar).append("\n");
			return buffer.toString();
		}
	}

	static class StaticInner {
		private static int staticInnerVar = 30;

		StaticInner() {
		}

		public String toString() {
			StringBuffer buffer = new StringBuffer();
			buffer.append("From StaticInner - staticInnerVar: " + staticInnerVar).append("\n");
			//buffer.append("From StaticInner - outerVar: " + outerVar).append("\n");  CANNOT BE DONE
			return buffer.toString();
		}
	}

}


public class InnerClassAllTest {
	public static void main(String[] args) {
		Outer outer = new Outer();
		Outer.Inner inner = outer.new Inner();
		Outer.StaticInner staticInner = new Outer.StaticInner();
		System.out.println(outer);
		System.out.println(outer.getState(inner));
		System.out.println(inner);
		System.out.println(staticInner);
	}
}

