public class RandomNumberGeneration2{

	public static void main(String[] args){
                int lowerBound =100;
                int upperBound = 300;
 	
		for (int i=0;i<10;i++){
			
                                          int rand =(int)((upperBound-lowerBound+1)*Math.random()+lowerBound);                                   
                                          System.out.println(rand);
		         }
	}
}



