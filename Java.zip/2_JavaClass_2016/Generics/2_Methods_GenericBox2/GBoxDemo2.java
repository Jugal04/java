class GBox<T >{
   private T length;
   private T width;
   private T height;


public GBox(){
     length= null;
     width = null;
     height =  null;
  }

public  GBox( T length, T width, T height){
       this.length =  length;
       this.width = width;
      this.height = height;
}

public void setLength(T length){
    this.length =  length;
}

public T getLength(){
     return this.length;
}

public void setWidth(T width){
    this.width =  width;
}

public T getWidth(){
     return this.width;
}

public void setHeight(T height){
    this.height = height;
}

public T getHeight(){
     return this.height;
}

public String toString(){
   return ("\n length = " + this.length  + "\n   width = " + this.width + "\n  height = " + this.height );
}

public  T volume(){  
return length * width * height;     // GOT STUCK UP HERE

}

}

class GBoxDemo2{
  public static void main(String[] args){
      GBox<Integer> firstIntBox = new GBox<Integer>();
      firstIntBox.setLength(5);
      firstIntBox.setWidth(6);
      firstIntBox.setHeight(7);
      System.out.println( "\n first intBox dimensions are : length =" +firstIntBox.getLength() + "widhth = " +firstIntBox.getWidth()+" height = " +firstIntBox.getHeight());

      GBox<Integer>  intBox =new GBox<Integer>(10,20,30);
      System.out.println("\n Integer Box " + intBox);
   
      GBox<Double>  doubleBox =new GBox<Double>(10.5,20.5,30.5);
       System.out.println("\n Double Box " +doubleBox);
 System.out.println("\n Double Box volume " +doubleBox.volume());
     }

}

