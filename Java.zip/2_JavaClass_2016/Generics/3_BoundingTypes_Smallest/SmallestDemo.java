import java.util.*;

class Smallest{
  public static <T extends Comparable> T  smallestItem(T item1, T item2){
     if (item1.compareTo(item2) > 0) {
             return item2;
           }
    else{
              return item1;
        }
   }
}

class SmallestDemo{
  public static void main(String args[]){
 System.out.println("smallest item is " + Smallest.smallestItem(10,2));
  Box box1 =new Box(10,10,10);
  Box box2 =new Box(2,2,2);
System.out.println("smallest item is " + Smallest.smallestItem(box1,box2));

 }
}

class Box implements Comparable{
   private  int length;
   private int  width;
   private int height;

public Box(){
    
  }


public Box( int length, int width, int height){
       this.length =  length;
       this.width = width;
      this.height = height;
}

public void setLength( int length){
    this.length =  length;
}

public  int getLength(){
     return this.length;
}

public void setWidth( int width){
    this.width =  width;
}

public  int getWidth(){
     return this.width;
}

public void setHeight(int height){
    this.height = height;
}

public int  getHeight(){
     return this.height;
}

public String toString(){
   return ("\n length = " + this.length  + "\n   width = " + this.width + "\n  height = " + this.height);
}

public int volume(){

return length * width * height;
}

public int compareTo(Object  aBox){
Box otherBox =  (Box)aBox;
return this.volume() - otherBox.volume();
}

}


