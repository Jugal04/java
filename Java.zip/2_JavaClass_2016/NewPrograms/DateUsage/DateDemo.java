import java.util.*;
import java.text.SimpleDateFormat;

class DateDemo{

public static void main(String[] args){

GregorianCalendar gcDate1 = new GregorianCalendar(2017, 01,01);
System.out.println("gcDate1 month is " +  gcDate1.get(Calendar.MONTH));
System.out.println(" gcDate1 date is "   +  gcDate1.get(Calendar.DATE));
System.out.println(" gcDate1 year  is "  +  gcDate1.get(Calendar.YEAR));


GregorianCalendar gcDate2 = new GregorianCalendar(2017, 03,01);
System.out.println("gcDate2 month is " +  gcDate2.get(Calendar.MONTH));
System.out.println(" gcDate2 date is "   +  gcDate2.get(Calendar.DATE));
System.out.println(" gcDate2 year  is "  +  gcDate2.get(Calendar.YEAR));

gcDate1.add(Calendar.YEAR,1);
System.out.println("gcDate1 month is " +  gcDate1.get(Calendar.MONTH));
System.out.println(" gcDate1 date is "   +  gcDate1.get(Calendar.DATE));
System.out.println(" gcDate1 year  is "  +  gcDate1.get(Calendar.YEAR));




}




}
