class Missile{
  private static int missileCount;
  private static Missile missile;
  static int id;
 static{
   missile = new Missile();
  }


private Missile(){
id++;
missileCount++;
}

public static Missile getMissile(){
   if(missileCount<3){
     return new Missile();
   }
   else{
   return Missile.missile;
   
   }
   
   
   }
 

}
class MissileDemo{
public static void main(String[] args){
Missile missile1  =  Missile.getMissile();
System.out.println(Missile.id);
Missile missile2  =  Missile.getMissile();
System.out.println(Missile.id);
Missile missile3  =  Missile.getMissile();
System.out.println(Missile.id);
Missile missile4  =  Missile.getMissile();
System.out.println(Missile.id);
}
}