/*  5.	Develop a system to detect excess delivery of LPG cylinders . The cap is 7 cylinders per consumer no.  Excess of 7 will throw  RefillQuotaExceeded Exception. Print all the relevant details.  Enclose the  refillRequest method in a n infinite loop with exit option by the user. User will enter his requirement (not exceeding 2 at a time).
*/

public class Lpg{  
  public static  int[][] customerRecord ={ {101,102,103,104,105}, {0,0,0,0,0}};
  public static int  customerRecordPosition;

  public static String checkCustomerId(int customerId){
     String status="NOT FOUND";
     for(int i=0;i<5;i++){
           if (customerId == customerRecord[0][i]){
                 status ="FOUND";
                 customerRecordPosition = i;
                 break;
           }
    }
  return status;
 }

  public static String lpgIssue( int refillRequired){
  String order = "";
    if (customerRecord[1][customerRecordPosition] + refillRequired  <= 7){
           order = "ISSUED";
           customerRecord[1][customerRecordPosition] =  customerRecord[1][customerRecordPosition] + refillRequired;
          }
           else{
                   order ="REJECTED";
                  }
   return order;
  }

  public static void main(String[] args) throws Exception{
     int customerNo;
     while(true){
             while (true){
                             System.out.println(" Enter Customer No");
                              customerNo = Console.readInt();
                              if (checkCustomerId(customerNo).equals("NOT FOUND")){
                                               System.out.println("Invalid Customer Id.. Pl re enter");
                                                }
                                                else{
                                                         break;
                                                }
                            }
          System.out.println("Pl. enter refills required ");;
          int refillsRequired = Console.readInt();
          System.out.println("Your Request is  "+  lpgIssue(refillsRequired));
          }
       }    
}



  
































