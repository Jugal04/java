package com.ns.contactPack.contactPack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ContactService {

    @Autowired
    private ContactRepository contactRepository;

    public List<ContactDetails> getContacts(){
        List<ContactDetails> contacts=new ArrayList<>();
        contactRepository.findAll().forEach(contacts::add);
        return contacts;
    }

    public void addContact(ContactDetails contactDetails){
        List<ContactDetails> contacts=new ArrayList<>();
        contactRepository.findAll().forEach(contacts::add);
        Integer sNo=contacts.size()+1;
        contactDetails.setsNo(sNo);
        contactRepository.save(contactDetails);
    }

    public void updateContact(ContactDetails contactDetails, String name){
        int i;
        List<ContactDetails> contacts=new ArrayList<>();
        contactRepository.findAll().forEach(contacts::add);
        for(i=0;i<contacts.size();i++){
            if(contacts.get(i).getPersonName().equals(name)){
                break;
            }
        }
        contactDetails.setsNo(i);
        contactRepository.save(contactDetails);
    }

    public void deleteContact(String name){
        //    cont.removeIf(t->t.getContactName().equals(name));
        contactRepository.deleteById(name);
    }

}
