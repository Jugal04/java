package com.ns.contactPack.restController;

import com.ns.contactPack.contactPack.ContactDetails;
import com.ns.contactPack.contactPack.ContactService;
import com.ns.contactPack.message.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class restControl {
    @Autowired
    private ContactService contactService;

    @RequestMapping("/all")
    public Response getResponse(){
        List<ContactDetails> allContactDetails =contactService.getContacts();
        Response response=new Response("Done", allContactDetails);
        return response;

    }

    @RequestMapping(method = RequestMethod.POST,value="/save")
    public Response saveCustomer(@RequestBody ContactDetails contactDetails){
        contactService.addContact(contactDetails);
        Response response=new Response("Done", contactDetails);
        return response;
    }

}
