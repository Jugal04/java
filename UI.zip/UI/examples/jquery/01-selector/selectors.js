cols = $('td')
cols[0]

$('#contactScreen')

$('.formRow')

$('[datetime]')

$('[type]')

$('input[type]')

$('input[type="tel"]')

$('tr')
$('tr:first’)
$('tr:last')
$('tr:gt(0)')
$('tr:gt(1)')

$('tbody tr:even');

$('input,select,textarea')
$(':input');

:even finds all even numbered elements in a selection. 
:odd finds all odd numbered elements in a selection. 
:not(selection) finds all elements that do not match the selection. 
:gt(selection) finds all elements with an index greater than the supplied number. 
:checked finds radio buttons or check boxes that are checked. 
:selected finds options in select boxes that are selected. 
:contains(text) finds elements that contain a given piece of text. 
:empty finds all elements that have no children. 
:focus finds the element that currently has focus. 
:first finds the rst element in a set. 
:last finds the last element in a set. 

