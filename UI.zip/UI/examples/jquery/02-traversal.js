$('table').find('time')

$('time').parent()

$('time').parents('table')

$(':input').parent()

$(':input').parents('form')

$(':input').parents('form').andSelf();

$('header').siblings('script');

$(':input').siblings()

$(':input[required]').siblings('label').css('background', 'red')

$('div', 'form')

$('div', 'form').first()

$('div', 'form').last().next()

$(':input').add('label')

$(':contains("Bob Morris")').closest('td')

$('section:eq(0)')

$('section').eq(0)

$('time').siblings('.overlay').parents('tr').last();

$(':input[required]').siblings('label');

$(':input[required]').siblings('label').append(<span class="requiredMarker">*</span>);

<label for="contactName" style="color: red;">
Contact name<span class="requiredMarker">*</span>
</label>



$(':input[required]').siblings('label').append($('<span>').text('*'). addClass('requiredMarker'));

$('h2').before('<span>before</span>')

$('h2').after('<span>after</span>')

$('form').prepend('<span>Preprend</span>')

$('form').append('<span>append</span>')

$('.requiredMarker').remove();

$('#contactDetails h2').text('CONTACT DETAILS');

$('#contactDetails h2').html('<span>Contact Details</span>');

$('#contactDetails h2').wrapInner('<span>');

$('[name="contactName"]').val('testing 123');

$('[name="contactName"]').val();

$('label span').removeClass('requiredMarker');

$('textarea').attr('maxlength');

$('textarea').attr('maxlength', 200)

 $('textarea').removeAttr('maxlength');
 
 appScreen.serializeForm()
 
 
