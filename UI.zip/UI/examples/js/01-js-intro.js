s1 = "Welcome to JavaScript";

typeof s1

s1 = 'Hi, Welcome to JavaScript';

s1.toLowerCase()

s1.substr(0,2)

s1.indexOf('to')

s1.length

s1 = s1 + " - Hope you have a good time"

s2 = 'This is Ram's idea';

n1=10

n1/3

Math.round(10/3)

n2=Math.sqrt(-1)

isNaN(n2)

b1=true

b2=false

n1=null

typeof n1

typeof n3

"undefined"

a1 = [3,6,4,1,4,9]
var result = 0;
for (var i = 0; i < a1.length; i++) {
	result = result + a1[i]; 
}

function doubleTheNumber(num) { 
   var result = num * 2; 
   return result;
}

for (var i = 0; i < a1.length; i++) {
   console.log('The value of i is ' + i); 
   console.log('The value in the array is ' + a1[i]); 
   result = result + a1[i];
}

var result = 0; 
var counter = 0;
while (counter < a1.length) { 
   result = result + a1[counter]; 
   counter++;
} 

function checkCountEven(a1, n1) {
   var result = false;
   var count = 0;
   for (var i = 0; i < a1.length; i++) {
      var number = a1[i];
      if (number % 2 != 0) {
         continue; 
      }
      count = count + number; 
      if (count > n1) {
         result = true;
         break; 
      }
   }
   return result; 
}
a1 = [3, 6, 4, 1, 4, 9]
checkCountEven(a1, 20)


function describeNumber(num) { 
	if (num >= 0 && num % 2 == 0) {
		console.log(num + ' is a positive even number');
	} 
	else if (num >= 0 && num % 2 == 1) {
		console.log(num + ' is a positive odd number');
	} 
	else if (num < 0 && num % 2 == 0) { 
		console.log(num + ' is a negative even number');
	} 
	else {
		console.log(num + ' is a negative odd number');
	} 
}

function whatAmI(v1) { 
	if (v1) {
		console.log('I am true'); 
	} 
	else {
		console.log('I am false'); 
	}
}

function add(n1, n2) { 
	return n1+n2;
}

function add(v1, v2) {
	if (typeof v1 === "number" && typeof v2 === "number") {
		return v1+v2; 
	} 
	else {
		throw "both arguments must be numbers"; 
	}
}