function doubleTheNumber(num) { 
	var result = num * 2; return result;
}


for (var i = 0; i < a1.length; i++) {
	console.log('The value of i is ' + i); 
	console.log('The value in the array is ' + a1[i]); 
	result = result + a1[i];
}

function whatAmI(v1) { 
	if (v1) {
		console.log('I am true'); 
	} 
	else {
		console.log('I am false'); 
	}
}

function add(n1, n2) { 
	return n1+n2;
}

function add(v1, v2) {
	if (typeof v1 === "number" && typeof v2 === "number") {
		return v1+v2; 
	} 
	else {
		throw "both arguments must be numbers"; 
	
	}
}

function isPositive(num) { 
	return num >= 0;
}

function countForArray(array, condition) { 
	var result = 0;
	for (var i = 0; i < array.length; i++) { 
		var element = array[i];
		if (condition(element)) {
			result++; 
		}
	}
	return result; 
}

> a = [1,2,-3,2,-5]
> countForArray(a, f1)

> countForArray(a, function(num) { 
						return num < 0;
					})
					
> a1 = [-2,1-3,5,6]
> a.filter(function(num) {
				return num%2==0; 
			}).map(function(num) {
						return Math.abs(num); 
					});
					
function counter() { 
	var myCount = 0; 
	return myCount++;
}

function getCounter() { 
	var myCount = 0; 
	return function() {
		return myCount++; 
	}
}

function add() { 
	var result = 0;
	for (var i = 0; i < arguments.length; i++) { 
		result = result + arguments[i];
	}
	return result; 
}

function getCount() { 
	return this.myCount++;
}

var counter2 = getCount.bind({myCount:100});


words = ["jet", "pet", "cat", "dog", "pet", "cat", "dog", "dog", "pet", "cat", "dog", "pet", "cat", "dog", "dog", "pet"];
words.map(function(word) {
             return {"word": word, "count": 1};
          })
          			
words.reduce(function(map, word) {
          		map[word] = (map[word] ? map[word] : 0) + 1;
          		return map;
          	}, []);






					
					