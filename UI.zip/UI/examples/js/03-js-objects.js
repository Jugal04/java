o= {
	firstName:'Dane', 
	lastName:'Cameron', 
	getFullName: function() {
					return this.firstName + ' ' + this.lastName; 
				}
	}
	
	
o= {
	'first name':'Dane', 
	'last name':'Cameron'
}

o.profession = "Software Developer";

o.getFullName = function() {
	return this.firstName + " " + this.lastName + " (" + this.profession + ")"; 
}

Array.prototype.contains = function (val) { 
	for (var i = 0; i < this.length; i++) {
		if (this[i] === val) { 
			return true;
		} 
	}
	return false; 
}


staffPrototype = {
	increasePay : function(percentage) {
					this.salary = this.salary + ((this.salary * percentage) / 100);
				  },
	getFullName : function() {
					return this.firstName + " " + this.lastName + " (" + this.profession + ")";
				  } 
				}

function extend(obj) { 
	function T(){};
	T.prototype = obj;
	return new T(); 
}


> s1 = extend(staffPrototype);

> s1.firstName = 'Morgan';
> s1.lastName = 'Thomas';
> s1.salary = 50000;
> s1.profession = 'Graphic Designer';

> s1.getFullName()

> s1.increasePay(10)

> s1.salary

> s1.getFullName = function() {
	return this.lastName + ", "+ this.firstName + " (" + this.profession + ")";
}

function Staff(firstName, lastName, salary, profession) { 
	this.firstName = firstName;
	this.lastName = lastName;
	this.salary = salary;
	this.profession = profession; 
}

s3 = new Staff('Brian', 'Downing', 40000, 'Software Tester');



function createStaffMember(initialSalary, firstName, lastName) { 
	var salary = null;
	o= 
	  {
		setSalary : function() {
						if (initialSalary > 0 && initialSalary < 200000) { 
							salary = initialSalary;
						} 
						else {
							throw 'The salary must be between 0 and 200000';
						} 
					},
		getSalary : function() { 
						return salary;
					},
		firstName : firstName, 
		lastName : lastName
	 }; 
	 o.setSalary(initialSalary); 
	 return o;
}


