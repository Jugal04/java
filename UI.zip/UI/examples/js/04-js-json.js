<?xml version="1.0" encoding="UTF-8"?> 
<contact>
	<contactName>William Jones</contactName>
	<phoneNumber>555-2941</phoneNumber> 
	<emailAddress>william@testing.com</emailAddress>
	<company>
		<code>123</code>
		<name>ABC Incorporated</name> 
	</company>
	<company>
		<code>123</code>
		<name>ABC Incorporated</name> 
	</company>
	<company>
		<code>123</code>
		<name>ABC Incorporated</name> 
	</company>
	<notes></notes>
	<lastContacted>2014-09-25</lastContacted> 
</contact>

c1 = {
		contactName: "William Jones", 
		phoneNumber:"555-2941", 
		emailAddress:"william@testing.com", 
		company:{
					code:123,
					name:"ABC Incorporated" 
				},
		notes:null,
		lastContacted: new Date() 
	}

contactString = JSON.stringify(c1)

c2 = JSON.parse(contactString)

new Date().getTime() 1404088573560

new Date().toString()
"Mon Jun 30 2014 12:36:01 GMT+1200 (New Zealand Standard Time)"

new Date().toJSON(); "2014-06-30T00:37:09.348Z"

contact2 = JSON.parse(contactString, dateReviver);

dateReviver = function(name, value) {
	var regExp = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/ 
	if (value && typeof value === 'string' && value.match(regExp)) {
		return new Date(value); 
	} 
	else {
		return value; 
	}
}

